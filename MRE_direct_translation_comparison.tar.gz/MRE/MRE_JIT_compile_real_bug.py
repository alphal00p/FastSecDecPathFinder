#!/usr/bin/env python3
"""Standalone Symbolica real-JIT mismatch reproducer.

This script has no FSD imports.  It reads a saved ``format_plain()`` dump of
the DOT double-box PSD50 explicit sector expressions, builds one eager
multi-output evaluator and one JIT multi-output evaluator, then compares:

  * raw real-JIT ``evaluate(rows)``,
  * complex-JIT ``evaluate_complex(rows.astype(complex))``,
  * eager real ``evaluate(rows)`` as reference.

On the local Symbolica community/dev wheel used by FSD development, the raw
real-JIT path disagrees at order one while the complex-JIT path agrees with the
eager reference to roundoff.
"""

from __future__ import annotations

import argparse
import json
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
import sys
import time

import numpy as np
from symbolica import E, Expression, S


MRE_ROOT = Path(__file__).resolve().parent
DEFAULT_EXPR_FILE = MRE_ROOT / "assets" / "PSD50_explicit_format_plain.json"


def _symbolica_version() -> str:
    try:
        return version("symbolica")
    except PackageNotFoundError:
        return "unknown"


def _load_expression_data(path: Path, indices: list[int] | None) -> tuple[list[str], list[str]]:
    """Load saved ``format_plain()`` expressions and optional output subset."""
    payload = json.loads(path.read_text())
    input_names = [str(name) for name in payload["input_names"]]
    expressions = [str(expr) for expr in payload["expressions"]]
    if indices is not None:
        expressions = [expressions[int(index)] for index in indices]
    return input_names, expressions


def _parse_indices(raw: str | None) -> list[int] | None:
    """Parse a comma-separated index list or return ``None`` for all outputs."""
    if raw is None or raw.strip().lower() in {"", "all"}:
        return None
    return [int(part) for part in raw.replace(",", " ").split()]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--expression-file",
        type=Path,
        default=DEFAULT_EXPR_FILE,
        help="JSON file with input_names and format_plain expression strings.",
    )
    parser.add_argument(
        "--expression-indices",
        default="all",
        help=(
            "Output expression indices to use, e.g. '1' or '0,1,2'. "
            "Default 'all' uses the full five-output PSD50 expression."
        ),
    )
    parser.add_argument("--samples", type=int, default=4, help="Number of random rows.")
    parser.add_argument("--seed", type=int, default=123, help="Random seed.")
    parser.add_argument("--rtol", type=float, default=1.0e-10, help="Bug verdict tolerance.")
    args = parser.parse_args()

    indices = _parse_indices(args.expression_indices)
    input_names, expression_strings = _load_expression_data(args.expression_file, indices)
    params = [S(name) for name in input_names]

    print("Standalone Symbolica real-JIT mismatch reproducer")
    print(f"python: {sys.executable}")
    print(f"symbolica version: {_symbolica_version()}")
    print(f"expression file: {args.expression_file}")
    print(f"outputs used: {'all' if indices is None else indices}")
    print(f"input count: {len(params)}")
    print(f"output count: {len(expression_strings)}")
    print(f"expression bytes: {sum(len(expr.encode('utf-8')) for expr in expression_strings)}")

    t0 = time.perf_counter()
    expressions = [E(expr) for expr in expression_strings]
    parse_seconds = time.perf_counter() - t0

    t0 = time.perf_counter()
    eager = Expression.evaluator_multiple(expressions, params, jit_compile=False)
    eager_build_seconds = time.perf_counter() - t0

    t0 = time.perf_counter()
    jit = Expression.evaluator_multiple(expressions, params, jit_compile=True)
    jit_build_seconds = time.perf_counter() - t0

    print(f"parse time: {parse_seconds:.6f} s")
    print(f"eager build time: {eager_build_seconds:.6f} s")
    print(f"JIT build time: {jit_build_seconds:.6f} s")

    rng = np.random.default_rng(args.seed)
    rows = 0.125 + 0.75 * rng.random((args.samples, len(params)))
    real_jit = np.asarray(jit.evaluate(rows), dtype=float)
    complex_jit = np.asarray(
        jit.evaluate_complex(np.ascontiguousarray(rows, dtype=np.complex128)),
        dtype=np.complex128,
    ).real
    eager_ref = np.asarray(eager.evaluate(rows), dtype=float)

    real_diff = float(np.max(np.abs(real_jit - eager_ref)))
    complex_diff = float(np.max(np.abs(complex_jit - eager_ref)))
    scale = max(1.0, float(np.max(np.abs(eager_ref))))
    real_rel = real_diff / scale
    complex_rel = complex_diff / scale

    np.set_printoptions(precision=16, suppress=False)
    print("sample rows:")
    print(rows)
    print("raw real JIT evaluate(rows):")
    print(real_jit)
    print("complex JIT evaluate_complex(rows.astype(complex)).real:")
    print(complex_jit)
    print("eager evaluate(rows) reference:")
    print(eager_ref)
    print(f"max |real_jit - eager|:    {real_diff:.16e} (relative {real_rel:.16e})")
    print(f"max |complex_jit - eager|: {complex_diff:.16e} (relative {complex_rel:.16e})")

    if real_rel > args.rtol and complex_rel <= args.rtol:
        print("BUG REPRODUCED: raw real JIT evaluate() disagrees; complex JIT agrees.")
    elif real_rel <= args.rtol:
        print("BUG NOT REPRODUCED: raw real JIT agrees with eager within tolerance.")
    else:
        print("INCONCLUSIVE: both raw real JIT and complex JIT differ from eager.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
