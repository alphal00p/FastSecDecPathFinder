# Symbolica Evaluator Performance MRE

This folder is self-contained.  It does not depend on any generated files
outside `MRE/`.

## Main checks

Run the evaluator timing MRE:

```sh
python3 MRE_jit_direct_translation_performance.py
```


Run the direct-vs-indirect JIT translation comparison used for FSD's default:

```sh
python3 MRE_jit_direct_translation_performance.py \
  --compare-jit-direct-translation \
  --compare-trials 5 \
  --modes jit-real jit-complex \
  --batch-sizes 1 16 256 1000 4096 \
  --repeats 80 \
  --skip-pysecdec
```

Run the JIT-real wrong-result check:

```sh
python3 MRE_JIT_compile_real_bug.py
```

Both scripts read the saved Symbolica expression strings from
`assets/PSD50_explicit_format_plain.json`.

## Optional pySecDec generated-kernel timing

The table always prints the recorded `pySecDec53_REF` reference line by
default.  To execute the local pySecDec generated kernels as well, run:

```sh
python3 MRE_jit_direct_translation_performance.py \
  --run-pysecdec-kernel-benchmark \
  --pysecdec-kernel-sectors 53 \
  --batch-sizes 100000
```

With `--run-pysecdec-kernel-benchmark`, the script automatically runs
`make clean && make` in `assets/` before timing the kernels, and reports that
elapsed rebuild time in the `build_s` column.  The default asset Makefile
target intentionally compiles only the five `sector_53_*` order kernels needed
by the MRE.  A full static archive can still be built with
`make -C assets full`, but it is not needed for the default MRE.

To rebuild the optional pySecDec pylink shared library used by
`--include-pysecdec-wall-maxeval`, run:

```sh
make -C assets pysecdec-double-box PYTHON=python3 -j
```

The generated Makefiles discover `pySecDecContrib` from the selected Python
environment, so the receiving machine only needs compatible `symbolica`,
`numpy`, `pySecDec`, and the usual pySecDec C++ dependencies.

Clean generated artifacts and Python caches with:

```sh
./clean.sh
```
