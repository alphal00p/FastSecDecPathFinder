#include <secdecutil/series.hpp>

#include "sector_48_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_48()
{
return {0,0,{{48,{0},6,sector_48_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_48_order_0_integrand
#endif
}},true,"eps"};
}

}
