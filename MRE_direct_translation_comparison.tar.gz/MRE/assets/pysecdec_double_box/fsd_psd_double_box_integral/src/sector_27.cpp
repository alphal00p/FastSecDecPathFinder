#include <secdecutil/series.hpp>

#include "sector_27_n2.hpp"
#include "sector_27_n1.hpp"
#include "sector_27_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_27()
{
return {-2,0,{{27,{-2},4,sector_27_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_27_order_n2_integrand
#endif
},{27,{-1},6,sector_27_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_27_order_n1_integrand
#endif
},{27,{0},6,sector_27_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_27_order_0_integrand
#endif
}},true,"eps"};
}

}
