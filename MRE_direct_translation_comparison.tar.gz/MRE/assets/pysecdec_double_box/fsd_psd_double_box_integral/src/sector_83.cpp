#include <secdecutil/series.hpp>

#include "sector_83_n3.hpp"
#include "sector_83_n2.hpp"
#include "sector_83_n1.hpp"
#include "sector_83_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_83()
{
return {-3,0,{{83,{-3},3,sector_83_order_n3_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_83_order_n3_integrand
#endif
},{83,{-2},6,sector_83_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_83_order_n2_integrand
#endif
},{83,{-1},6,sector_83_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_83_order_n1_integrand
#endif
},{83,{0},6,sector_83_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_83_order_0_integrand
#endif
}},true,"eps"};
}

}
