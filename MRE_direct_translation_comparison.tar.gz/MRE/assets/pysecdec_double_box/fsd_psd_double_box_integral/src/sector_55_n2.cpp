#include "sector_55_n2.hpp"
namespace fsd_psd_double_box_integral
{
#ifdef SECDEC_WITH_CUDA
__host__ __device__
#endif
integrand_return_t sector_55_order_n2_integrand
(
    real_t const * restrict const integration_variables,
    real_t const * restrict const real_parameters,
    complex_t const * restrict const complex_parameters,
    secdecutil::ResultInfo * restrict const result_info
)
{
    const auto x0 = integration_variables[0]; (void)x0;
    const auto x1 = integration_variables[1]; (void)x1;
    const auto x2 = integration_variables[2]; (void)x2;
    const auto x3 = integration_variables[3]; (void)x3;
    const auto x4 = integration_variables[4]; (void)x4;
    const auto x5 = integration_variables[5]; (void)x5;
    const auto s12 = real_parameters[0]; (void)s12;
    const auto s23 = real_parameters[1]; (void)s23;
    auto tmp1_1 = SecDecInternalQuo(1, 4)*x5;
    auto tmp1_2 = SecDecInternalQuo(1, 2)*x5;
    auto tmp1_3 = SecDecInternalQuo(3, 4)*x5;
    auto tmp1_4 = x3 + x2 + 1;
    auto tmp1_5 = x5 + tmp1_4;
    auto tmp1_6 = x2 + x3;
    auto tmp1_7 = x5*tmp1_6;
    auto tmp1_8 = x4*tmp1_7;
    auto tmp3_1 = tmp1_8 + tmp1_5;
    auto tmp3_2 = tmp1_6 + 1;
    auto tmp1_9 = x5 + 1;
    auto tmp3_3 = tmp1_9*tmp3_2;
    auto tmp3_4 = tmp1_7 + 2*x5;
    auto tmp1_10 = SecDecInternalQuo(3, 2)*x5;
    auto tmp1_11 = -x4*tmp1_10;
    auto tmp1_12 = x4*x5;
    auto tmp1_13 = x5 + 2*tmp1_12;
    auto tmp1_14 = x1*x5;
    auto tmp1_15 = x5 + 2*tmp1_14;
    auto tmp1_16 = x5 + tmp1_7;
    auto tmp3_5 = x4*tmp1_16;
    auto tmp3_6 = tmp3_5 + tmp1_4;
    auto tmp1_17 = -x1*tmp1_10;
    auto tmp1_18 = 2*tmp1_4;
    auto tmp1_19 = -SecDecInternalQuo(13, 4)*x5;
    auto tmp1_20 = SecDecInternalQuo(9, 4)*x5;
    auto tmp1_21 = 6*tmp1_12;
    auto tmp1_22 = x4 + 1;
    auto tmp3_7 = tmp1_4*tmp1_22;
    auto tmp1_23 = x1 + 1;
    auto tmp3_8 = tmp1_4*tmp1_23;
    auto __PowCall8 = SecDecInternalSqr(x1);
    auto __PowCall9 = SecDecInternalSqr(x4);
    auto __DenominatorCall9 = SecDecInternalDenominator(x0);
    auto __DenominatorCall12 = SecDecInternalDenominator(x1);
    auto __DenominatorCall15 = SecDecInternalDenominator(x4);
    auto tmp3_9 = x5*__PowCall9;
    auto tmp3_10 = tmp1_12 + tmp3_9;
    auto _logCall1 = SecDecInternalLog(tmp1_4);
    auto _logCall2 = SecDecInternalLog(tmp1_5);
    auto __PowCall10 = SecDecInternalSqr(tmp1_5);
    auto __PowCall11 = SecDecInternalSqr(tmp1_5)*tmp1_5;
    auto __PowCall12 = SecDecInternalSqr(tmp3_3);
    auto __PowCall13 = SecDecInternalSqr(tmp3_3)*tmp3_3;
    auto __PowCall14 = SecDecInternalSqr(tmp1_5);
    auto __PowCall15 = SecDecInternalSqr(tmp1_5)*tmp1_5;
    auto __PowCall16 = SecDecInternalSqr(tmp1_5);
    auto __PowCall17 = SecDecInternalSqr(tmp1_5)*tmp1_5;
    auto __PowCall18 = SecDecInternalSqr(tmp1_5);
    auto __PowCall19 = SecDecInternalSqr(tmp1_5)*tmp1_5;
    auto __PowCall20 = SecDecInternalSqr(tmp1_5);
    auto __PowCall21 = SecDecInternalSqr(tmp1_5)*tmp1_5;
    auto __PowCall22 = SecDecInternalSqr(tmp3_1);
    auto __PowCall23 = SecDecInternalSqr(tmp3_1)*tmp3_1;
    auto __PowCall1 = SecDecInternalSqr(__PowCall10);
    auto __PowCall2 = SecDecInternalSqr(__PowCall12);
    auto __PowCall3 = SecDecInternalSqr(__PowCall14);
    auto __PowCall4 = SecDecInternalSqr(__PowCall16);
    auto __PowCall5 = SecDecInternalSqr(__PowCall18);
    auto __PowCall6 = SecDecInternalSqr(__PowCall20);
    auto __PowCall7 = SecDecInternalSqr(__PowCall22);
    auto __DenominatorCall5 = SecDecInternalDenominator(__PowCall11);
    auto __DenominatorCall6 = SecDecInternalDenominator(__PowCall13);
    auto __DenominatorCall7 = SecDecInternalDenominator(__PowCall15);
    auto __DenominatorCall8 = SecDecInternalDenominator(__PowCall17);
    auto __DenominatorCall11 = SecDecInternalDenominator(__PowCall19);
    auto __DenominatorCall14 = SecDecInternalDenominator(__PowCall21);
    auto __DenominatorCall18 = SecDecInternalDenominator(__PowCall23);
    auto tmp3_11 = tmp3_1*__PowCall7;
    auto __DenominatorCall1 = SecDecInternalDenominator(__PowCall1);
    auto __DenominatorCall2 = SecDecInternalDenominator(__PowCall2);
    auto __DenominatorCall3 = SecDecInternalDenominator(__PowCall3);
    auto __DenominatorCall4 = SecDecInternalDenominator(__PowCall4);
    auto __DenominatorCall10 = SecDecInternalDenominator(__PowCall5);
    auto __DenominatorCall13 = SecDecInternalDenominator(__PowCall6);
    auto __DenominatorCall16 = SecDecInternalDenominator(__PowCall7);
    auto __DenominatorCall17 = SecDecInternalDenominator(tmp3_11);
    auto tmp3_12 = __DenominatorCall12-_logCall2;
    auto tmp3_13 = __DenominatorCall1*tmp1_4;
    auto tmp2_12 = tmp3_12*tmp3_13;
    auto tmp2_13 = -__DenominatorCall16*tmp3_7;
    auto tmp3_14 = tmp2_13 + tmp3_13;
    auto tmp3_15 = __DenominatorCall15*tmp3_14;
    auto tmp2_14 = __DenominatorCall2*tmp1_18;
    auto tmp2_15 = __DenominatorCall3*tmp1_18;
    auto tmp2_16 = -__DenominatorCall12*__DenominatorCall13*tmp3_8;
    auto tmp3_16 = tmp3_15 + tmp2_12 + tmp2_16 + tmp2_14 + tmp2_15;
    auto tmp3_17 = tmp1_10*tmp3_16;
    auto tmp3_18 = tmp1_11*tmp1_4;
    auto tmp3_19 = tmp1_7*tmp3_10;
    auto tmp3_20 = tmp3_18-SecDecInternalQuo(3, 2)*tmp3_19;
    auto tmp3_21 = __DenominatorCall16*tmp3_20;
    auto tmp3_22 = __DenominatorCall18*tmp1_13;
    auto tmp3_23 = tmp1_7*tmp3_7*tmp1_21*__DenominatorCall17;
    auto tmp3_24 = -__DenominatorCall5*tmp1_2;
    auto tmp3_25 = tmp3_24 + tmp3_21 + SecDecInternalQuo(1, 2)*tmp3_22 + tmp3_23;
    auto tmp3_26 = __DenominatorCall15*tmp3_25;
    auto tmp3_27 = 1-tmp3_12;
    auto tmp3_28 = tmp1_2*tmp3_27;
    auto tmp3_29 = __DenominatorCall9*tmp1_1;
    auto tmp3_30 = -tmp1_3*_logCall1;
    auto tmp3_31 = -tmp3_29 + tmp3_30 + tmp3_28;
    auto tmp3_32 = __DenominatorCall5*tmp3_31;
    auto tmp3_33 = __DenominatorCall4*tmp1_4;
    auto tmp3_34 = -__DenominatorCall9*__DenominatorCall10*tmp1_4;
    auto tmp3_35 = tmp3_33 + tmp3_34;
    auto tmp3_36 = tmp1_3*tmp3_35;
    auto tmp3_37 = __DenominatorCall14*tmp1_15;
    auto tmp2_17 = __DenominatorCall13*tmp1_17*tmp1_4;
    auto tmp3_38 = SecDecInternalQuo(1, 2)*tmp3_37 + tmp2_17;
    auto tmp3_39 = __DenominatorCall12*tmp3_38;
    auto tmp3_40 = _logCall1*tmp1_20;
    auto tmp2_18 = tmp1_3*__DenominatorCall9;
    auto tmp3_41 = tmp2_18 + tmp1_19 + tmp3_40;
    auto tmp3_42 = tmp3_41*tmp3_13;
    auto tmp3_43 = __DenominatorCall8*tmp3_4;
    auto tmp3_44 = -__DenominatorCall6-__DenominatorCall7;
    auto tmp3_45 = x5*tmp3_44;
    auto tmp2_19 = __DenominatorCall4*tmp1_7*tmp1_4;
    auto tmp3_46 = __DenominatorCall11*tmp3_29;
    return(tmp3_32 + tmp3_42 + tmp3_17 + tmp3_26 + tmp3_46 + tmp3_36 + tmp3_39-SecDecInternalQuo(1, 4)*tmp3_43 + tmp3_45 + SecDecInternalQuo(3, 4)*tmp2_19);
}
#ifdef SECDEC_WITH_CUDA
__device__ secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* const device_sector_55_order_n2_integrand = sector_55_order_n2_integrand;
secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* get_device_sector_55_order_n2_integrand()
{
    using IntegrandFunction = secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction;
    IntegrandFunction* device_address_on_host;
    auto errcode = cudaMemcpyFromSymbol(&device_address_on_host,device_sector_55_order_n2_integrand, sizeof(IntegrandFunction*));
    if (errcode != cudaSuccess) throw secdecutil::cuda_error( cudaGetErrorString(errcode) );
    return device_address_on_host;
}
#endif
}
