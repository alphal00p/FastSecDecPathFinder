#include "sector_92_0.hpp"
namespace fsd_psd_double_box_integral
{
#ifdef SECDEC_WITH_CUDA
__host__ __device__
#endif
integrand_return_t sector_92_order_0_integrand
(
    real_t const * restrict const integration_variables,
    real_t const * restrict const real_parameters,
    complex_t const * restrict const complex_parameters,
    secdecutil::ResultInfo * restrict const result_info
)
{
    const auto x0 = integration_variables[0]; (void)x0;
    const auto x1 = integration_variables[1]; (void)x1;
    const auto x2 = integration_variables[2]; (void)x2;
    const auto x3 = integration_variables[3]; (void)x3;
    const auto x4 = integration_variables[4]; (void)x4;
    const auto x5 = integration_variables[5]; (void)x5;
    const auto s12 = real_parameters[0]; (void)s12;
    const auto s23 = real_parameters[1]; (void)s23;
    auto tmp1_1 = x1*x0;
    auto tmp1_2 = x1*x4;
    auto tmp1_3 = x2 + 1;
    auto tmp1_4 = tmp1_3*x4;
    auto tmp3_1 = tmp1_4 + x3;
    auto tmp1_5 = x1*x5;
    auto tmp3_2 = tmp3_1*tmp1_5;
    auto tmp3_3 = tmp1_3 + x3;
    auto tmp1_6 = tmp3_3 + x5;
    auto tmp3_4 = tmp1_6 + tmp3_2;
    auto tmp1_7 = tmp1_5*x4;
    auto tmp1_8 = tmp3_3*tmp1_7;
    auto tmp3_5 = tmp1_8 + tmp1_6;
    auto tmp1_9 = x0 + 1;
    auto tmp3_6 = tmp1_9*tmp1_6;
    auto tmp3_7 = tmp1_5*x3;
    auto tmp3_8 = tmp3_7 + tmp1_6;
    auto tmp1_10 = 4*x1;
    auto tmp1_11 = 2*x1;
    auto tmp1_12 = 6*x1;
    auto tmp1_13 = 2*tmp1_6;
    auto tmp1_14 = x4 + 2;
    auto tmp3_9 = tmp1_7 + tmp1_14;
    auto tmp3_10 = tmp3_3*tmp3_9;
    auto tmp3_11 = x5*tmp1_14;
    auto tmp3_12 = tmp3_11 + tmp3_10;
    auto tmp3_13 = SecDecInternalQuo(9, 2)*x1;
    auto tmp3_14 = SecDecInternalQuo(1, 2)*x1;
    auto tmp1_15 = 3*x1;
    auto tmp1_16 = x4 + 1;
    auto tmp3_15 = tmp1_6*tmp1_16;
    auto _logCall1 = SecDecInternalLog(tmp1_2);
    auto _logCall2 = SecDecInternalLog(tmp1_1);
    auto _logCall4 = SecDecInternalLog(x1);
    auto __PowCall4 = SecDecInternalSqr(x4);
    auto __DenominatorCall3 = SecDecInternalDenominator(x0);
    auto __DenominatorCall5 = SecDecInternalDenominator(x4);
    auto tmp3_16 = x1*__PowCall4;
    auto _logCall3 = SecDecInternalLog(tmp3_16);
    auto _logCall5 = SecDecInternalLog(tmp1_13);
    auto _logCall6 = SecDecInternalLog(tmp3_4);
    auto _logCall7 = SecDecInternalLog(tmp3_8);
    auto _logCall8 = SecDecInternalLog(tmp3_8);
    auto _logCall9 = SecDecInternalLog(tmp3_8);
    auto _logCall10 = SecDecInternalLog(tmp3_6);
    auto _logCall11 = SecDecInternalLog(tmp3_5);
    auto _logCall12 = SecDecInternalLog(tmp1_6);
    auto __PowCall1 = SecDecInternalSqr(_logCall4);
    auto __PowCall5 = SecDecInternalSqr(tmp3_4)*tmp3_4;
    auto __PowCall6 = SecDecInternalSqr(tmp3_8)*tmp3_8;
    auto __PowCall7 = SecDecInternalSqr(tmp3_8)*tmp3_8;
    auto __PowCall8 = SecDecInternalSqr(tmp3_8)*tmp3_8;
    auto __PowCall9 = SecDecInternalSqr(tmp3_4)*tmp3_4;
    auto __PowCall10 = SecDecInternalSqr(tmp3_4)*tmp3_4;
    auto __PowCall2 = SecDecInternalSqr(_logCall7);
    auto __PowCall3 = SecDecInternalSqr(_logCall12);
    auto __DenominatorCall1 = SecDecInternalDenominator(__PowCall6);
    auto __DenominatorCall2 = SecDecInternalDenominator(__PowCall8);
    auto __DenominatorCall4 = SecDecInternalDenominator(__PowCall7);
    auto __DenominatorCall6 = SecDecInternalDenominator(__PowCall5);
    auto __DenominatorCall7 = SecDecInternalDenominator(__PowCall9);
    auto __DenominatorCall8 = SecDecInternalDenominator(__PowCall10);
    auto tmp3_17 = __DenominatorCall3-_logCall7;
    auto tmp3_18 = -_logCall4*_logCall7;
    auto tmp3_19 = -_logCall3 + tmp3_17;
    auto tmp3_20 = __DenominatorCall5*tmp3_19;
    auto tmp3_21 = tmp3_20 + tmp3_18-1 + __PowCall2 + tmp3_17;
    auto tmp3_22 = tmp1_11*tmp3_21;
    auto tmp3_23 = 1 + _logCall4;
    auto tmp3_24 = tmp1_15*tmp3_23;
    auto tmp3_25 = -tmp1_12*_logCall7;
    auto tmp3_26 = tmp3_25 + tmp3_24;
    auto tmp3_27 = _logCall12*tmp3_26;
    auto tmp3_28 = _logCall12 + _logCall4;
    auto tmp3_29 = tmp1_12*tmp3_28;
    auto tmp3_30 = -_logCall2-_logCall7;
    auto tmp3_31 = tmp1_10*tmp3_30;
    auto tmp3_32 = tmp3_29 + tmp3_31;
    auto tmp3_33 = __DenominatorCall3*tmp3_32;
    auto tmp3_34 = tmp3_14*__PowCall1;
    auto tmp2_11 = tmp3_13*__PowCall3;
    auto tmp2_12 = _logCall4*x1;
    auto tmp2_13 = _logCall1 + _logCall12;
    auto tmp3_35 = tmp1_15*tmp2_13;
    auto tmp3_36 = x1 + tmp3_35;
    auto tmp3_37 = __DenominatorCall5*tmp3_36;
    auto tmp3_38 = tmp3_22 + tmp3_37 + tmp3_33 + tmp2_12 + tmp3_34 + tmp2_11 + tmp3_27;
    auto tmp3_39 = __DenominatorCall1*tmp1_6*tmp3_38;
    auto tmp3_40 = __DenominatorCall4*tmp1_6;
    auto tmp3_41 = __DenominatorCall6*tmp3_15;
    auto tmp3_42 = __DenominatorCall7*tmp3_15;
    auto tmp3_43 = -tmp3_41 + tmp3_42-tmp3_40;
    auto tmp3_44 = __DenominatorCall3*tmp3_43;
    auto tmp3_45 = _logCall6 + _logCall3;
    auto tmp3_46 = tmp3_45*tmp3_41;
    auto tmp3_47 = __DenominatorCall2*tmp1_13;
    auto tmp3_48 = -__DenominatorCall8*tmp3_12;
    auto tmp3_49 = tmp3_44 + tmp3_46 + tmp3_48 + tmp3_47;
    auto tmp3_50 = __DenominatorCall5*tmp3_49;
    auto tmp3_51 = _logCall4*tmp3_47;
    auto tmp3_52 = -__DenominatorCall3*tmp3_40;
    auto tmp3_53 = tmp3_50 + tmp3_51 + tmp3_52;
    auto tmp3_54 = tmp1_11*tmp3_53;
    auto tmp3_55 = tmp1_12*_logCall5;
    auto tmp3_56 = -1-_logCall9;
    auto tmp3_57 = tmp1_10*tmp3_56;
    auto tmp3_58 = tmp3_55 + tmp3_57;
    auto tmp3_59 = tmp3_47*tmp3_58;
    auto tmp3_60 = -_logCall10-_logCall4;
    auto tmp3_61 = tmp1_12*tmp3_60;
    auto tmp3_62 = _logCall8 + _logCall2;
    auto tmp3_63 = tmp1_10*tmp3_62;
    auto tmp3_64 = tmp3_61 + tmp3_63;
    auto tmp3_65 = __DenominatorCall3*tmp3_40*tmp3_64;
    auto tmp3_66 = -_logCall11-_logCall1;
    auto tmp3_67 = tmp1_15*tmp3_66;
    auto tmp3_68 = -x1 + tmp3_67;
    auto tmp3_69 = __DenominatorCall5*tmp3_41*tmp3_68;
    return(tmp3_39 + tmp3_65 + tmp3_69 + tmp3_54 + tmp3_59);
}
#ifdef SECDEC_WITH_CUDA
__device__ secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* const device_sector_92_order_0_integrand = sector_92_order_0_integrand;
secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* get_device_sector_92_order_0_integrand()
{
    using IntegrandFunction = secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction;
    IntegrandFunction* device_address_on_host;
    auto errcode = cudaMemcpyFromSymbol(&device_address_on_host,device_sector_92_order_0_integrand, sizeof(IntegrandFunction*));
    if (errcode != cudaSuccess) throw secdecutil::cuda_error( cudaGetErrorString(errcode) );
    return device_address_on_host;
}
#endif
}
