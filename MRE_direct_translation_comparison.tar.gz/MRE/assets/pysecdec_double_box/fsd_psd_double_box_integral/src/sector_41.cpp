#include <secdecutil/series.hpp>

#include "sector_41_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_41()
{
return {0,0,{{41,{0},6,sector_41_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_41_order_0_integrand
#endif
}},true,"eps"};
}

}
