#include "sector_22_n2.hpp"
namespace fsd_psd_double_box_integral
{
#ifdef SECDEC_WITH_CUDA
__host__ __device__
#endif
integrand_return_t sector_22_order_n2_integrand
(
    real_t const * restrict const integration_variables,
    real_t const * restrict const real_parameters,
    complex_t const * restrict const complex_parameters,
    secdecutil::ResultInfo * restrict const result_info
)
{
    const auto x0 = integration_variables[0]; (void)x0;
    const auto x1 = integration_variables[1]; (void)x1;
    const auto x2 = integration_variables[2]; (void)x2;
    const auto x3 = integration_variables[3]; (void)x3;
    const auto x4 = integration_variables[4]; (void)x4;
    const auto x5 = integration_variables[5]; (void)x5;
    const auto s12 = real_parameters[0]; (void)s12;
    const auto s23 = real_parameters[1]; (void)s23;
    auto tmp1_1 = SecDecInternalQuo(1, 2)*x4;
    auto tmp1_2 = x1*x4;
    auto tmp1_3 = SecDecInternalQuo(3, 2)*tmp1_2;
    auto tmp1_4 = 3*tmp1_2;
    auto tmp1_5 = 2*tmp1_2;
    auto tmp1_6 = SecDecInternalQuo(3, 2)*x4;
    auto tmp1_7 = SecDecInternalQuo(9, 2)*tmp1_2;
    auto tmp1_8 = tmp1_2 + x4;
    auto tmp3_1 = tmp1_8*x2;
    auto tmp1_9 = x4 + 1;
    auto tmp3_2 = tmp3_1 + tmp1_9;
    auto tmp1_10 = tmp1_2 + tmp3_2;
    auto tmp1_11 = x5*tmp1_2;
    auto tmp3_3 = tmp1_11 + tmp1_10;
    auto tmp3_4 = x3*tmp1_2;
    auto tmp3_5 = tmp3_4 + tmp1_10;
    auto tmp3_6 = tmp1_5 + tmp3_2;
    auto tmp1_12 = x2 + 1;
    auto tmp1_13 = x1 + 1;
    auto tmp1_14 = tmp1_13*tmp1_12;
    auto tmp1_15 = x1 + 2;
    auto tmp1_16 = tmp1_15*tmp1_12;
    auto tmp1_17 = x3*x4;
    auto tmp3_7 = 1 + tmp1_17;
    auto tmp1_18 = x2*x4;
    auto tmp3_8 = tmp1_18 + x4 + tmp1_15;
    auto tmp1_19 = x2 + 2;
    auto tmp1_20 = tmp1_9*tmp1_19;
    auto tmp1_21 = SecDecInternalQuo(9, 2)*x4;
    auto tmp1_22 = SecDecInternalQuo(3, 2)*x1;
    auto tmp1_23 = x5 + tmp1_12;
    auto tmp1_24 = tmp1_18 + tmp1_9;
    auto tmp1_25 = x3*tmp1_24;
    auto tmp3_9 = tmp1_25 + tmp1_12;
    auto tmp1_26 = 2*x4;
    auto tmp3_10 = tmp1_18 + 1 + tmp1_26;
    auto tmp1_27 = x5*x4;
    auto tmp3_11 = tmp1_27 + tmp1_24;
    auto tmp3_12 = x3*tmp1_26;
    auto tmp3_13 = tmp3_12 + tmp1_24;
    auto __PowCall1 = SecDecInternalSqr(x1);
    auto __PowCall2 = SecDecInternalSqr(x4);
    auto __PowCall10 = SecDecInternalSqr(x3);
    auto __DenominatorCall12 = SecDecInternalDenominator(x0);
    auto __DenominatorCall16 = SecDecInternalDenominator(x3);
    auto __DenominatorCall20 = SecDecInternalDenominator(x5);
    auto tmp3_14 = x4*__PowCall10;
    auto tmp3_15 = tmp3_9 + tmp3_14;
    auto _logCall1 = SecDecInternalLog(tmp1_10);
    auto _logCall2 = SecDecInternalLog(tmp1_14);
    auto __PowCall11 = SecDecInternalSqr(tmp1_10);
    auto __PowCall12 = SecDecInternalSqr(tmp1_10)*tmp1_10;
    auto __PowCall13 = SecDecInternalSqr(tmp1_14);
    auto __PowCall14 = SecDecInternalSqr(tmp3_6);
    auto __PowCall15 = SecDecInternalSqr(tmp3_6)*tmp3_6;
    auto __PowCall16 = SecDecInternalSqr(tmp3_6);
    auto __PowCall17 = SecDecInternalSqr(tmp3_6)*tmp3_6;
    auto __PowCall18 = SecDecInternalSqr(tmp1_10);
    auto __PowCall19 = SecDecInternalSqr(tmp1_10)*tmp1_10;
    auto __PowCall20 = SecDecInternalSqr(tmp1_10);
    auto __PowCall21 = SecDecInternalSqr(tmp1_10)*tmp1_10;
    auto __PowCall22 = SecDecInternalSqr(tmp3_5);
    auto __PowCall23 = SecDecInternalSqr(tmp3_5)*tmp3_5;
    auto __PowCall24 = SecDecInternalSqr(tmp3_3);
    auto __PowCall25 = SecDecInternalSqr(tmp3_3)*tmp3_3;
    auto __DenominatorCall24 = SecDecInternalDenominator(tmp1_14);
    auto __PowCall3 = SecDecInternalSqr(__PowCall11);
    auto __PowCall4 = SecDecInternalSqr(__PowCall14);
    auto __PowCall5 = SecDecInternalSqr(__PowCall16);
    auto __PowCall6 = SecDecInternalSqr(__PowCall18);
    auto __PowCall7 = SecDecInternalSqr(__PowCall20);
    auto __PowCall8 = SecDecInternalSqr(__PowCall22);
    auto __PowCall9 = SecDecInternalSqr(__PowCall24);
    auto __DenominatorCall7 = SecDecInternalDenominator(__PowCall12);
    auto __DenominatorCall8 = SecDecInternalDenominator(__PowCall13);
    auto __DenominatorCall9 = SecDecInternalDenominator(__PowCall15);
    auto __DenominatorCall10 = SecDecInternalDenominator(__PowCall17);
    auto __DenominatorCall11 = SecDecInternalDenominator(__PowCall19);
    auto __DenominatorCall15 = SecDecInternalDenominator(__PowCall21);
    auto __DenominatorCall19 = SecDecInternalDenominator(__PowCall23);
    auto __DenominatorCall23 = SecDecInternalDenominator(__PowCall25);
    auto tmp3_16 = tmp1_10*__PowCall3;
    auto tmp3_17 = tmp1_10*__PowCall6;
    auto tmp3_18 = tmp1_10*__PowCall7;
    auto tmp3_19 = tmp3_5*__PowCall8;
    auto tmp3_20 = tmp3_3*__PowCall9;
    auto __DenominatorCall1 = SecDecInternalDenominator(__PowCall3);
    auto __DenominatorCall2 = SecDecInternalDenominator(tmp3_16);
    auto __DenominatorCall3 = SecDecInternalDenominator(__PowCall4);
    auto __DenominatorCall4 = SecDecInternalDenominator(__PowCall5);
    auto __DenominatorCall5 = SecDecInternalDenominator(__PowCall6);
    auto __DenominatorCall6 = SecDecInternalDenominator(tmp3_17);
    auto __DenominatorCall13 = SecDecInternalDenominator(__PowCall7);
    auto __DenominatorCall14 = SecDecInternalDenominator(tmp3_18);
    auto __DenominatorCall17 = SecDecInternalDenominator(__PowCall8);
    auto __DenominatorCall18 = SecDecInternalDenominator(tmp3_19);
    auto __DenominatorCall21 = SecDecInternalDenominator(__PowCall9);
    auto __DenominatorCall22 = SecDecInternalDenominator(tmp3_20);
    auto tmp3_21 = -tmp1_24*__DenominatorCall24;
    auto tmp3_22 = __DenominatorCall8*tmp1_12*tmp1_13;
    auto tmp3_23 = tmp3_22 + tmp3_21;
    auto tmp3_24 = tmp1_22*tmp3_23;
    auto tmp3_25 = __DenominatorCall24*tmp1_13;
    auto tmp3_26 = __DenominatorCall12*x4;
    auto tmp3_27 = __DenominatorCall16*x4;
    auto tmp3_28 = -_logCall2*tmp1_6;
    auto tmp3_29 = 1 + _logCall1;
    auto tmp3_30 = x4*tmp3_29;
    auto tmp3_31 = -__DenominatorCall20*tmp1_1;
    auto tmp3_32 = tmp3_31-tmp3_27-tmp3_26 + tmp3_30 + tmp3_28-SecDecInternalQuo(3, 2)*tmp3_25 + tmp3_24;
    auto tmp3_33 = __DenominatorCall7*tmp3_32;
    auto tmp3_34 = __DenominatorCall4*tmp1_20;
    auto tmp3_35 = tmp3_8 + tmp1_13;
    auto tmp3_36 = __DenominatorCall5*tmp3_35;
    auto tmp3_37 = -1-tmp1_24;
    auto tmp3_38 = __DenominatorCall12*__DenominatorCall13*tmp3_37;
    auto tmp3_39 = -tmp3_13-tmp3_7;
    auto tmp3_40 = __DenominatorCall16*__DenominatorCall17*tmp3_39;
    auto tmp3_41 = tmp3_40 + tmp3_38 + tmp3_34 + tmp3_36;
    auto tmp3_42 = tmp1_4*tmp3_41;
    auto tmp3_43 = -__DenominatorCall6*tmp1_16;
    auto tmp3_44 = __DenominatorCall12*__DenominatorCall14*tmp1_12;
    auto tmp3_45 = __DenominatorCall16*__DenominatorCall18*tmp3_15;
    auto tmp3_46 = tmp3_45 + tmp3_43 + tmp3_44;
    auto tmp3_47 = __DenominatorCall20*__DenominatorCall22*tmp1_23;
    auto tmp3_48 = 2*tmp3_46 + tmp3_47;
    auto tmp3_49 = __DenominatorCall16 + __DenominatorCall12;
    auto tmp3_50 = 12*__DenominatorCall2;
    auto tmp3_51 = -tmp3_50*tmp3_49;
    auto tmp3_52 = -6*__DenominatorCall20-18*_logCall2 + 5 + 12*_logCall1;
    auto tmp3_53 = __DenominatorCall2*tmp3_52;
    auto tmp3_54 = tmp3_51 + tmp3_53;
    auto tmp3_55 = tmp1_12*tmp3_54;
    auto tmp3_56 = 6*tmp3_48 + tmp3_55;
    auto tmp3_57 = __PowCall1*__PowCall2*tmp3_56;
    auto tmp3_58 = _logCall2*tmp1_7;
    auto tmp3_59 = __DenominatorCall20*tmp1_3;
    auto tmp3_60 = tmp3_49-_logCall1;
    auto tmp3_61 = tmp1_4*tmp3_60;
    auto tmp3_62 = tmp3_61 + tmp3_59 + tmp3_58-tmp1_5;
    auto tmp3_63 = tmp1_24 + 1;
    auto tmp3_64 = tmp3_63*tmp3_62;
    auto tmp3_65 = tmp1_7*tmp1_13;
    auto tmp3_66 = __PowCall1*tmp1_21;
    auto tmp3_67 = tmp3_66 + tmp3_65;
    auto tmp3_68 = tmp3_67*tmp1_12*__DenominatorCall24;
    auto tmp3_69 = tmp3_68 + tmp3_64;
    auto tmp3_70 = __DenominatorCall1*tmp3_69;
    auto tmp3_71 = tmp1_1*__DenominatorCall23;
    auto tmp3_72 = -1-tmp3_11;
    auto tmp3_73 = tmp1_3*__DenominatorCall21*tmp3_72;
    auto tmp3_74 = tmp3_71 + tmp3_73;
    auto tmp3_75 = __DenominatorCall20*tmp3_74;
    auto tmp3_76 = __DenominatorCall9*tmp3_10;
    auto tmp3_77 = -__DenominatorCall10*tmp1_9;
    auto tmp3_78 = tmp1_3*__DenominatorCall3*tmp1_19;
    auto tmp2_19 = -x4*__DenominatorCall11;
    auto tmp3_79 = __DenominatorCall15*tmp3_26;
    auto tmp3_80 = __DenominatorCall19*tmp3_27;
    return(tmp3_33 + tmp3_42 + tmp3_79 + tmp3_80 + tmp3_57 + tmp3_70 + tmp3_75-SecDecInternalQuo(1, 2)*tmp3_76 + tmp3_77 + tmp3_78 + tmp2_19);
}
#ifdef SECDEC_WITH_CUDA
__device__ secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* const device_sector_22_order_n2_integrand = sector_22_order_n2_integrand;
secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* get_device_sector_22_order_n2_integrand()
{
    using IntegrandFunction = secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction;
    IntegrandFunction* device_address_on_host;
    auto errcode = cudaMemcpyFromSymbol(&device_address_on_host,device_sector_22_order_n2_integrand, sizeof(IntegrandFunction*));
    if (errcode != cudaSuccess) throw secdecutil::cuda_error( cudaGetErrorString(errcode) );
    return device_address_on_host;
}
#endif
}
