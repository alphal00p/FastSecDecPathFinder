#include <secdecutil/series.hpp>

#include "sector_77_n3.hpp"
#include "sector_77_n2.hpp"
#include "sector_77_n1.hpp"
#include "sector_77_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_77()
{
return {-3,0,{{77,{-3},3,sector_77_order_n3_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_77_order_n3_integrand
#endif
},{77,{-2},6,sector_77_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_77_order_n2_integrand
#endif
},{77,{-1},6,sector_77_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_77_order_n1_integrand
#endif
},{77,{0},6,sector_77_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_77_order_0_integrand
#endif
}},true,"eps"};
}

}
