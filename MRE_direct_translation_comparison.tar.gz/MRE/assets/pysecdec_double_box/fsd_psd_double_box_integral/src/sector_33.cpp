#include <secdecutil/series.hpp>

#include "sector_33_n3.hpp"
#include "sector_33_n2.hpp"
#include "sector_33_n1.hpp"
#include "sector_33_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_33()
{
return {-3,0,{{33,{-3},3,sector_33_order_n3_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_33_order_n3_integrand
#endif
},{33,{-2},6,sector_33_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_33_order_n2_integrand
#endif
},{33,{-1},6,sector_33_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_33_order_n1_integrand
#endif
},{33,{0},6,sector_33_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_33_order_0_integrand
#endif
}},true,"eps"};
}

}
