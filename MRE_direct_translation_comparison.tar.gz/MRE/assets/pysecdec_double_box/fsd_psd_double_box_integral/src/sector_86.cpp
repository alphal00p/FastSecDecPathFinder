#include <secdecutil/series.hpp>

#include "sector_86_n3.hpp"
#include "sector_86_n2.hpp"
#include "sector_86_n1.hpp"
#include "sector_86_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_86()
{
return {-3,0,{{86,{-3},3,sector_86_order_n3_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_86_order_n3_integrand
#endif
},{86,{-2},6,sector_86_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_86_order_n2_integrand
#endif
},{86,{-1},6,sector_86_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_86_order_n1_integrand
#endif
},{86,{0},6,sector_86_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_86_order_0_integrand
#endif
}},true,"eps"};
}

}
