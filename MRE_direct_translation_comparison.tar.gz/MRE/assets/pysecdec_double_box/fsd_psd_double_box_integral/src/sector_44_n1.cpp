#include "sector_44_n1.hpp"
namespace fsd_psd_double_box_integral
{
#ifdef SECDEC_WITH_CUDA
__host__ __device__
#endif
integrand_return_t sector_44_order_n1_integrand
(
    real_t const * restrict const integration_variables,
    real_t const * restrict const real_parameters,
    complex_t const * restrict const complex_parameters,
    secdecutil::ResultInfo * restrict const result_info
)
{
    const auto x0 = integration_variables[0]; (void)x0;
    const auto x1 = integration_variables[1]; (void)x1;
    const auto x2 = integration_variables[2]; (void)x2;
    const auto x3 = integration_variables[3]; (void)x3;
    const auto x4 = integration_variables[4]; (void)x4;
    const auto s12 = real_parameters[0]; (void)s12;
    const auto s23 = real_parameters[1]; (void)s23;
    auto tmp1_1 = x0*x1;
    auto tmp1_2 = tmp1_1*x2;
    auto tmp1_3 = tmp1_2 + 1;
    auto tmp1_4 = x3 + 1;
    auto tmp3_1 = tmp1_4*tmp1_3;
    auto tmp3_2 = x1 + x4 + tmp3_1;
    auto tmp3_3 = 3*x4*tmp1_2;
    auto tmp1_5 = x0 + 1;
    auto tmp3_4 = tmp1_4*tmp1_5;
    auto tmp3_5 = x1 + tmp3_4;
    auto tmp3_6 = x2*tmp3_5;
    auto tmp3_7 = 1 + tmp3_6;
    auto tmp1_6 = tmp1_4*tmp1_1;
    auto tmp3_8 = x4 + tmp1_4;
    auto tmp3_9 = x0*tmp3_8;
    auto tmp3_10 = x4 + tmp3_9;
    auto tmp3_11 = x2*tmp3_10;
    auto tmp3_12 = 1 + tmp3_11;
    auto tmp3_13 = tmp1_1*x4;
    auto __PowCall2 = SecDecInternalSqr(x2);
    auto tmp2_5 = tmp3_13*__PowCall2;
    auto tmp3_14 = tmp2_5 + tmp3_12;
    auto tmp2_6 = tmp1_6*__PowCall2;
    auto tmp3_15 = tmp3_7 + tmp2_6;
    auto __PowCall3 = SecDecInternalSqr(tmp3_2);
    auto __PowCall4 = SecDecInternalSqr(tmp3_2)*tmp3_2;
    auto __PowCall1 = SecDecInternalSqr(__PowCall3);
    auto __DenominatorCall2 = SecDecInternalDenominator(__PowCall4);
    auto __DenominatorCall1 = SecDecInternalDenominator(__PowCall1);
    auto tmp3_16 = tmp3_15*__DenominatorCall1*tmp3_3;
    auto tmp3_17 = -tmp3_14*__DenominatorCall2;
    return(tmp3_16 + tmp3_17);
}
#ifdef SECDEC_WITH_CUDA
__device__ secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* const device_sector_44_order_n1_integrand = sector_44_order_n1_integrand;
secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* get_device_sector_44_order_n1_integrand()
{
    using IntegrandFunction = secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction;
    IntegrandFunction* device_address_on_host;
    auto errcode = cudaMemcpyFromSymbol(&device_address_on_host,device_sector_44_order_n1_integrand, sizeof(IntegrandFunction*));
    if (errcode != cudaSuccess) throw secdecutil::cuda_error( cudaGetErrorString(errcode) );
    return device_address_on_host;
}
#endif
}
