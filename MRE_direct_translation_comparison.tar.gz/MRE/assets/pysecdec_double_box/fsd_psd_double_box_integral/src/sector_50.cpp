#include <secdecutil/series.hpp>

#include "sector_50_n2.hpp"
#include "sector_50_n1.hpp"
#include "sector_50_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_50()
{
return {-2,0,{{50,{-2},4,sector_50_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_50_order_n2_integrand
#endif
},{50,{-1},6,sector_50_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_50_order_n1_integrand
#endif
},{50,{0},6,sector_50_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_50_order_0_integrand
#endif
}},true,"eps"};
}

}
