#include "sector_57_0.hpp"
namespace fsd_psd_double_box_integral
{
#ifdef SECDEC_WITH_CUDA
__host__ __device__
#endif
integrand_return_t sector_57_order_0_integrand
(
    real_t const * restrict const integration_variables,
    real_t const * restrict const real_parameters,
    complex_t const * restrict const complex_parameters,
    secdecutil::ResultInfo * restrict const result_info
)
{
    const auto x0 = integration_variables[0]; (void)x0;
    const auto x1 = integration_variables[1]; (void)x1;
    const auto x2 = integration_variables[2]; (void)x2;
    const auto x3 = integration_variables[3]; (void)x3;
    const auto x4 = integration_variables[4]; (void)x4;
    const auto x5 = integration_variables[5]; (void)x5;
    const auto s12 = real_parameters[0]; (void)s12;
    const auto s23 = real_parameters[1]; (void)s23;
    auto tmp1_1 = x4*x3;
    auto tmp1_2 = x1 + x2;
    auto tmp1_3 = x0*x3;
    auto tmp1_4 = tmp1_3 + 1;
    auto tmp3_1 = tmp1_4*tmp1_2;
    auto tmp3_2 = tmp3_1 + 1;
    auto tmp1_5 = x3 + 1;
    auto tmp1_6 = tmp1_5*x0;
    auto tmp3_3 = tmp1_6 + tmp3_2;
    auto tmp3_4 = x0 + tmp3_2;
    auto tmp1_7 = tmp1_3*x4;
    auto tmp3_5 = tmp3_4 + tmp1_7;
    auto tmp1_8 = x3*tmp1_2;
    auto tmp3_6 = tmp1_8 + tmp1_5;
    auto tmp1_9 = 2*tmp3_6;
    auto tmp1_10 = tmp1_8 + tmp1_3;
    auto tmp1_11 = x3 + tmp1_10;
    auto tmp3_7 = x5*tmp1_11;
    auto tmp3_8 = tmp1_9 + tmp3_7;
    auto tmp3_9 = x0*tmp1_2;
    auto tmp1_12 = x0 + tmp3_9;
    auto tmp3_10 = x5*tmp1_12;
    auto tmp1_13 = 4*tmp1_3;
    auto tmp1_14 = 2*tmp1_3;
    auto tmp1_15 = 3*tmp1_3;
    auto tmp1_16 = -SecDecInternalQuo(27, 4)*tmp1_3;
    auto tmp1_17 = 6*tmp1_3;
    auto tmp1_18 = SecDecInternalQuo(9, 2)*tmp1_3;
    auto tmp3_11 = 9*tmp1_3;
    auto tmp3_12 = tmp1_8 + 1;
    auto tmp3_13 = tmp1_10*x5;
    auto tmp3_14 = tmp3_13 + tmp3_12;
    auto tmp3_15 = tmp3_9*x5;
    auto tmp1_19 = x4*tmp3_6;
    auto tmp3_16 = tmp1_19 + tmp3_12;
    auto tmp1_20 = x5*x3;
    auto tmp3_17 = tmp1_20 + tmp3_6;
    auto tmp1_21 = x4*tmp3_17;
    auto tmp3_18 = tmp1_21 + tmp3_14;
    auto tmp1_22 = x5*x0;
    auto tmp1_23 = x4*tmp1_22;
    auto tmp3_19 = tmp3_15 + tmp1_23;
    auto tmp1_24 = 2*tmp1_1;
    auto tmp1_25 = tmp1_24 + tmp3_6;
    auto tmp3_20 = tmp1_24 + tmp3_17;
    auto _logCall1 = SecDecInternalLog(tmp1_1);
    auto _logCall3 = SecDecInternalLog(x3);
    auto _logCall4 = SecDecInternalLog(x5);
    auto __PowCall8 = SecDecInternalSqr(x3);
    auto __PowCall9 = SecDecInternalSqr(x4);
    auto __PowCall10 = SecDecInternalSqr(x5);
    auto __DenominatorCall4 = SecDecInternalDenominator(x4);
    auto __DenominatorCall7 = SecDecInternalDenominator(x5);
    auto tmp2_11 = tmp1_22*__PowCall8;
    auto tmp2_12 = tmp2_11 + tmp3_20;
    auto tmp3_21 = tmp2_11 + tmp3_17;
    auto tmp2_13 = __PowCall9*x3;
    auto tmp2_14 = tmp3_19*__PowCall8;
    auto tmp3_22 = tmp2_14 + tmp2_13 + tmp3_18;
    auto tmp3_23 = tmp2_13 + tmp3_16;
    auto tmp2_15 = tmp3_15*__PowCall8;
    auto tmp3_24 = tmp2_15 + tmp3_14;
    auto tmp2_16 = tmp3_10*__PowCall8;
    auto tmp3_25 = tmp3_8 + tmp2_16;
    auto tmp2_17 = __PowCall10*x3;
    auto _logCall2 = SecDecInternalLog(tmp2_17);
    auto _logCall7 = SecDecInternalLog(tmp3_12);
    auto _logCall8 = SecDecInternalLog(tmp1_9);
    auto _logCall9 = SecDecInternalLog(tmp3_4);
    auto _logCall10 = SecDecInternalLog(tmp3_4);
    auto _logCall11 = SecDecInternalLog(tmp3_5);
    auto _logCall12 = SecDecInternalLog(tmp3_3);
    auto __PowCall1 = SecDecInternalSqr(_logCall3);
    auto __PowCall11 = SecDecInternalSqr(tmp3_4);
    auto __PowCall12 = SecDecInternalSqr(tmp3_4)*tmp3_4;
    auto __PowCall13 = SecDecInternalSqr(tmp3_4);
    auto __PowCall14 = SecDecInternalSqr(tmp3_4)*tmp3_4;
    auto __PowCall15 = SecDecInternalSqr(tmp3_5);
    auto __PowCall16 = SecDecInternalSqr(tmp3_5)*tmp3_5;
    auto __PowCall17 = SecDecInternalSqr(tmp3_3)*tmp3_3;
    auto __PowCall18 = SecDecInternalSqr(tmp3_5);
    auto __PowCall19 = SecDecInternalSqr(tmp3_5)*tmp3_5;
    auto __PowCall20 = SecDecInternalSqr(tmp3_3)*tmp3_3;
    auto _logCall5 = SecDecInternalLog(tmp3_23);
    auto _logCall6 = SecDecInternalLog(tmp3_24);
    auto __PowCall2 = SecDecInternalSqr(_logCall7);
    auto __PowCall3 = SecDecInternalSqr(_logCall10);
    auto __PowCall4 = SecDecInternalSqr(__PowCall11);
    auto __PowCall5 = SecDecInternalSqr(__PowCall13);
    auto __PowCall6 = SecDecInternalSqr(__PowCall15);
    auto __PowCall7 = SecDecInternalSqr(__PowCall18);
    auto __DenominatorCall2 = SecDecInternalDenominator(__PowCall14);
    auto __DenominatorCall3 = SecDecInternalDenominator(__PowCall17);
    auto __DenominatorCall6 = SecDecInternalDenominator(__PowCall16);
    auto __DenominatorCall10 = SecDecInternalDenominator(__PowCall12);
    auto __DenominatorCall11 = SecDecInternalDenominator(__PowCall19);
    auto __DenominatorCall12 = SecDecInternalDenominator(__PowCall20);
    auto __DenominatorCall1 = SecDecInternalDenominator(__PowCall5);
    auto __DenominatorCall5 = SecDecInternalDenominator(__PowCall6);
    auto __DenominatorCall8 = SecDecInternalDenominator(__PowCall4);
    auto __DenominatorCall9 = SecDecInternalDenominator(__PowCall7);
    auto tmp3_26 = __DenominatorCall8*tmp3_24;
    auto tmp3_27 = __DenominatorCall5*tmp3_23;
    auto tmp3_28 = __DenominatorCall1*tmp3_12;
    auto tmp3_29 = -__DenominatorCall9*tmp3_22;
    auto tmp3_30 = -tmp3_28 + tmp3_26 + tmp3_29 + tmp3_27;
    auto tmp3_31 = tmp1_15*tmp3_30;
    auto tmp3_32 = __DenominatorCall6*tmp1_25;
    auto tmp3_33 = __DenominatorCall10*tmp3_21;
    auto tmp3_34 = __DenominatorCall2*tmp3_6;
    auto tmp3_35 = __DenominatorCall11*tmp2_12;
    auto tmp3_36 = tmp3_34-tmp3_33 + tmp3_35-tmp3_32 + tmp3_31;
    auto tmp3_37 = __DenominatorCall4*tmp3_36;
    auto tmp3_38 = _logCall2 + _logCall9;
    auto tmp3_39 = SecDecInternalQuo(3, 2)*_logCall4;
    auto tmp3_40 = -1-3*_logCall6;
    auto tmp3_41 = -tmp3_39 + SecDecInternalQuo(1, 2)*tmp3_40 + tmp3_38;
    auto tmp3_42 = tmp3_41*tmp3_33;
    auto tmp3_43 = _logCall6 + _logCall4;
    auto tmp3_44 = tmp1_18*tmp3_43;
    auto tmp3_45 = -tmp1_15*tmp3_38;
    auto tmp3_46 = tmp3_45-tmp1_14 + tmp3_44;
    auto tmp3_47 = tmp3_26*tmp3_46;
    auto tmp3_48 = -_logCall7-_logCall4;
    auto tmp3_49 = tmp1_18*tmp3_48;
    auto tmp3_50 = _logCall10 + _logCall2;
    auto tmp2_18 = tmp1_15*tmp3_50;
    auto tmp3_51 = tmp2_18 + tmp1_14 + tmp3_49;
    auto tmp3_52 = tmp3_51*tmp3_28;
    auto tmp3_53 = SecDecInternalQuo(3, 2)*_logCall7 + tmp3_39 + SecDecInternalQuo(1, 2)-tmp3_50;
    auto tmp3_54 = tmp3_53*tmp3_34;
    auto tmp3_55 = __DenominatorCall3*tmp1_9;
    auto tmp3_56 = -__DenominatorCall12*tmp3_25;
    auto tmp3_57 = tmp3_37 + tmp3_54 + tmp3_52 + tmp3_42 + tmp3_56 + tmp3_55 + tmp3_47;
    auto tmp3_58 = __DenominatorCall7*tmp3_57;
    auto tmp3_59 = _logCall7*tmp3_11;
    auto tmp3_60 = tmp3_59-tmp1_13;
    auto tmp3_61 = -_logCall3*tmp1_17;
    auto tmp3_62 = tmp3_61 + tmp3_60;
    auto tmp3_63 = _logCall10*tmp3_62;
    auto tmp3_64 = _logCall3 + 1;
    auto tmp3_65 = -tmp1_13*tmp3_64;
    auto tmp3_66 = __PowCall2*tmp1_16;
    auto tmp2_19 = _logCall3*tmp3_11;
    auto tmp3_67 = tmp1_17 + tmp2_19;
    auto tmp3_68 = _logCall7*tmp3_67;
    auto tmp2_20 = __PowCall3 + __PowCall1;
    auto tmp2_21 = -tmp1_15*tmp2_20;
    auto tmp3_69 = tmp2_21 + tmp3_63 + tmp3_68 + tmp3_66 + tmp3_65;
    auto tmp3_70 = tmp3_69*tmp3_28;
    auto tmp3_71 = tmp3_11*_logCall5;
    auto tmp3_72 = -_logCall11-_logCall1;
    auto tmp3_73 = tmp1_17*tmp3_72;
    auto tmp3_74 = tmp3_73-tmp1_13 + tmp3_71;
    auto tmp3_75 = tmp3_27*tmp3_74;
    auto tmp3_76 = 2*_logCall1;
    auto tmp3_77 = tmp3_76 + 2*_logCall11-1-3*_logCall5;
    auto tmp3_78 = tmp3_77*tmp3_32;
    auto tmp3_79 = _logCall10 + _logCall1;
    auto tmp3_80 = tmp1_17*tmp3_79;
    auto tmp3_81 = tmp3_80-tmp3_60;
    auto tmp3_82 = tmp3_81*tmp3_28;
    auto tmp3_83 = 3*_logCall7;
    auto tmp3_84 = tmp3_83 + 1;
    auto tmp3_85 = -2*_logCall10-tmp3_76 + tmp3_84;
    auto tmp3_86 = tmp3_85*tmp3_34;
    auto tmp3_87 = tmp3_86 + tmp3_82 + tmp3_78 + tmp3_75;
    auto tmp3_88 = __DenominatorCall4*tmp3_87;
    auto tmp3_89 = SecDecInternalQuo(1, 2)-_logCall3;
    auto tmp3_90 = tmp3_89*tmp3_83;
    auto tmp3_91 = 2*_logCall3;
    auto tmp3_92 = tmp3_91-tmp3_84;
    auto tmp3_93 = _logCall10*tmp3_92;
    auto tmp3_94 = tmp3_93 + tmp3_90 + SecDecInternalQuo(9, 4)*__PowCall2-tmp3_64 + tmp2_20;
    auto tmp3_95 = tmp3_94*tmp3_34;
    auto tmp3_96 = -tmp3_91-2*_logCall12-2 + 3*_logCall8;
    auto tmp3_97 = tmp3_55*tmp3_96;
    return(tmp3_58 + tmp3_88 + tmp3_95 + tmp3_97 + tmp3_70);
}
#ifdef SECDEC_WITH_CUDA
__device__ secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* const device_sector_57_order_0_integrand = sector_57_order_0_integrand;
secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* get_device_sector_57_order_0_integrand()
{
    using IntegrandFunction = secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction;
    IntegrandFunction* device_address_on_host;
    auto errcode = cudaMemcpyFromSymbol(&device_address_on_host,device_sector_57_order_0_integrand, sizeof(IntegrandFunction*));
    if (errcode != cudaSuccess) throw secdecutil::cuda_error( cudaGetErrorString(errcode) );
    return device_address_on_host;
}
#endif
}
