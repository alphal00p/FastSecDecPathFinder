#include "sector_54_n4.hpp"
namespace fsd_psd_double_box_integral
{
#ifdef SECDEC_WITH_CUDA
__host__ __device__
#endif
integrand_return_t sector_54_order_n4_integrand
(
    real_t const * restrict const integration_variables,
    real_t const * restrict const real_parameters,
    complex_t const * restrict const complex_parameters,
    secdecutil::ResultInfo * restrict const result_info
)
{
    const auto x2 = integration_variables[0]; (void)x2;
    const auto x5 = integration_variables[1]; (void)x5;
    const auto s12 = real_parameters[0]; (void)s12;
    const auto s23 = real_parameters[1]; (void)s23;
    auto tmp1_1 = -SecDecInternalQuo(3, 2)*x5;
    auto tmp1_2 = x2 + 1;
    auto tmp1_3 = x5 + tmp1_2;
    auto tmp1_4 = 3*x5;
    auto __PowCall2 = SecDecInternalSqr(tmp1_3);
    auto __PowCall1 = SecDecInternalSqr(__PowCall2);
    auto tmp3_1 = tmp1_3*__PowCall1;
    auto __DenominatorCall1 = SecDecInternalDenominator(__PowCall1);
    auto __DenominatorCall2 = SecDecInternalDenominator(tmp3_1);
    auto tmp2_3 = __DenominatorCall1*tmp1_1;
    auto tmp2_4 = tmp1_2*__DenominatorCall2*tmp1_4;
    return(tmp2_3 + tmp2_4);
}
#ifdef SECDEC_WITH_CUDA
__device__ secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* const device_sector_54_order_n4_integrand = sector_54_order_n4_integrand;
secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* get_device_sector_54_order_n4_integrand()
{
    using IntegrandFunction = secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction;
    IntegrandFunction* device_address_on_host;
    auto errcode = cudaMemcpyFromSymbol(&device_address_on_host,device_sector_54_order_n4_integrand, sizeof(IntegrandFunction*));
    if (errcode != cudaSuccess) throw secdecutil::cuda_error( cudaGetErrorString(errcode) );
    return device_address_on_host;
}
#endif
}
