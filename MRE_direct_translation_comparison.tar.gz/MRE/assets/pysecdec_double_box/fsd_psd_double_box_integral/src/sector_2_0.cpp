#include "sector_2_0.hpp"
namespace fsd_psd_double_box_integral
{
#ifdef SECDEC_WITH_CUDA
__host__ __device__
#endif
integrand_return_t sector_2_order_0_integrand
(
    real_t const * restrict const integration_variables,
    real_t const * restrict const real_parameters,
    complex_t const * restrict const complex_parameters,
    secdecutil::ResultInfo * restrict const result_info
)
{
    const auto x0 = integration_variables[0]; (void)x0;
    const auto x1 = integration_variables[1]; (void)x1;
    const auto x2 = integration_variables[2]; (void)x2;
    const auto x3 = integration_variables[3]; (void)x3;
    const auto x4 = integration_variables[4]; (void)x4;
    const auto x5 = integration_variables[5]; (void)x5;
    const auto s12 = real_parameters[0]; (void)s12;
    const auto s23 = real_parameters[1]; (void)s23;
    auto tmp1_1 = x3 + 1;
    auto tmp1_2 = tmp1_1 + x4;
    auto tmp1_3 = tmp1_2*x1;
    auto tmp1_4 = x2*tmp1_3;
    auto tmp3_1 = tmp1_4 + tmp1_1;
    auto tmp3_2 = x4*x0;
    auto tmp3_3 = tmp3_2 + x1 + tmp3_1;
    auto tmp1_5 = x1 + x4;
    auto tmp3_4 = tmp3_1 + tmp1_5;
    auto tmp1_6 = x0 + 1;
    auto tmp3_5 = tmp1_2*tmp1_6;
    auto tmp3_6 = tmp1_3 + tmp3_5;
    auto tmp3_7 = x2*tmp3_6;
    auto tmp3_8 = tmp3_7 + 2 + x0 + x3 + tmp1_5;
    auto tmp3_9 = tmp3_5*x2;
    auto tmp3_10 = tmp3_9 + tmp1_6;
    auto _logCall2 = SecDecInternalLog(x2);
    auto __PowCall1 = SecDecInternalSqr(x2);
    auto __DenominatorCall3 = SecDecInternalDenominator(x5);
    auto _logCall1 = SecDecInternalLog(__PowCall1);
    auto _logCall3 = SecDecInternalLog(tmp3_3);
    auto _logCall4 = SecDecInternalLog(tmp3_4);
    auto __PowCall2 = SecDecInternalSqr(tmp3_3)*tmp3_3;
    auto __PowCall3 = SecDecInternalSqr(tmp3_3)*tmp3_3;
    auto __PowCall4 = SecDecInternalSqr(tmp3_3)*tmp3_3;
    auto __DenominatorCall1 = SecDecInternalDenominator(__PowCall2);
    auto __DenominatorCall2 = SecDecInternalDenominator(__PowCall3);
    auto __DenominatorCall4 = SecDecInternalDenominator(__PowCall4);
    auto tmp3_11 = -__DenominatorCall2*tmp3_8;
    auto tmp3_12 = __DenominatorCall3*__DenominatorCall4*tmp3_10;
    auto tmp3_13 = tmp3_11 + tmp3_12;
    auto tmp3_14 = -_logCall1 + __DenominatorCall3-_logCall3;
    auto tmp3_15 = _logCall4 + _logCall2;
    auto tmp3_16 = -1-3*tmp3_15-2*tmp3_14;
    auto tmp3_17 = __DenominatorCall1*tmp3_10*tmp3_16;
    return(2*tmp3_13 + tmp3_17);
}
#ifdef SECDEC_WITH_CUDA
__device__ secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* const device_sector_2_order_0_integrand = sector_2_order_0_integrand;
secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* get_device_sector_2_order_0_integrand()
{
    using IntegrandFunction = secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction;
    IntegrandFunction* device_address_on_host;
    auto errcode = cudaMemcpyFromSymbol(&device_address_on_host,device_sector_2_order_0_integrand, sizeof(IntegrandFunction*));
    if (errcode != cudaSuccess) throw secdecutil::cuda_error( cudaGetErrorString(errcode) );
    return device_address_on_host;
}
#endif
}
