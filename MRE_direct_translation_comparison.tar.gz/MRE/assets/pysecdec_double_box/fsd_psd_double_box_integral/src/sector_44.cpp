#include <secdecutil/series.hpp>

#include "sector_44_n1.hpp"
#include "sector_44_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_44()
{
return {-1,0,{{44,{-1},5,sector_44_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_44_order_n1_integrand
#endif
},{44,{0},6,sector_44_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_44_order_0_integrand
#endif
}},true,"eps"};
}

}
