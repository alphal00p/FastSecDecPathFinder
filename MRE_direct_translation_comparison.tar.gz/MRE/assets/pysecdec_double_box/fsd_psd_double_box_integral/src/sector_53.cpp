#include <secdecutil/series.hpp>

#include "sector_53_n4.hpp"
#include "sector_53_n3.hpp"
#include "sector_53_n2.hpp"
#include "sector_53_n1.hpp"
#include "sector_53_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_53()
{
return {-4,0,{{53,{-4},2,sector_53_order_n4_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_53_order_n4_integrand
#endif
},{53,{-3},6,sector_53_order_n3_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_53_order_n3_integrand
#endif
},{53,{-2},6,sector_53_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_53_order_n2_integrand
#endif
},{53,{-1},6,sector_53_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_53_order_n1_integrand
#endif
},{53,{0},6,sector_53_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_53_order_0_integrand
#endif
}},true,"eps"};
}

}
