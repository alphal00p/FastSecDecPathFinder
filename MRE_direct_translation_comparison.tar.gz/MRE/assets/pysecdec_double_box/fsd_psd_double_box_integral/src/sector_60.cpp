#include <secdecutil/series.hpp>

#include "sector_60_n2.hpp"
#include "sector_60_n1.hpp"
#include "sector_60_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_60()
{
return {-2,0,{{60,{-2},4,sector_60_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_60_order_n2_integrand
#endif
},{60,{-1},6,sector_60_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_60_order_n1_integrand
#endif
},{60,{0},6,sector_60_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_60_order_0_integrand
#endif
}},true,"eps"};
}

}
