#include <secdecutil/series.hpp>

#include "sector_79_n1.hpp"
#include "sector_79_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_79()
{
return {-1,0,{{79,{-1},5,sector_79_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_79_order_n1_integrand
#endif
},{79,{0},6,sector_79_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_79_order_0_integrand
#endif
}},true,"eps"};
}

}
