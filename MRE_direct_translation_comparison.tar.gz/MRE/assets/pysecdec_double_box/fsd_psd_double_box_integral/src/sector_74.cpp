#include <secdecutil/series.hpp>

#include "sector_74_n2.hpp"
#include "sector_74_n1.hpp"
#include "sector_74_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_74()
{
return {-2,0,{{74,{-2},4,sector_74_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_74_order_n2_integrand
#endif
},{74,{-1},6,sector_74_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_74_order_n1_integrand
#endif
},{74,{0},6,sector_74_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_74_order_0_integrand
#endif
}},true,"eps"};
}

}
