#include <secdecutil/series.hpp>

#include "sector_89_n4.hpp"
#include "sector_89_n3.hpp"
#include "sector_89_n2.hpp"
#include "sector_89_n1.hpp"
#include "sector_89_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_89()
{
return {-4,0,{{89,{-4},2,sector_89_order_n4_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_89_order_n4_integrand
#endif
},{89,{-3},6,sector_89_order_n3_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_89_order_n3_integrand
#endif
},{89,{-2},6,sector_89_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_89_order_n2_integrand
#endif
},{89,{-1},6,sector_89_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_89_order_n1_integrand
#endif
},{89,{0},6,sector_89_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_89_order_0_integrand
#endif
}},true,"eps"};
}

}
