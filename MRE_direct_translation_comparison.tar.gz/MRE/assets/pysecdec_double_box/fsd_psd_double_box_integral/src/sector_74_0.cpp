#include "sector_74_0.hpp"
namespace fsd_psd_double_box_integral
{
#ifdef SECDEC_WITH_CUDA
__host__ __device__
#endif
integrand_return_t sector_74_order_0_integrand
(
    real_t const * restrict const integration_variables,
    real_t const * restrict const real_parameters,
    complex_t const * restrict const complex_parameters,
    secdecutil::ResultInfo * restrict const result_info
)
{
    const auto x0 = integration_variables[0]; (void)x0;
    const auto x1 = integration_variables[1]; (void)x1;
    const auto x2 = integration_variables[2]; (void)x2;
    const auto x3 = integration_variables[3]; (void)x3;
    const auto x4 = integration_variables[4]; (void)x4;
    const auto x5 = integration_variables[5]; (void)x5;
    const auto s12 = real_parameters[0]; (void)s12;
    const auto s23 = real_parameters[1]; (void)s23;
    auto tmp1_1 = x0*x5;
    auto tmp1_2 = tmp1_1*x4;
    auto tmp1_3 = x5 + 1;
    auto tmp1_4 = tmp1_3*x3;
    auto tmp3_1 = tmp1_2 + tmp1_4;
    auto tmp1_5 = 2*x5;
    auto tmp1_6 = x4 + 1;
    auto tmp1_7 = tmp1_6 + tmp3_1 + tmp1_5;
    auto tmp1_8 = tmp1_3 + x4;
    auto tmp3_2 = tmp3_1 + tmp1_8;
    auto tmp1_9 = x1*x5;
    auto tmp3_3 = tmp1_9 + tmp3_2;
    auto tmp1_10 = x0 + 1;
    auto tmp3_4 = x3 + tmp1_8;
    auto tmp3_5 = tmp3_4*tmp1_10;
    auto tmp1_11 = tmp1_3*x4;
    auto tmp3_6 = tmp1_11 + tmp1_4;
    auto tmp3_7 = 1 + tmp1_5 + tmp3_6;
    auto tmp3_8 = x2*tmp3_7;
    auto tmp3_9 = tmp3_8 + tmp3_5;
    auto tmp1_12 = 8*x5;
    auto tmp1_13 = 4*x5;
    auto tmp1_14 = 6*x5;
    auto tmp1_15 = -SecDecInternalQuo(27, 2)*x5;
    auto tmp1_16 = 12*x5;
    auto tmp1_17 = 9*x5;
    auto tmp1_18 = 18*x5;
    auto tmp3_10 = tmp1_6 + x3;
    auto tmp3_11 = tmp3_10*tmp1_10;
    auto tmp3_12 = tmp1_1 + x5;
    auto tmp3_13 = x1*tmp3_12;
    auto tmp3_14 = tmp3_13 + tmp3_11;
    auto tmp3_15 = tmp3_6 + tmp1_3;
    auto tmp3_16 = tmp3_15*x2;
    auto tmp3_17 = tmp3_16 + tmp3_12;
    auto tmp1_19 = x1*tmp3_17;
    auto tmp3_18 = tmp1_19 + tmp3_11;
    auto tmp1_20 = x2*x5;
    auto tmp3_19 = x1*tmp1_5;
    auto tmp3_20 = tmp3_19 + tmp3_15;
    auto tmp3_21 = x2*tmp3_20;
    auto tmp3_22 = tmp3_12 + tmp3_21;
    auto _logCall2 = SecDecInternalLog(x1);
    auto _logCall3 = SecDecInternalLog(x2);
    auto __PowCall7 = SecDecInternalSqr(x1);
    auto __PowCall8 = SecDecInternalSqr(x2);
    auto __DenominatorCall4 = SecDecInternalDenominator(x1);
    auto __DenominatorCall7 = SecDecInternalDenominator(x2);
    auto tmp3_23 = __PowCall7*tmp1_20;
    auto tmp3_24 = tmp3_18 + tmp3_23;
    auto _logCall1 = SecDecInternalLog(__PowCall8);
    auto _logCall4 = SecDecInternalLog(tmp3_14);
    auto _logCall5 = SecDecInternalLog(tmp3_11);
    auto _logCall6 = SecDecInternalLog(tmp3_11);
    auto _logCall7 = SecDecInternalLog(tmp3_5);
    auto _logCall8 = SecDecInternalLog(tmp3_2);
    auto _logCall9 = SecDecInternalLog(tmp3_2);
    auto _logCall10 = SecDecInternalLog(tmp3_3);
    auto _logCall11 = SecDecInternalLog(tmp1_7);
    auto __PowCall9 = SecDecInternalSqr(tmp3_2);
    auto __PowCall10 = SecDecInternalSqr(tmp3_2)*tmp3_2;
    auto __PowCall11 = SecDecInternalSqr(tmp3_2);
    auto __PowCall12 = SecDecInternalSqr(tmp3_2)*tmp3_2;
    auto __PowCall13 = SecDecInternalSqr(tmp3_3);
    auto __PowCall14 = SecDecInternalSqr(tmp3_3)*tmp3_3;
    auto __PowCall15 = SecDecInternalSqr(tmp1_7)*tmp1_7;
    auto __PowCall16 = SecDecInternalSqr(tmp3_3);
    auto __PowCall17 = SecDecInternalSqr(tmp3_3)*tmp3_3;
    auto __PowCall18 = SecDecInternalSqr(tmp1_7)*tmp1_7;
    auto __PowCall1 = SecDecInternalSqr(_logCall6);
    auto __PowCall2 = SecDecInternalSqr(_logCall9);
    auto __PowCall3 = SecDecInternalSqr(__PowCall9);
    auto __PowCall4 = SecDecInternalSqr(__PowCall11);
    auto __PowCall5 = SecDecInternalSqr(__PowCall13);
    auto __PowCall6 = SecDecInternalSqr(__PowCall16);
    auto __DenominatorCall2 = SecDecInternalDenominator(__PowCall12);
    auto __DenominatorCall3 = SecDecInternalDenominator(__PowCall15);
    auto __DenominatorCall6 = SecDecInternalDenominator(__PowCall14);
    auto __DenominatorCall10 = SecDecInternalDenominator(__PowCall10);
    auto __DenominatorCall11 = SecDecInternalDenominator(__PowCall17);
    auto __DenominatorCall12 = SecDecInternalDenominator(__PowCall18);
    auto __DenominatorCall1 = SecDecInternalDenominator(__PowCall4);
    auto __DenominatorCall5 = SecDecInternalDenominator(__PowCall5);
    auto __DenominatorCall8 = SecDecInternalDenominator(__PowCall3);
    auto __DenominatorCall9 = SecDecInternalDenominator(__PowCall6);
    auto tmp3_25 = __DenominatorCall5*tmp3_14;
    auto tmp3_26 = __DenominatorCall8*tmp3_11;
    auto tmp3_27 = __DenominatorCall1*tmp3_11;
    auto tmp2_11 = -__DenominatorCall9*tmp3_24;
    auto tmp3_28 = -tmp3_27 + tmp3_26 + tmp2_11 + tmp3_25;
    auto tmp3_29 = tmp1_14*tmp3_28;
    auto tmp2_12 = __DenominatorCall6*tmp3_12;
    auto tmp2_13 = __DenominatorCall10*tmp3_17;
    auto tmp2_14 = __DenominatorCall11*tmp3_22;
    auto tmp3_30 = -tmp2_13 + tmp2_14-tmp2_12;
    auto tmp2_15 = __DenominatorCall2*tmp3_12;
    auto tmp2_16 = 2*tmp2_15;
    auto tmp3_31 = tmp2_16 + 2*tmp3_30 + tmp3_29;
    auto tmp3_32 = __DenominatorCall4*tmp3_31;
    auto tmp3_33 = _logCall5 + _logCall3;
    auto tmp3_34 = tmp1_17*tmp3_33;
    auto tmp2_17 = -_logCall8-_logCall1;
    auto tmp3_35 = tmp1_14*tmp2_17;
    auto tmp3_36 = tmp3_35-tmp1_13 + tmp3_34;
    auto tmp3_37 = tmp3_26*tmp3_36;
    auto tmp3_38 = __DenominatorCall3*tmp3_5;
    auto tmp3_39 = -__DenominatorCall12*tmp3_9;
    auto tmp3_40 = tmp3_39 + tmp3_38;
    auto tmp2_18 = -3*_logCall3 + 2*_logCall1;
    auto tmp2_19 = 2*_logCall8-1-3*_logCall5 + tmp2_18;
    auto tmp3_41 = tmp2_19*tmp2_13;
    auto tmp3_42 = -_logCall6-_logCall3;
    auto tmp3_43 = tmp1_17*tmp3_42;
    auto tmp2_20 = _logCall1 + _logCall9;
    auto tmp3_44 = tmp1_14*tmp2_20;
    auto tmp3_45 = tmp3_44 + tmp1_13 + tmp3_43;
    auto tmp3_46 = tmp3_45*tmp3_27;
    auto tmp3_47 = 3*_logCall6;
    auto tmp2_21 = tmp3_47 + 1;
    auto tmp2_22 = 2*_logCall9;
    auto tmp2_23 = tmp2_21-tmp2_22;
    auto tmp3_48 = -tmp2_18 + tmp2_23;
    auto tmp3_49 = tmp3_48*tmp2_15;
    auto tmp3_50 = tmp3_32 + tmp3_49 + tmp3_46 + tmp3_41 + 2*tmp3_40 + tmp3_37;
    auto tmp3_51 = __DenominatorCall7*tmp3_50;
    auto tmp3_52 = tmp1_18*_logCall4;
    auto tmp3_53 = -_logCall10-_logCall2;
    auto tmp3_54 = tmp1_16*tmp3_53;
    auto tmp3_55 = tmp3_54 + tmp3_52-tmp1_12;
    auto tmp3_56 = tmp3_25*tmp3_55;
    auto tmp3_57 = 2*_logCall2;
    auto tmp3_58 = tmp3_57 + 2*_logCall10-1-3*_logCall4;
    auto tmp3_59 = tmp3_58*tmp2_12;
    auto tmp3_60 = _logCall6*tmp1_18;
    auto tmp3_61 = tmp3_60-tmp1_12;
    auto tmp3_62 = _logCall9 + _logCall2;
    auto tmp3_63 = tmp1_16*tmp3_62;
    auto tmp3_64 = tmp3_63-tmp3_61;
    auto tmp3_65 = tmp3_64*tmp3_27;
    auto tmp3_66 = -tmp3_57 + tmp2_23;
    auto tmp3_67 = tmp3_66*tmp2_16;
    auto tmp3_68 = tmp3_67 + tmp3_65 + 2*tmp3_59 + tmp3_56;
    auto tmp3_69 = __DenominatorCall4*tmp3_68;
    auto tmp3_70 = __PowCall1*tmp1_15;
    auto tmp3_71 = _logCall6*tmp1_16;
    auto tmp3_72 = _logCall9*tmp3_61;
    auto tmp3_73 = -tmp1_14*__PowCall2;
    auto tmp3_74 = tmp3_73 + tmp3_72 + tmp3_71 + tmp3_70-tmp1_12;
    auto tmp3_75 = tmp3_74*tmp3_27;
    auto tmp3_76 = -2*_logCall11-2 + 3*_logCall7;
    auto tmp3_77 = tmp3_76*tmp3_38;
    auto tmp3_78 = -tmp2_21*tmp2_22;
    auto tmp3_79 = tmp3_78 + tmp3_47 + 2*__PowCall2-2 + SecDecInternalQuo(9, 2)*__PowCall1;
    auto tmp3_80 = tmp3_79*tmp2_15;
    return(tmp3_69 + tmp3_51 + tmp3_75 + 2*tmp3_77 + tmp3_80);
}
#ifdef SECDEC_WITH_CUDA
__device__ secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* const device_sector_74_order_0_integrand = sector_74_order_0_integrand;
secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* get_device_sector_74_order_0_integrand()
{
    using IntegrandFunction = secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction;
    IntegrandFunction* device_address_on_host;
    auto errcode = cudaMemcpyFromSymbol(&device_address_on_host,device_sector_74_order_0_integrand, sizeof(IntegrandFunction*));
    if (errcode != cudaSuccess) throw secdecutil::cuda_error( cudaGetErrorString(errcode) );
    return device_address_on_host;
}
#endif
}
