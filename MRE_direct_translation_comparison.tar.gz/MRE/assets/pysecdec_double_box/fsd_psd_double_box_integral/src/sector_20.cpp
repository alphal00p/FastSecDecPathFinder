#include <secdecutil/series.hpp>

#include "sector_20_n3.hpp"
#include "sector_20_n2.hpp"
#include "sector_20_n1.hpp"
#include "sector_20_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_20()
{
return {-3,0,{{20,{-3},3,sector_20_order_n3_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_20_order_n3_integrand
#endif
},{20,{-2},6,sector_20_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_20_order_n2_integrand
#endif
},{20,{-1},6,sector_20_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_20_order_n1_integrand
#endif
},{20,{0},6,sector_20_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_20_order_0_integrand
#endif
}},true,"eps"};
}

}
