#include <secdecutil/series.hpp>

#include "sector_3_n2.hpp"
#include "sector_3_n1.hpp"
#include "sector_3_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_3()
{
return {-2,0,{{3,{-2},4,sector_3_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_3_order_n2_integrand
#endif
},{3,{-1},6,sector_3_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_3_order_n1_integrand
#endif
},{3,{0},6,sector_3_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_3_order_0_integrand
#endif
}},true,"eps"};
}

}
