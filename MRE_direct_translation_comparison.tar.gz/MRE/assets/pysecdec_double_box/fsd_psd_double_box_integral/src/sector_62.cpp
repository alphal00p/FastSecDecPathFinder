#include <secdecutil/series.hpp>

#include "sector_62_n3.hpp"
#include "sector_62_n2.hpp"
#include "sector_62_n1.hpp"
#include "sector_62_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_62()
{
return {-3,0,{{62,{-3},3,sector_62_order_n3_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_62_order_n3_integrand
#endif
},{62,{-2},6,sector_62_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_62_order_n2_integrand
#endif
},{62,{-1},6,sector_62_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_62_order_n1_integrand
#endif
},{62,{0},6,sector_62_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_62_order_0_integrand
#endif
}},true,"eps"};
}

}
