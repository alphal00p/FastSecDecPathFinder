#include <secdecutil/series.hpp>

#include "sector_25_n1.hpp"
#include "sector_25_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_25()
{
return {-1,0,{{25,{-1},5,sector_25_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_25_order_n1_integrand
#endif
},{25,{0},6,sector_25_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_25_order_0_integrand
#endif
}},true,"eps"};
}

}
