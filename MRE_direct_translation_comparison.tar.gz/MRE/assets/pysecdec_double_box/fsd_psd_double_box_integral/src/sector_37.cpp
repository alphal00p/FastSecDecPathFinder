#include <secdecutil/series.hpp>

#include "sector_37_n1.hpp"
#include "sector_37_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_37()
{
return {-1,0,{{37,{-1},5,sector_37_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_37_order_n1_integrand
#endif
},{37,{0},6,sector_37_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_37_order_0_integrand
#endif
}},true,"eps"};
}

}
