#include <secdecutil/series.hpp>

#include "sector_23_n1.hpp"
#include "sector_23_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_23()
{
return {-1,0,{{23,{-1},5,sector_23_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_23_order_n1_integrand
#endif
},{23,{0},6,sector_23_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_23_order_0_integrand
#endif
}},true,"eps"};
}

}
