#include <secdecutil/series.hpp>

#include "sector_1_n2.hpp"
#include "sector_1_n1.hpp"
#include "sector_1_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_1()
{
return {-2,0,{{1,{-2},4,sector_1_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_1_order_n2_integrand
#endif
},{1,{-1},6,sector_1_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_1_order_n1_integrand
#endif
},{1,{0},6,sector_1_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_1_order_0_integrand
#endif
}},true,"eps"};
}

}
