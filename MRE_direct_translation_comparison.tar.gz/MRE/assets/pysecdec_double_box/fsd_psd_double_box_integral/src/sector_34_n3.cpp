#include "sector_34_n3.hpp"
namespace fsd_psd_double_box_integral
{
#ifdef SECDEC_WITH_CUDA
__host__ __device__
#endif
integrand_return_t sector_34_order_n3_integrand
(
    real_t const * restrict const integration_variables,
    real_t const * restrict const real_parameters,
    complex_t const * restrict const complex_parameters,
    secdecutil::ResultInfo * restrict const result_info
)
{
    const auto x0 = integration_variables[0]; (void)x0;
    const auto x1 = integration_variables[1]; (void)x1;
    const auto x2 = integration_variables[2]; (void)x2;
    const auto x3 = integration_variables[3]; (void)x3;
    const auto x4 = integration_variables[4]; (void)x4;
    const auto x5 = integration_variables[5]; (void)x5;
    const auto s12 = real_parameters[0]; (void)s12;
    const auto s23 = real_parameters[1]; (void)s23;
    auto tmp1_1 = 3*x4;
    auto tmp1_2 = SecDecInternalQuo(3, 4)*x4;
    auto tmp1_3 = -6*x4;
    auto tmp1_4 = SecDecInternalQuo(7, 2)*x4;
    auto tmp1_5 = SecDecInternalQuo(3, 2)*x4;
    auto tmp1_6 = SecDecInternalQuo(9, 2)*x4;
    auto tmp1_7 = x2*x4;
    auto tmp1_8 = tmp1_7 + 1;
    auto tmp1_9 = x4 + tmp1_8;
    auto tmp1_10 = x5*x4;
    auto tmp3_1 = tmp1_10 + tmp1_9;
    auto tmp1_11 = x3*x4;
    auto tmp3_2 = tmp1_11 + tmp1_9;
    auto tmp3_3 = 2*x4 + tmp1_8;
    auto tmp1_12 = x2 + 1;
    auto tmp3_4 = tmp1_7 + x4;
    auto tmp3_5 = tmp3_4*x1;
    auto tmp1_13 = x4 + tmp3_5;
    auto tmp1_14 = 2*tmp1_12;
    auto tmp1_15 = x2 + 2;
    auto tmp1_16 = x5 + tmp1_12;
    auto tmp1_17 = x3 + tmp1_12;
    auto __PowCall1 = SecDecInternalSqr(x4);
    auto __DenominatorCall11 = SecDecInternalDenominator(x0);
    auto __DenominatorCall14 = SecDecInternalDenominator(x1);
    auto __DenominatorCall18 = SecDecInternalDenominator(x3);
    auto __DenominatorCall21 = SecDecInternalDenominator(x5);
    auto _logCall1 = SecDecInternalLog(tmp1_12);
    auto _logCall2 = SecDecInternalLog(tmp1_9);
    auto __PowCall10 = SecDecInternalSqr(tmp1_12);
    auto __PowCall11 = SecDecInternalSqr(tmp1_9);
    auto __PowCall12 = SecDecInternalSqr(tmp1_9)*tmp1_9;
    auto __PowCall13 = SecDecInternalSqr(tmp3_3);
    auto __PowCall14 = SecDecInternalSqr(tmp3_3)*tmp3_3;
    auto __PowCall15 = SecDecInternalSqr(tmp3_3);
    auto __PowCall16 = SecDecInternalSqr(tmp3_3)*tmp3_3;
    auto __PowCall17 = SecDecInternalSqr(tmp1_9);
    auto __PowCall18 = SecDecInternalSqr(tmp1_9);
    auto __PowCall19 = SecDecInternalSqr(tmp1_9);
    auto __PowCall20 = SecDecInternalSqr(tmp1_9)*tmp1_9;
    auto __PowCall21 = SecDecInternalSqr(tmp3_2);
    auto __PowCall22 = SecDecInternalSqr(tmp3_1);
    auto __DenominatorCall24 = SecDecInternalDenominator(tmp1_12);
    auto __PowCall2 = SecDecInternalSqr(__PowCall11);
    auto __PowCall3 = SecDecInternalSqr(__PowCall13);
    auto __PowCall4 = SecDecInternalSqr(__PowCall15);
    auto __PowCall5 = SecDecInternalSqr(__PowCall17);
    auto __PowCall6 = SecDecInternalSqr(__PowCall18);
    auto __PowCall7 = SecDecInternalSqr(__PowCall19);
    auto __PowCall8 = SecDecInternalSqr(__PowCall21);
    auto __PowCall9 = SecDecInternalSqr(__PowCall22);
    auto __DenominatorCall7 = SecDecInternalDenominator(__PowCall10);
    auto __DenominatorCall8 = SecDecInternalDenominator(__PowCall12);
    auto __DenominatorCall9 = SecDecInternalDenominator(__PowCall14);
    auto __DenominatorCall10 = SecDecInternalDenominator(__PowCall16);
    auto __DenominatorCall17 = SecDecInternalDenominator(__PowCall20);
    auto tmp3_6 = tmp1_9*__PowCall2;
    auto tmp3_7 = tmp1_9*__PowCall5;
    auto tmp3_8 = tmp1_9*__PowCall6;
    auto tmp3_9 = tmp1_9*__PowCall7;
    auto tmp3_10 = tmp3_2*__PowCall8;
    auto tmp3_11 = tmp3_1*__PowCall9;
    auto __DenominatorCall1 = SecDecInternalDenominator(__PowCall2);
    auto __DenominatorCall2 = SecDecInternalDenominator(tmp3_6);
    auto __DenominatorCall3 = SecDecInternalDenominator(__PowCall3);
    auto __DenominatorCall4 = SecDecInternalDenominator(__PowCall4);
    auto __DenominatorCall5 = SecDecInternalDenominator(__PowCall5);
    auto __DenominatorCall6 = SecDecInternalDenominator(tmp3_7);
    auto __DenominatorCall12 = SecDecInternalDenominator(__PowCall6);
    auto __DenominatorCall13 = SecDecInternalDenominator(tmp3_8);
    auto __DenominatorCall15 = SecDecInternalDenominator(__PowCall7);
    auto __DenominatorCall16 = SecDecInternalDenominator(tmp3_9);
    auto __DenominatorCall19 = SecDecInternalDenominator(__PowCall8);
    auto __DenominatorCall20 = SecDecInternalDenominator(tmp3_10);
    auto __DenominatorCall22 = SecDecInternalDenominator(__PowCall9);
    auto __DenominatorCall23 = SecDecInternalDenominator(tmp3_11);
    auto tmp3_12 = __DenominatorCall11*__DenominatorCall12;
    auto tmp3_13 = __DenominatorCall18*__DenominatorCall19;
    auto tmp3_14 = __DenominatorCall21*__DenominatorCall22;
    auto tmp3_15 = -__DenominatorCall14*tmp1_13*__DenominatorCall16*tmp1_12;
    auto tmp3_16 = __DenominatorCall21 + __DenominatorCall18 + __DenominatorCall11-_logCall2;
    auto tmp2_12 = -__DenominatorCall1*tmp3_16;
    auto tmp3_17 = tmp2_12 + tmp3_15 + tmp3_14 + tmp3_12 + tmp3_13;
    auto tmp3_18 = tmp1_1*tmp3_17;
    auto tmp3_19 = __DenominatorCall6*tmp1_14;
    auto tmp3_20 = -__DenominatorCall11*__DenominatorCall13*tmp1_12;
    auto tmp3_21 = -__DenominatorCall18*__DenominatorCall20*tmp1_17;
    auto tmp3_22 = -__DenominatorCall21*__DenominatorCall23*tmp1_16;
    auto tmp3_23 = tmp3_22 + tmp3_21 + tmp3_19 + tmp3_20;
    auto tmp3_24 = 3*__DenominatorCall14-SecDecInternalQuo(11, 2)+9*_logCall1 + 6*tmp3_16;
    auto tmp3_25 = tmp1_12*__DenominatorCall2*tmp3_24;
    auto tmp3_26 = 6*tmp3_23 + tmp3_25;
    auto tmp3_27 = __PowCall1*tmp3_26;
    auto tmp3_28 = -__DenominatorCall3*tmp1_15;
    auto tmp3_29 = -__DenominatorCall4*tmp1_15;
    auto tmp3_30 = tmp3_28 + tmp3_29;
    auto tmp3_31 = tmp1_5*tmp3_30;
    auto tmp3_32 = __DenominatorCall17*tmp3_5;
    auto tmp3_33 = tmp1_2 + SecDecInternalQuo(3, 4)*tmp1_13;
    auto tmp3_34 = __DenominatorCall15*tmp3_33;
    auto tmp3_35 = -SecDecInternalQuo(1, 4)*tmp3_32 + tmp3_34;
    auto tmp3_36 = __DenominatorCall14*tmp3_35;
    auto tmp3_37 = -tmp1_6*_logCall1;
    auto tmp3_38 = -__DenominatorCall14*tmp1_5;
    auto tmp3_39 = tmp3_38 + tmp1_4 + tmp3_37;
    auto tmp3_40 = __DenominatorCall1*tmp3_39;
    auto tmp3_41 = __DenominatorCall8*__DenominatorCall7;
    auto tmp2_13 = -__DenominatorCall1*tmp1_6*__DenominatorCall24;
    auto tmp3_42 = -SecDecInternalQuo(3, 4)*tmp3_41 + tmp2_13;
    auto tmp3_43 = tmp1_12*tmp3_42;
    auto tmp3_44 = __DenominatorCall9 + __DenominatorCall10;
    auto tmp2_14 = tmp1_3*__DenominatorCall5;
    auto tmp2_15 = __DenominatorCall24*__DenominatorCall8;
    return(tmp3_18 + tmp3_27 + tmp3_31 + tmp3_36 + tmp3_40 + tmp3_43 + SecDecInternalQuo(1, 2)*tmp3_44 + tmp2_14 + SecDecInternalQuo(3, 2)*tmp2_15);
}
#ifdef SECDEC_WITH_CUDA
__device__ secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* const device_sector_34_order_n3_integrand = sector_34_order_n3_integrand;
secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* get_device_sector_34_order_n3_integrand()
{
    using IntegrandFunction = secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction;
    IntegrandFunction* device_address_on_host;
    auto errcode = cudaMemcpyFromSymbol(&device_address_on_host,device_sector_34_order_n3_integrand, sizeof(IntegrandFunction*));
    if (errcode != cudaSuccess) throw secdecutil::cuda_error( cudaGetErrorString(errcode) );
    return device_address_on_host;
}
#endif
}
