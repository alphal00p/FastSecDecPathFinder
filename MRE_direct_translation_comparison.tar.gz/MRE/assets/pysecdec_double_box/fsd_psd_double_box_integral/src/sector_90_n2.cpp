#include "sector_90_n2.hpp"
namespace fsd_psd_double_box_integral
{
#ifdef SECDEC_WITH_CUDA
__host__ __device__
#endif
integrand_return_t sector_90_order_n2_integrand
(
    real_t const * restrict const integration_variables,
    real_t const * restrict const real_parameters,
    complex_t const * restrict const complex_parameters,
    secdecutil::ResultInfo * restrict const result_info
)
{
    const auto x0 = integration_variables[0]; (void)x0;
    const auto x1 = integration_variables[1]; (void)x1;
    const auto x2 = integration_variables[2]; (void)x2;
    const auto x3 = integration_variables[3]; (void)x3;
    const auto x4 = integration_variables[4]; (void)x4;
    const auto x5 = integration_variables[5]; (void)x5;
    const auto s12 = real_parameters[0]; (void)s12;
    const auto s23 = real_parameters[1]; (void)s23;
    auto tmp1_1 = SecDecInternalQuo(1, 2)*x5;
    auto tmp1_2 = SecDecInternalQuo(3, 2)*x5;
    auto tmp1_3 = x2 + x1 + 1;
    auto tmp1_4 = x5 + tmp1_3;
    auto tmp1_5 = x4*x5;
    auto tmp1_6 = tmp1_5 + tmp1_4;
    auto tmp1_7 = 2*x5;
    auto tmp1_8 = tmp1_7 + tmp1_3;
    auto tmp1_9 = 3*x5;
    auto tmp1_10 = SecDecInternalQuo(9, 2)*x5;
    auto tmp3_1 = tmp1_5 + tmp1_3;
    auto tmp1_11 = x0 + 1;
    auto tmp1_12 = tmp1_3*tmp1_11;
    auto tmp1_13 = x3*tmp1_3;
    auto tmp3_2 = x5 + tmp1_13;
    auto tmp3_3 = x5*tmp1_11;
    auto tmp1_14 = x2 + x1;
    auto tmp3_4 = x3*tmp1_14;
    auto tmp3_5 = 1 + tmp3_4;
    auto tmp3_6 = x5*tmp3_5;
    auto __DenominatorCall4 = SecDecInternalDenominator(x0);
    auto __DenominatorCall7 = SecDecInternalDenominator(x3);
    auto __DenominatorCall10 = SecDecInternalDenominator(x4);
    auto _logCall1 = SecDecInternalLog(tmp1_3);
    auto _logCall2 = SecDecInternalLog(tmp1_4);
    auto __PowCall5 = SecDecInternalSqr(tmp1_4);
    auto __PowCall6 = SecDecInternalSqr(tmp1_4)*tmp1_4;
    auto __PowCall7 = SecDecInternalSqr(tmp1_8)*tmp1_8;
    auto __PowCall8 = SecDecInternalSqr(tmp1_4);
    auto __PowCall9 = SecDecInternalSqr(tmp1_4)*tmp1_4;
    auto __PowCall10 = SecDecInternalSqr(tmp1_4);
    auto __PowCall11 = SecDecInternalSqr(tmp1_4)*tmp1_4;
    auto __PowCall12 = SecDecInternalSqr(tmp1_6);
    auto __PowCall13 = SecDecInternalSqr(tmp1_6)*tmp1_6;
    auto __PowCall1 = SecDecInternalSqr(__PowCall5);
    auto __PowCall2 = SecDecInternalSqr(__PowCall8);
    auto __PowCall3 = SecDecInternalSqr(__PowCall10);
    auto __PowCall4 = SecDecInternalSqr(__PowCall12);
    auto __DenominatorCall2 = SecDecInternalDenominator(__PowCall6);
    auto __DenominatorCall3 = SecDecInternalDenominator(__PowCall7);
    auto __DenominatorCall6 = SecDecInternalDenominator(__PowCall9);
    auto __DenominatorCall9 = SecDecInternalDenominator(__PowCall11);
    auto __DenominatorCall12 = SecDecInternalDenominator(__PowCall13);
    auto __DenominatorCall1 = SecDecInternalDenominator(__PowCall1);
    auto __DenominatorCall5 = SecDecInternalDenominator(__PowCall2);
    auto __DenominatorCall8 = SecDecInternalDenominator(__PowCall3);
    auto __DenominatorCall11 = SecDecInternalDenominator(__PowCall4);
    auto tmp3_7 = __DenominatorCall10-_logCall2;
    auto tmp3_8 = tmp1_9*tmp3_7;
    auto tmp3_9 = _logCall1*tmp1_10;
    auto tmp3_10 = __DenominatorCall7 + __DenominatorCall4;
    auto tmp2_10 = tmp1_2*tmp3_10;
    auto tmp3_11 = tmp2_10-tmp1_7 + tmp3_9 + tmp3_8;
    auto tmp3_12 = __DenominatorCall1*tmp1_3*tmp3_11;
    auto tmp3_13 = -x5*tmp3_7;
    auto tmp3_14 = -1-tmp3_10;
    auto tmp3_15 = tmp1_1*tmp3_14;
    auto tmp3_16 = -tmp1_2*_logCall1;
    auto tmp3_17 = tmp3_16 + tmp3_15 + tmp3_13;
    auto tmp3_18 = __DenominatorCall2*tmp3_17;
    auto tmp3_19 = __DenominatorCall6*tmp3_3;
    auto tmp3_20 = -tmp1_2*__DenominatorCall5*tmp1_12;
    auto tmp3_21 = tmp3_20 + SecDecInternalQuo(1, 2)*tmp3_19;
    auto tmp3_22 = __DenominatorCall4*tmp3_21;
    auto tmp3_23 = __DenominatorCall8*tmp1_3*tmp3_6;
    auto tmp3_24 = __DenominatorCall9*tmp3_2;
    auto tmp3_25 = -3*tmp3_23 + tmp3_24;
    auto tmp3_26 = __DenominatorCall7*tmp3_25;
    auto tmp3_27 = x5*__DenominatorCall12;
    auto tmp2_11 = -tmp1_9*__DenominatorCall11*tmp3_1;
    auto tmp3_28 = tmp3_27 + tmp2_11;
    auto tmp3_29 = __DenominatorCall10*tmp3_28;
    auto tmp3_30 = -__DenominatorCall3*tmp1_4;
    return(tmp3_18 + tmp3_12 + tmp3_22 + SecDecInternalQuo(1, 2)*tmp3_26 + tmp3_29 + tmp3_30);
}
#ifdef SECDEC_WITH_CUDA
__device__ secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* const device_sector_90_order_n2_integrand = sector_90_order_n2_integrand;
secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* get_device_sector_90_order_n2_integrand()
{
    using IntegrandFunction = secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction;
    IntegrandFunction* device_address_on_host;
    auto errcode = cudaMemcpyFromSymbol(&device_address_on_host,device_sector_90_order_n2_integrand, sizeof(IntegrandFunction*));
    if (errcode != cudaSuccess) throw secdecutil::cuda_error( cudaGetErrorString(errcode) );
    return device_address_on_host;
}
#endif
}
