#include <secdecutil/series.hpp>

#include "sector_88_n4.hpp"
#include "sector_88_n3.hpp"
#include "sector_88_n2.hpp"
#include "sector_88_n1.hpp"
#include "sector_88_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_88()
{
return {-4,0,{{88,{-4},2,sector_88_order_n4_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_88_order_n4_integrand
#endif
},{88,{-3},6,sector_88_order_n3_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_88_order_n3_integrand
#endif
},{88,{-2},6,sector_88_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_88_order_n2_integrand
#endif
},{88,{-1},6,sector_88_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_88_order_n1_integrand
#endif
},{88,{0},6,sector_88_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_88_order_0_integrand
#endif
}},true,"eps"};
}

}
