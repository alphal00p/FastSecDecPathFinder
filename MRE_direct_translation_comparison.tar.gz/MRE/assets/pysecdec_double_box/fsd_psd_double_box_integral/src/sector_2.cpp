#include <secdecutil/series.hpp>

#include "sector_2_n1.hpp"
#include "sector_2_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_2()
{
return {-1,0,{{2,{-1},5,sector_2_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_2_order_n1_integrand
#endif
},{2,{0},6,sector_2_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_2_order_0_integrand
#endif
}},true,"eps"};
}

}
