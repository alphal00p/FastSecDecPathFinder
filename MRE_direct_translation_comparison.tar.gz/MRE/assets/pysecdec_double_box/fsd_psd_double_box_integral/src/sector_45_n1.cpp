#include "sector_45_n1.hpp"
namespace fsd_psd_double_box_integral
{
#ifdef SECDEC_WITH_CUDA
__host__ __device__
#endif
integrand_return_t sector_45_order_n1_integrand
(
    real_t const * restrict const integration_variables,
    real_t const * restrict const real_parameters,
    complex_t const * restrict const complex_parameters,
    secdecutil::ResultInfo * restrict const result_info
)
{
    const auto x0 = integration_variables[0]; (void)x0;
    const auto x1 = integration_variables[1]; (void)x1;
    const auto x2 = integration_variables[2]; (void)x2;
    const auto x3 = integration_variables[3]; (void)x3;
    const auto x4 = integration_variables[4]; (void)x4;
    const auto x5 = integration_variables[5]; (void)x5;
    const auto s12 = real_parameters[0]; (void)s12;
    const auto s23 = real_parameters[1]; (void)s23;
    auto tmp1_1 = x2 + x3;
    auto tmp1_2 = x1*x0;
    auto tmp1_3 = tmp1_2 + 1;
    auto tmp1_4 = tmp1_1*tmp1_3;
    auto tmp1_5 = x1 + 1;
    auto tmp1_6 = tmp1_4 + tmp1_5;
    auto tmp1_7 = x5*x1;
    auto tmp3_1 = tmp1_7 + tmp1_6;
    auto tmp3_2 = 1 + 2*x1 + tmp1_4;
    auto tmp1_8 = x0*tmp1_1;
    auto tmp3_3 = tmp1_3 + tmp1_8;
    auto tmp1_9 = x1*tmp1_1;
    auto tmp1_10 = 3*x1;
    auto tmp1_11 = tmp1_2 + 2 + x0 + 2*tmp1_8;
    auto tmp3_4 = tmp1_5*tmp1_1;
    auto tmp1_12 = x0 + 1;
    auto tmp1_13 = tmp1_2 + tmp1_12;
    auto tmp1_14 = 2*tmp1_12 + tmp1_8;
    auto tmp3_5 = SecDecInternalQuo(3, 2)*tmp1_2;
    auto tmp1_15 = SecDecInternalQuo(3, 2)*x1;
    auto tmp1_16 = -SecDecInternalQuo(9, 2)*x1;
    auto tmp1_17 = tmp1_8 + tmp1_12;
    auto tmp1_18 = x5 + 1;
    auto tmp3_6 = tmp1_12*tmp1_18;
    auto tmp3_7 = tmp3_6 + tmp1_8;
    auto _logCall1 = SecDecInternalLog(x0);
    auto __PowCall5 = SecDecInternalSqr(x0);
    auto __DenominatorCall6 = SecDecInternalDenominator(x4);
    auto __DenominatorCall9 = SecDecInternalDenominator(x5);
    auto tmp2_9 = tmp1_1*__PowCall5;
    auto tmp2_10 = tmp2_9 + tmp1_17;
    auto tmp2_11 = tmp2_9 + tmp3_7;
    auto tmp3_8 = tmp2_9 + tmp1_14;
    auto tmp2_12 = tmp3_4*__PowCall5;
    auto tmp3_9 = tmp2_12 + tmp1_11;
    auto tmp2_13 = tmp1_9*__PowCall5;
    auto tmp3_10 = tmp3_3 + tmp2_13;
    auto _logCall2 = SecDecInternalLog(tmp1_6);
    auto __PowCall6 = SecDecInternalSqr(tmp1_6);
    auto __PowCall7 = SecDecInternalSqr(tmp1_6)*tmp1_6;
    auto __PowCall8 = SecDecInternalSqr(tmp3_2)*tmp3_2;
    auto __PowCall9 = SecDecInternalSqr(tmp1_6);
    auto __PowCall10 = SecDecInternalSqr(tmp1_6)*tmp1_6;
    auto __PowCall11 = SecDecInternalSqr(tmp1_6);
    auto __PowCall12 = SecDecInternalSqr(tmp1_6)*tmp1_6;
    auto __PowCall13 = SecDecInternalSqr(tmp3_1);
    auto __PowCall14 = SecDecInternalSqr(tmp3_1)*tmp3_1;
    auto _logCall3 = SecDecInternalLog(tmp3_10);
    auto __PowCall1 = SecDecInternalSqr(__PowCall6);
    auto __PowCall2 = SecDecInternalSqr(__PowCall9);
    auto __PowCall3 = SecDecInternalSqr(__PowCall11);
    auto __PowCall4 = SecDecInternalSqr(__PowCall13);
    auto __DenominatorCall3 = SecDecInternalDenominator(__PowCall7);
    auto __DenominatorCall4 = SecDecInternalDenominator(__PowCall8);
    auto __DenominatorCall5 = SecDecInternalDenominator(__PowCall10);
    auto __DenominatorCall8 = SecDecInternalDenominator(__PowCall12);
    auto __DenominatorCall11 = SecDecInternalDenominator(__PowCall14);
    auto __DenominatorCall12 = SecDecInternalDenominator(tmp3_10);
    auto __DenominatorCall1 = SecDecInternalDenominator(__PowCall1);
    auto __DenominatorCall2 = SecDecInternalDenominator(__PowCall2);
    auto __DenominatorCall7 = SecDecInternalDenominator(__PowCall3);
    auto __DenominatorCall10 = SecDecInternalDenominator(__PowCall4);
    auto tmp3_11 = _logCall3*tmp1_16;
    auto tmp3_12 = -__DenominatorCall9*tmp1_15;
    auto tmp3_13 = -_logCall1 + __DenominatorCall6-_logCall2;
    auto tmp3_14 = -tmp1_10*tmp3_13;
    auto tmp3_15 = tmp3_14 + tmp3_12-x1 + tmp3_11;
    auto tmp3_16 = __DenominatorCall1*tmp3_15;
    auto tmp3_17 = __DenominatorCall3*tmp3_5*__DenominatorCall12;
    auto tmp3_18 = tmp3_16 + tmp3_17;
    auto tmp3_19 = tmp2_10*tmp3_18;
    auto tmp3_20 = __DenominatorCall11*tmp1_12;
    auto tmp3_21 = tmp1_15*__DenominatorCall10*tmp2_11;
    auto tmp3_22 = -SecDecInternalQuo(1, 2)*tmp3_20 + tmp3_21;
    auto tmp3_23 = __DenominatorCall9*tmp3_22;
    auto tmp3_24 = -__DenominatorCall2*tmp3_9;
    auto tmp3_25 = __DenominatorCall6*__DenominatorCall7*tmp2_10;
    auto tmp3_26 = tmp3_24 + tmp3_25;
    auto tmp3_27 = tmp1_10*tmp3_26;
    auto tmp3_28 = __DenominatorCall4*tmp3_8;
    auto tmp3_29 = __DenominatorCall5*tmp1_13;
    auto tmp3_30 = -__DenominatorCall6*__DenominatorCall8*tmp1_12;
    auto tmp3_31 = SecDecInternalQuo(1, 2)*__DenominatorCall9 + SecDecInternalQuo(3, 2)*_logCall3 + tmp3_13;
    auto tmp3_32 = __DenominatorCall3*tmp1_12*tmp3_31;
    return(tmp3_19 + tmp3_23 + tmp3_32 + tmp3_27 + SecDecInternalQuo(1, 2)*tmp3_28 + tmp3_29 + tmp3_30);
}
#ifdef SECDEC_WITH_CUDA
__device__ secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* const device_sector_45_order_n1_integrand = sector_45_order_n1_integrand;
secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* get_device_sector_45_order_n1_integrand()
{
    using IntegrandFunction = secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction;
    IntegrandFunction* device_address_on_host;
    auto errcode = cudaMemcpyFromSymbol(&device_address_on_host,device_sector_45_order_n1_integrand, sizeof(IntegrandFunction*));
    if (errcode != cudaSuccess) throw secdecutil::cuda_error( cudaGetErrorString(errcode) );
    return device_address_on_host;
}
#endif
}
