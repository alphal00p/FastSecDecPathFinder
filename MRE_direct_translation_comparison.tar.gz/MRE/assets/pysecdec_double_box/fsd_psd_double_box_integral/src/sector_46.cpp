#include <secdecutil/series.hpp>

#include "sector_46_n1.hpp"
#include "sector_46_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_46()
{
return {-1,0,{{46,{-1},5,sector_46_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_46_order_n1_integrand
#endif
},{46,{0},6,sector_46_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_46_order_0_integrand
#endif
}},true,"eps"};
}

}
