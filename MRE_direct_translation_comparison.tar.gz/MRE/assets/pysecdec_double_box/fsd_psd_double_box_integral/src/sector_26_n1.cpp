#include "sector_26_n1.hpp"
namespace fsd_psd_double_box_integral
{
#ifdef SECDEC_WITH_CUDA
__host__ __device__
#endif
integrand_return_t sector_26_order_n1_integrand
(
    real_t const * restrict const integration_variables,
    real_t const * restrict const real_parameters,
    complex_t const * restrict const complex_parameters,
    secdecutil::ResultInfo * restrict const result_info
)
{
    const auto x0 = integration_variables[0]; (void)x0;
    const auto x1 = integration_variables[1]; (void)x1;
    const auto x2 = integration_variables[2]; (void)x2;
    const auto x3 = integration_variables[3]; (void)x3;
    const auto x4 = integration_variables[4]; (void)x4;
    const auto x5 = integration_variables[5]; (void)x5;
    const auto s12 = real_parameters[0]; (void)s12;
    const auto s23 = real_parameters[1]; (void)s23;
    auto tmp1_1 = x2 + x3;
    auto tmp1_2 = x1 + 1;
    auto tmp1_3 = tmp1_1*tmp1_2;
    auto tmp3_1 = tmp1_3 + 1;
    auto tmp1_4 = x4 + tmp3_1;
    auto tmp1_5 = x4*x1;
    auto tmp1_6 = x5*tmp1_5;
    auto tmp3_2 = tmp1_6 + tmp1_4;
    auto tmp1_7 = x4 + tmp1_1;
    auto tmp3_3 = tmp1_2*tmp1_7;
    auto tmp3_4 = 1 + tmp3_3;
    auto tmp1_8 = SecDecInternalQuo(3, 2)*tmp1_5;
    auto tmp1_9 = 1 + 2*x1;
    auto tmp3_5 = tmp1_9*tmp1_1;
    auto tmp3_6 = 2 + tmp3_5;
    auto tmp1_10 = x3*x1;
    auto tmp1_11 = x2*x1;
    auto tmp3_7 = tmp1_11 + tmp1_10 + 1;
    auto tmp3_8 = tmp1_5 + tmp3_7;
    auto tmp1_12 = 2*tmp3_8;
    auto tmp1_13 = SecDecInternalQuo(1, 4)*tmp1_5;
    auto tmp1_14 = SecDecInternalQuo(9, 4)*tmp1_5;
    auto tmp1_15 = x5*tmp3_8;
    auto tmp3_9 = tmp1_15 + tmp3_7;
    auto tmp1_16 = 2*x5 + 1;
    auto tmp3_10 = tmp1_5*tmp1_16;
    auto tmp3_11 = tmp3_10 + tmp3_7;
    auto tmp3_12 = x4*tmp1_9;
    auto tmp3_13 = tmp3_12 + tmp3_7;
    auto tmp3_14 = x4*tmp1_2;
    auto _logCall2 = SecDecInternalLog(x1);
    auto __PowCall5 = SecDecInternalSqr(x1);
    auto __PowCall6 = SecDecInternalSqr(x5);
    auto __DenominatorCall6 = SecDecInternalDenominator(x0);
    auto __DenominatorCall9 = SecDecInternalDenominator(x5);
    auto tmp3_15 = __PowCall6*tmp1_5;
    auto tmp3_16 = tmp3_9 + tmp3_15;
    auto _logCall1 = SecDecInternalLog(__PowCall5);
    auto _logCall3 = SecDecInternalLog(tmp1_4);
    auto _logCall4 = SecDecInternalLog(tmp3_1);
    auto __PowCall7 = SecDecInternalSqr(tmp1_4);
    auto __PowCall8 = SecDecInternalSqr(tmp1_4)*tmp1_4;
    auto __PowCall9 = SecDecInternalSqr(tmp3_4)*tmp3_4;
    auto __PowCall10 = SecDecInternalSqr(tmp1_4);
    auto __PowCall11 = SecDecInternalSqr(tmp1_4)*tmp1_4;
    auto __PowCall12 = SecDecInternalSqr(tmp1_4);
    auto __PowCall13 = SecDecInternalSqr(tmp1_4)*tmp1_4;
    auto __PowCall14 = SecDecInternalSqr(tmp3_2);
    auto __PowCall15 = SecDecInternalSqr(tmp3_2)*tmp3_2;
    auto __DenominatorCall12 = SecDecInternalDenominator(tmp3_1);
    auto __PowCall1 = SecDecInternalSqr(__PowCall7);
    auto __PowCall2 = SecDecInternalSqr(__PowCall10);
    auto __PowCall3 = SecDecInternalSqr(__PowCall12);
    auto __PowCall4 = SecDecInternalSqr(__PowCall14);
    auto __DenominatorCall3 = SecDecInternalDenominator(__PowCall8);
    auto __DenominatorCall4 = SecDecInternalDenominator(__PowCall9);
    auto __DenominatorCall5 = SecDecInternalDenominator(__PowCall11);
    auto __DenominatorCall8 = SecDecInternalDenominator(__PowCall13);
    auto __DenominatorCall11 = SecDecInternalDenominator(__PowCall15);
    auto __DenominatorCall1 = SecDecInternalDenominator(__PowCall1);
    auto __DenominatorCall2 = SecDecInternalDenominator(__PowCall2);
    auto __DenominatorCall7 = SecDecInternalDenominator(__PowCall3);
    auto __DenominatorCall10 = SecDecInternalDenominator(__PowCall4);
    auto tmp3_17 = _logCall4 + _logCall2;
    auto tmp3_18 = -__DenominatorCall9-__DenominatorCall6 + _logCall3 + _logCall1;
    auto tmp3_19 = -SecDecInternalQuo(1, 2)-tmp3_18 + SecDecInternalQuo(3, 2)*tmp3_17;
    auto tmp3_20 = tmp3_8*tmp3_19;
    auto tmp3_21 = tmp3_7*__DenominatorCall12*tmp3_14;
    auto tmp3_22 = tmp3_20 + SecDecInternalQuo(3, 2)*tmp3_21;
    auto tmp3_23 = __DenominatorCall3*tmp3_22;
    auto tmp3_24 = __DenominatorCall4*tmp1_12;
    auto tmp3_25 = __DenominatorCall5*tmp3_13;
    auto tmp3_26 = -__DenominatorCall6*__DenominatorCall8*tmp3_8;
    auto tmp3_27 = -__DenominatorCall9*__DenominatorCall11*tmp3_11;
    auto tmp3_28 = tmp3_23 + tmp3_27 + tmp3_26 + tmp3_24 + tmp3_25;
    auto tmp3_29 = -__DenominatorCall2*tmp3_6;
    auto tmp3_30 = __DenominatorCall6*__DenominatorCall7*tmp3_7;
    auto tmp3_31 = __DenominatorCall9*__DenominatorCall10*tmp3_16;
    auto tmp3_32 = tmp3_31 + tmp3_29 + tmp3_30;
    auto tmp3_33 = tmp1_8*tmp3_32;
    auto tmp3_34 = -tmp1_14*tmp3_17;
    auto tmp3_35 = tmp1_8*tmp3_18;
    auto tmp3_36 = tmp3_35 + tmp1_13 + tmp3_34;
    auto tmp3_37 = tmp3_7*__DenominatorCall1*tmp3_36;
    return(tmp3_37 + SecDecInternalQuo(1, 2)*tmp3_28 + tmp3_33);
}
#ifdef SECDEC_WITH_CUDA
__device__ secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* const device_sector_26_order_n1_integrand = sector_26_order_n1_integrand;
secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* get_device_sector_26_order_n1_integrand()
{
    using IntegrandFunction = secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction;
    IntegrandFunction* device_address_on_host;
    auto errcode = cudaMemcpyFromSymbol(&device_address_on_host,device_sector_26_order_n1_integrand, sizeof(IntegrandFunction*));
    if (errcode != cudaSuccess) throw secdecutil::cuda_error( cudaGetErrorString(errcode) );
    return device_address_on_host;
}
#endif
}
