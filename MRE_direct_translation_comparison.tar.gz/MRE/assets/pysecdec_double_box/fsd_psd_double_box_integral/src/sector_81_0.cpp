#include "sector_81_0.hpp"
namespace fsd_psd_double_box_integral
{
#ifdef SECDEC_WITH_CUDA
__host__ __device__
#endif
integrand_return_t sector_81_order_0_integrand
(
    real_t const * restrict const integration_variables,
    real_t const * restrict const real_parameters,
    complex_t const * restrict const complex_parameters,
    secdecutil::ResultInfo * restrict const result_info
)
{
    const auto x0 = integration_variables[0]; (void)x0;
    const auto x1 = integration_variables[1]; (void)x1;
    const auto x2 = integration_variables[2]; (void)x2;
    const auto x3 = integration_variables[3]; (void)x3;
    const auto x4 = integration_variables[4]; (void)x4;
    const auto x5 = integration_variables[5]; (void)x5;
    const auto s12 = real_parameters[0]; (void)s12;
    const auto s23 = real_parameters[1]; (void)s23;
    auto tmp1_1 = x3 + x2;
    auto tmp1_2 = x4*x0;
    auto tmp3_1 = tmp1_1 + tmp1_2;
    auto tmp3_2 = tmp3_1*x5;
    auto tmp3_3 = tmp1_1 + x4;
    auto tmp1_3 = 1 + tmp3_3;
    auto tmp3_4 = tmp1_3 + tmp3_2;
    auto tmp1_4 = 2*x5;
    auto tmp1_5 = -3*x5;
    auto tmp1_6 = x0 + 1;
    auto tmp1_7 = tmp1_6*tmp1_3;
    auto tmp3_5 = tmp1_6 + x1;
    auto tmp3_6 = tmp3_5*tmp1_3;
    auto tmp3_7 = x5*x1*tmp3_3;
    auto tmp3_8 = tmp3_7 + tmp3_6;
    auto _logCall1 = SecDecInternalLog(x5);
    auto __DenominatorCall2 = SecDecInternalDenominator(x1);
    auto _logCall2 = SecDecInternalLog(tmp1_7);
    auto _logCall3 = SecDecInternalLog(tmp3_4);
    auto __PowCall1 = SecDecInternalSqr(tmp3_4)*tmp3_4;
    auto __PowCall2 = SecDecInternalSqr(tmp3_4)*tmp3_4;
    auto __DenominatorCall1 = SecDecInternalDenominator(__PowCall1);
    auto __DenominatorCall3 = SecDecInternalDenominator(__PowCall2);
    auto tmp3_9 = __DenominatorCall2*x5;
    auto tmp2_4 = _logCall3*tmp1_4;
    auto tmp2_5 = _logCall2*tmp1_5;
    auto tmp2_6 = -_logCall1*x5;
    auto tmp3_10 = tmp2_6 + tmp2_5-tmp3_9 + tmp2_4;
    auto tmp3_11 = tmp3_10*tmp1_7*__DenominatorCall1;
    auto tmp3_12 = tmp3_8*__DenominatorCall3*tmp3_9;
    return(tmp3_12 + tmp3_11);
}
#ifdef SECDEC_WITH_CUDA
__device__ secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* const device_sector_81_order_0_integrand = sector_81_order_0_integrand;
secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* get_device_sector_81_order_0_integrand()
{
    using IntegrandFunction = secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction;
    IntegrandFunction* device_address_on_host;
    auto errcode = cudaMemcpyFromSymbol(&device_address_on_host,device_sector_81_order_0_integrand, sizeof(IntegrandFunction*));
    if (errcode != cudaSuccess) throw secdecutil::cuda_error( cudaGetErrorString(errcode) );
    return device_address_on_host;
}
#endif
}
