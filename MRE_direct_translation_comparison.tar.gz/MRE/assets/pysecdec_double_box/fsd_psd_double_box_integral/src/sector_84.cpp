#include <secdecutil/series.hpp>

#include "sector_84_n1.hpp"
#include "sector_84_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_84()
{
return {-1,0,{{84,{-1},5,sector_84_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_84_order_n1_integrand
#endif
},{84,{0},6,sector_84_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_84_order_0_integrand
#endif
}},true,"eps"};
}

}
