#include <secdecutil/series.hpp>

#include "sector_94_n2.hpp"
#include "sector_94_n1.hpp"
#include "sector_94_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_94()
{
return {-2,0,{{94,{-2},4,sector_94_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_94_order_n2_integrand
#endif
},{94,{-1},6,sector_94_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_94_order_n1_integrand
#endif
},{94,{0},6,sector_94_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_94_order_0_integrand
#endif
}},true,"eps"};
}

}
