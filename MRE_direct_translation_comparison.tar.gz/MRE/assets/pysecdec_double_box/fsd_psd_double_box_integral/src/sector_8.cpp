#include <secdecutil/series.hpp>

#include "sector_8_n2.hpp"
#include "sector_8_n1.hpp"
#include "sector_8_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_8()
{
return {-2,0,{{8,{-2},4,sector_8_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_8_order_n2_integrand
#endif
},{8,{-1},6,sector_8_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_8_order_n1_integrand
#endif
},{8,{0},6,sector_8_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_8_order_0_integrand
#endif
}},true,"eps"};
}

}
