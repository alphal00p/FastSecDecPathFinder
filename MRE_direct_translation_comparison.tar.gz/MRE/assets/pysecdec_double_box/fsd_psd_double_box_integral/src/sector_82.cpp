#include <secdecutil/series.hpp>

#include "sector_82_n2.hpp"
#include "sector_82_n1.hpp"
#include "sector_82_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_82()
{
return {-2,0,{{82,{-2},4,sector_82_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_82_order_n2_integrand
#endif
},{82,{-1},6,sector_82_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_82_order_n1_integrand
#endif
},{82,{0},6,sector_82_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_82_order_0_integrand
#endif
}},true,"eps"};
}

}
