#include "sector_38_n2.hpp"
namespace fsd_psd_double_box_integral
{
#ifdef SECDEC_WITH_CUDA
__host__ __device__
#endif
integrand_return_t sector_38_order_n2_integrand
(
    real_t const * restrict const integration_variables,
    real_t const * restrict const real_parameters,
    complex_t const * restrict const complex_parameters,
    secdecutil::ResultInfo * restrict const result_info
)
{
    const auto x0 = integration_variables[0]; (void)x0;
    const auto x1 = integration_variables[1]; (void)x1;
    const auto x2 = integration_variables[2]; (void)x2;
    const auto x3 = integration_variables[3]; (void)x3;
    const auto x4 = integration_variables[4]; (void)x4;
    const auto x5 = integration_variables[5]; (void)x5;
    const auto s12 = real_parameters[0]; (void)s12;
    const auto s23 = real_parameters[1]; (void)s23;
    auto tmp1_1 = x0*x4;
    auto tmp1_2 = 3*tmp1_1;
    auto tmp1_3 = SecDecInternalQuo(1, 2)*x4;
    auto tmp1_4 = SecDecInternalQuo(1, 2)*tmp1_1;
    auto tmp1_5 = SecDecInternalQuo(3, 2)*tmp1_1;
    auto tmp1_6 = SecDecInternalQuo(3, 2)*x4;
    auto tmp1_7 = SecDecInternalQuo(9, 2)*tmp1_1;
    auto tmp1_8 = tmp1_1 + x4;
    auto tmp3_1 = tmp1_8*x2;
    auto tmp1_9 = x4 + 1;
    auto tmp3_2 = tmp3_1 + tmp1_9;
    auto tmp1_10 = tmp1_1 + tmp3_2;
    auto tmp1_11 = x5*tmp1_1;
    auto tmp3_3 = tmp1_11 + tmp1_10;
    auto tmp1_12 = x3*tmp1_1;
    auto tmp3_4 = tmp1_12 + tmp1_10;
    auto tmp3_5 = 2*tmp1_1 + tmp3_2;
    auto tmp3_6 = x0 + 1;
    auto tmp3_7 = tmp3_6*x1;
    auto tmp1_13 = x4 + tmp3_7;
    auto tmp1_14 = 2*x4;
    auto tmp1_15 = x2*x4;
    auto tmp1_16 = tmp1_15 + 1 + tmp1_14;
    auto tmp3_8 = tmp1_15 + tmp1_9;
    auto tmp1_17 = x5*x4;
    auto tmp3_9 = tmp1_17 + tmp3_8;
    auto tmp3_10 = x3*tmp1_14;
    auto tmp3_11 = tmp3_10 + tmp3_8;
    auto tmp1_18 = x2 + 2;
    auto tmp1_19 = tmp1_9*tmp1_18;
    auto tmp1_20 = x2 + 1;
    auto tmp1_21 = x5 + tmp1_20;
    auto tmp1_22 = x3*tmp3_8;
    auto tmp3_12 = tmp1_22 + tmp1_20;
    auto tmp1_23 = x3*x4;
    auto tmp3_13 = 1 + tmp1_23;
    auto tmp3_14 = tmp1_20*tmp3_7;
    auto tmp3_15 = 1 + tmp3_14;
    auto __PowCall1 = SecDecInternalSqr(x0);
    auto __PowCall2 = SecDecInternalSqr(x4);
    auto __PowCall9 = SecDecInternalSqr(x3);
    auto __DenominatorCall8 = SecDecInternalDenominator(x1);
    auto __DenominatorCall12 = SecDecInternalDenominator(x3);
    auto __DenominatorCall16 = SecDecInternalDenominator(x5);
    auto tmp3_16 = x4*__PowCall9;
    auto tmp3_17 = tmp3_12 + tmp3_16;
    auto _logCall1 = SecDecInternalLog(tmp1_20);
    auto _logCall2 = SecDecInternalLog(tmp1_10);
    auto __PowCall10 = SecDecInternalSqr(tmp1_10);
    auto __PowCall11 = SecDecInternalSqr(tmp1_10)*tmp1_10;
    auto __PowCall12 = SecDecInternalSqr(tmp3_5);
    auto __PowCall13 = SecDecInternalSqr(tmp3_5)*tmp3_5;
    auto __PowCall14 = SecDecInternalSqr(tmp3_5);
    auto __PowCall15 = SecDecInternalSqr(tmp3_5)*tmp3_5;
    auto __PowCall16 = SecDecInternalSqr(tmp1_10);
    auto __PowCall17 = SecDecInternalSqr(tmp1_10)*tmp1_10;
    auto __PowCall18 = SecDecInternalSqr(tmp3_4);
    auto __PowCall19 = SecDecInternalSqr(tmp3_4)*tmp3_4;
    auto __PowCall20 = SecDecInternalSqr(tmp3_3);
    auto __PowCall21 = SecDecInternalSqr(tmp3_3)*tmp3_3;
    auto __DenominatorCall20 = SecDecInternalDenominator(tmp1_20);
    auto __PowCall3 = SecDecInternalSqr(__PowCall10);
    auto __PowCall4 = SecDecInternalSqr(__PowCall12);
    auto __PowCall5 = SecDecInternalSqr(__PowCall14);
    auto __PowCall6 = SecDecInternalSqr(__PowCall16);
    auto __PowCall7 = SecDecInternalSqr(__PowCall18);
    auto __PowCall8 = SecDecInternalSqr(__PowCall20);
    auto __DenominatorCall5 = SecDecInternalDenominator(__PowCall11);
    auto __DenominatorCall6 = SecDecInternalDenominator(__PowCall13);
    auto __DenominatorCall7 = SecDecInternalDenominator(__PowCall15);
    auto __DenominatorCall11 = SecDecInternalDenominator(__PowCall17);
    auto __DenominatorCall15 = SecDecInternalDenominator(__PowCall19);
    auto __DenominatorCall19 = SecDecInternalDenominator(__PowCall21);
    auto tmp3_18 = tmp1_10*__PowCall3;
    auto tmp3_19 = tmp1_10*__PowCall6;
    auto tmp3_20 = tmp3_4*__PowCall7;
    auto tmp3_21 = tmp3_3*__PowCall8;
    auto __DenominatorCall1 = SecDecInternalDenominator(__PowCall3);
    auto __DenominatorCall2 = SecDecInternalDenominator(tmp3_18);
    auto __DenominatorCall3 = SecDecInternalDenominator(__PowCall4);
    auto __DenominatorCall4 = SecDecInternalDenominator(__PowCall5);
    auto __DenominatorCall9 = SecDecInternalDenominator(__PowCall6);
    auto __DenominatorCall10 = SecDecInternalDenominator(tmp3_19);
    auto __DenominatorCall13 = SecDecInternalDenominator(__PowCall7);
    auto __DenominatorCall14 = SecDecInternalDenominator(tmp3_20);
    auto __DenominatorCall17 = SecDecInternalDenominator(__PowCall8);
    auto __DenominatorCall18 = SecDecInternalDenominator(tmp3_21);
    auto tmp3_22 = tmp3_8 + 1;
    auto tmp3_23 = -_logCall2 + __DenominatorCall16 + __DenominatorCall12;
    auto tmp3_24 = __DenominatorCall1*tmp3_22*tmp3_23;
    auto tmp3_25 = __DenominatorCall3*tmp1_18;
    auto tmp3_26 = __DenominatorCall4*tmp1_19;
    auto tmp3_27 = -tmp3_13-tmp3_11;
    auto tmp3_28 = __DenominatorCall12*__DenominatorCall13*tmp3_27;
    auto tmp3_29 = -1-tmp3_9;
    auto tmp3_30 = __DenominatorCall16*__DenominatorCall17*tmp3_29;
    auto tmp3_31 = tmp3_24 + tmp3_30 + tmp3_28 + tmp3_25 + tmp3_26;
    auto tmp3_32 = tmp1_2*tmp3_31;
    auto tmp3_33 = __DenominatorCall2*tmp1_20;
    auto tmp3_34 = __DenominatorCall14*tmp3_17;
    auto tmp3_35 = tmp3_34-tmp3_33;
    auto tmp3_36 = __DenominatorCall12*tmp3_35;
    auto tmp3_37 = __DenominatorCall18*tmp1_21;
    auto tmp3_38 = tmp3_37-tmp3_33;
    auto tmp3_39 = __DenominatorCall16*tmp3_38;
    auto tmp3_40 = tmp3_36 + tmp3_39;
    auto tmp3_41 = 12*_logCall2 + 17-18*_logCall1;
    auto tmp3_42 = tmp3_41*tmp3_33;
    auto tmp3_43 = __DenominatorCall10*tmp1_20;
    auto tmp3_44 = tmp3_43-tmp3_33;
    auto tmp3_45 = __DenominatorCall8*tmp3_44;
    auto tmp3_46 = tmp3_42 + 6*tmp3_45 + 12*tmp3_40;
    auto tmp3_47 = __PowCall2*__PowCall1*tmp3_46;
    auto tmp3_48 = -_logCall1*tmp1_6;
    auto tmp3_49 = x4*_logCall2;
    auto tmp3_50 = tmp3_8*__DenominatorCall20;
    auto tmp3_51 = -SecDecInternalQuo(3, 2)*tmp3_50 + tmp3_49 + tmp1_3 + tmp3_48;
    auto tmp3_52 = __DenominatorCall5*tmp3_51;
    auto tmp3_53 = __DenominatorCall11*tmp1_13;
    auto tmp3_54 = -tmp3_15-tmp3_8;
    auto tmp3_55 = tmp1_5*__DenominatorCall9*tmp3_54;
    auto tmp3_56 = -__DenominatorCall5*tmp1_3;
    auto tmp3_57 = tmp3_56 + SecDecInternalQuo(1, 2)*tmp3_53 + tmp3_55;
    auto tmp3_58 = __DenominatorCall8*tmp3_57;
    auto tmp3_59 = __DenominatorCall5*x4;
    auto tmp3_60 = x4*__DenominatorCall15;
    auto tmp3_61 = tmp3_60-tmp3_59;
    auto tmp3_62 = __DenominatorCall12*tmp3_61;
    auto tmp3_63 = x4*__DenominatorCall19;
    auto tmp3_64 = tmp3_63-tmp3_59;
    auto tmp3_65 = __DenominatorCall16*tmp3_64;
    auto tmp3_66 = _logCall1*tmp1_7;
    auto tmp3_67 = __DenominatorCall8*tmp1_5;
    auto tmp3_68 = tmp3_67 + tmp3_66-tmp1_4;
    auto tmp3_69 = __DenominatorCall1*tmp3_22*tmp3_68;
    auto tmp3_70 = -__DenominatorCall6*tmp1_16;
    auto tmp3_71 = -__DenominatorCall7*tmp1_9;
    return(tmp3_69 + tmp3_32 + tmp3_47 + tmp3_52 + tmp3_58 + tmp3_65 + tmp3_62 + tmp3_70 + tmp3_71);
}
#ifdef SECDEC_WITH_CUDA
__device__ secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* const device_sector_38_order_n2_integrand = sector_38_order_n2_integrand;
secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* get_device_sector_38_order_n2_integrand()
{
    using IntegrandFunction = secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction;
    IntegrandFunction* device_address_on_host;
    auto errcode = cudaMemcpyFromSymbol(&device_address_on_host,device_sector_38_order_n2_integrand, sizeof(IntegrandFunction*));
    if (errcode != cudaSuccess) throw secdecutil::cuda_error( cudaGetErrorString(errcode) );
    return device_address_on_host;
}
#endif
}
