#include <secdecutil/series.hpp>

#include "sector_58_n1.hpp"
#include "sector_58_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_58()
{
return {-1,0,{{58,{-1},5,sector_58_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_58_order_n1_integrand
#endif
},{58,{0},6,sector_58_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_58_order_0_integrand
#endif
}},true,"eps"};
}

}
