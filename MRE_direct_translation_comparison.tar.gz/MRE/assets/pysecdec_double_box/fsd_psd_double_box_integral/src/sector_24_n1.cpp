#include "sector_24_n1.hpp"
namespace fsd_psd_double_box_integral
{
#ifdef SECDEC_WITH_CUDA
__host__ __device__
#endif
integrand_return_t sector_24_order_n1_integrand
(
    real_t const * restrict const integration_variables,
    real_t const * restrict const real_parameters,
    complex_t const * restrict const complex_parameters,
    secdecutil::ResultInfo * restrict const result_info
)
{
    const auto x0 = integration_variables[0]; (void)x0;
    const auto x1 = integration_variables[1]; (void)x1;
    const auto x2 = integration_variables[2]; (void)x2;
    const auto x3 = integration_variables[3]; (void)x3;
    const auto x4 = integration_variables[4]; (void)x4;
    const auto x5 = integration_variables[5]; (void)x5;
    const auto s12 = real_parameters[0]; (void)s12;
    const auto s23 = real_parameters[1]; (void)s23;
    auto tmp1_1 = x1*x2;
    auto tmp1_2 = tmp1_1 + 1;
    auto tmp1_3 = tmp1_2*x3;
    auto tmp1_4 = x2 + 1;
    auto tmp1_5 = tmp1_4*x1;
    auto tmp3_1 = tmp1_3 + tmp1_5 + x0 + 1;
    auto tmp3_2 = x0*x2;
    auto tmp1_6 = tmp3_2 + 1;
    auto tmp1_7 = x5*tmp1_1;
    auto tmp3_3 = 2*tmp1_7 + tmp1_6;
    auto tmp1_8 = 3*x1;
    auto tmp1_9 = x3*x2;
    auto tmp3_4 = tmp1_9 + tmp1_4;
    auto tmp1_10 = tmp3_4 + tmp3_2;
    auto tmp1_11 = x3 + 1;
    auto tmp1_12 = tmp1_11*x0;
    auto tmp1_13 = 6*x1;
    auto tmp1_14 = tmp3_2 + tmp1_1;
    auto tmp1_15 = 2*tmp3_4 + tmp1_14;
    auto tmp3_5 = x1*tmp1_11;
    auto tmp1_16 = tmp1_12 + tmp3_5;
    auto tmp1_17 = 7*x1;
    auto tmp1_18 = -9*x1;
    auto tmp3_6 = tmp3_4 + tmp1_1;
    auto tmp1_19 = x5*tmp3_6;
    auto tmp3_7 = tmp1_19 + tmp1_10;
    auto tmp1_20 = x5*tmp3_5;
    auto tmp3_8 = tmp1_12 + tmp1_20;
    auto tmp3_9 = 2 + x2 + tmp1_9 + tmp1_14;
    auto tmp3_10 = x5*tmp1_13;
    auto tmp3_11 = tmp3_2 + tmp1_2;
    auto tmp3_12 = x5*tmp1_6;
    auto _logCall1 = SecDecInternalLog(x2);
    auto __PowCall6 = SecDecInternalSqr(x2);
    auto __PowCall7 = SecDecInternalSqr(x5);
    auto __DenominatorCall7 = SecDecInternalDenominator(x4);
    auto __DenominatorCall10 = SecDecInternalDenominator(x5);
    auto tmp2_10 = tmp3_5*__PowCall6;
    auto tmp2_11 = tmp2_10 + tmp3_6;
    auto tmp3_13 = tmp2_10 + tmp3_9;
    auto tmp2_12 = tmp1_12*__PowCall6;
    auto tmp3_14 = tmp2_12 + tmp1_10;
    auto tmp2_13 = tmp3_8*__PowCall6;
    auto tmp3_15 = tmp3_7 + tmp2_13;
    auto tmp2_14 = tmp1_16*__PowCall6;
    auto tmp3_16 = tmp1_15 + tmp2_14;
    auto _logCall3 = SecDecInternalLog(tmp3_1);
    auto __PowCall8 = SecDecInternalSqr(tmp3_1);
    auto __PowCall9 = SecDecInternalSqr(tmp3_1)*tmp3_1;
    auto __PowCall10 = SecDecInternalSqr(tmp3_1);
    auto __PowCall11 = SecDecInternalSqr(tmp3_1)*tmp3_1;
    auto __PowCall12 = SecDecInternalSqr(tmp3_1);
    auto __PowCall13 = SecDecInternalSqr(tmp3_1)*tmp3_1;
    auto __PowCall14 = SecDecInternalSqr(tmp3_1);
    auto __PowCall15 = SecDecInternalSqr(tmp3_1)*tmp3_1;
    auto __PowCall16 = SecDecInternalSqr(tmp3_1);
    auto __PowCall17 = SecDecInternalSqr(tmp3_1)*tmp3_1;
    auto _logCall2 = SecDecInternalLog(tmp3_14);
    auto __PowCall1 = SecDecInternalSqr(__PowCall8);
    auto __PowCall2 = SecDecInternalSqr(__PowCall10);
    auto __PowCall3 = SecDecInternalSqr(__PowCall12);
    auto __PowCall4 = SecDecInternalSqr(__PowCall14);
    auto __PowCall5 = SecDecInternalSqr(__PowCall16);
    auto __DenominatorCall4 = SecDecInternalDenominator(__PowCall9);
    auto __DenominatorCall5 = SecDecInternalDenominator(__PowCall11);
    auto __DenominatorCall6 = SecDecInternalDenominator(__PowCall13);
    auto __DenominatorCall9 = SecDecInternalDenominator(__PowCall15);
    auto __DenominatorCall12 = SecDecInternalDenominator(__PowCall17);
    auto __DenominatorCall1 = SecDecInternalDenominator(__PowCall1);
    auto __DenominatorCall2 = SecDecInternalDenominator(__PowCall2);
    auto __DenominatorCall3 = SecDecInternalDenominator(__PowCall3);
    auto __DenominatorCall8 = SecDecInternalDenominator(__PowCall4);
    auto __DenominatorCall11 = SecDecInternalDenominator(__PowCall5);
    auto tmp3_17 = _logCall2*tmp1_18;
    auto tmp3_18 = -__DenominatorCall7*tmp1_8;
    auto tmp3_19 = _logCall3 + _logCall1;
    auto tmp3_20 = -__DenominatorCall10 + tmp3_19;
    auto tmp3_21 = tmp1_13*tmp3_20;
    auto tmp3_22 = tmp3_21 + tmp3_18 + tmp1_17 + tmp3_17;
    auto tmp3_23 = __DenominatorCall1*tmp3_14*tmp3_22;
    auto tmp3_24 = -__DenominatorCall9*tmp1_6;
    auto tmp3_25 = tmp1_8*__DenominatorCall8*tmp3_14;
    auto tmp3_26 = tmp3_24 + tmp3_25;
    auto tmp3_27 = __DenominatorCall7*tmp3_26;
    auto tmp3_28 = __DenominatorCall4*tmp1_6;
    auto tmp3_29 = __DenominatorCall7 + 3*_logCall2-2*tmp3_19;
    auto tmp3_30 = tmp3_29*tmp3_28;
    auto tmp3_31 = __DenominatorCall12*tmp3_3;
    auto tmp3_32 = tmp3_28-tmp3_31;
    auto tmp3_33 = __DenominatorCall11*tmp3_10*tmp2_11;
    auto tmp3_34 = tmp3_33 + 2*tmp3_32;
    auto tmp3_35 = __DenominatorCall10*tmp3_34;
    auto tmp3_36 = -__DenominatorCall2*tmp3_16;
    auto tmp3_37 = __DenominatorCall10*__DenominatorCall11*tmp3_15;
    auto tmp3_38 = tmp3_36 + tmp3_37;
    auto tmp3_39 = tmp1_13*tmp3_38;
    auto tmp3_40 = __DenominatorCall5*tmp3_11;
    auto tmp3_41 = __DenominatorCall6*tmp3_13;
    auto tmp3_42 = -tmp1_8*__DenominatorCall3*tmp3_14;
    return(tmp3_23 + tmp3_27 + tmp3_30 + tmp3_35 + tmp3_39 + 2*tmp3_40 + tmp3_41 + tmp3_42);
}
#ifdef SECDEC_WITH_CUDA
__device__ secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* const device_sector_24_order_n1_integrand = sector_24_order_n1_integrand;
secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* get_device_sector_24_order_n1_integrand()
{
    using IntegrandFunction = secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction;
    IntegrandFunction* device_address_on_host;
    auto errcode = cudaMemcpyFromSymbol(&device_address_on_host,device_sector_24_order_n1_integrand, sizeof(IntegrandFunction*));
    if (errcode != cudaSuccess) throw secdecutil::cuda_error( cudaGetErrorString(errcode) );
    return device_address_on_host;
}
#endif
}
