#include <secdecutil/series.hpp>

#include "sector_18_n3.hpp"
#include "sector_18_n2.hpp"
#include "sector_18_n1.hpp"
#include "sector_18_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_18()
{
return {-3,0,{{18,{-3},3,sector_18_order_n3_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_18_order_n3_integrand
#endif
},{18,{-2},6,sector_18_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_18_order_n2_integrand
#endif
},{18,{-1},6,sector_18_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_18_order_n1_integrand
#endif
},{18,{0},6,sector_18_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_18_order_0_integrand
#endif
}},true,"eps"};
}

}
