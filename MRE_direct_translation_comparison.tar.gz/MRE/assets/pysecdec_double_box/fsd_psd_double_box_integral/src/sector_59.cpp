#include <secdecutil/series.hpp>

#include "sector_59_n2.hpp"
#include "sector_59_n1.hpp"
#include "sector_59_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_59()
{
return {-2,0,{{59,{-2},4,sector_59_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_59_order_n2_integrand
#endif
},{59,{-1},6,sector_59_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_59_order_n1_integrand
#endif
},{59,{0},6,sector_59_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_59_order_0_integrand
#endif
}},true,"eps"};
}

}
