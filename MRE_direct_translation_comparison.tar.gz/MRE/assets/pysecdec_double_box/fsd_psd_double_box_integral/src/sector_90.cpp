#include <secdecutil/series.hpp>

#include "sector_90_n3.hpp"
#include "sector_90_n2.hpp"
#include "sector_90_n1.hpp"
#include "sector_90_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_90()
{
return {-3,0,{{90,{-3},3,sector_90_order_n3_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_90_order_n3_integrand
#endif
},{90,{-2},6,sector_90_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_90_order_n2_integrand
#endif
},{90,{-1},6,sector_90_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_90_order_n1_integrand
#endif
},{90,{0},6,sector_90_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_90_order_0_integrand
#endif
}},true,"eps"};
}

}
