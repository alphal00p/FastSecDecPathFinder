#include "sector_43_n1.hpp"
namespace fsd_psd_double_box_integral
{
#ifdef SECDEC_WITH_CUDA
__host__ __device__
#endif
integrand_return_t sector_43_order_n1_integrand
(
    real_t const * restrict const integration_variables,
    real_t const * restrict const real_parameters,
    complex_t const * restrict const complex_parameters,
    secdecutil::ResultInfo * restrict const result_info
)
{
    const auto x0 = integration_variables[0]; (void)x0;
    const auto x1 = integration_variables[1]; (void)x1;
    const auto x2 = integration_variables[2]; (void)x2;
    const auto x3 = integration_variables[3]; (void)x3;
    const auto x4 = integration_variables[4]; (void)x4;
    const auto x5 = integration_variables[5]; (void)x5;
    const auto s12 = real_parameters[0]; (void)s12;
    const auto s23 = real_parameters[1]; (void)s23;
    auto tmp1_1 = x0*x1;
    auto tmp1_2 = tmp1_1 + 1;
    auto tmp1_3 = tmp1_2*x2;
    auto tmp3_1 = tmp1_3 + x3 + 1;
    auto tmp1_4 = x1 + 1;
    auto tmp1_5 = tmp1_4*x0;
    auto tmp1_6 = tmp1_5 + tmp3_1;
    auto tmp1_7 = x3*x1;
    auto tmp1_8 = x4*tmp1_7;
    auto tmp3_2 = tmp1_8 + tmp1_4;
    auto tmp3_3 = x0*tmp3_2;
    auto tmp3_4 = tmp3_3 + tmp3_1;
    auto tmp3_5 = x2 + x3;
    auto tmp3_6 = tmp1_2*tmp3_5;
    auto tmp3_7 = 1 + tmp1_5 + tmp3_6;
    auto tmp3_8 = x2*x1;
    auto tmp3_9 = tmp3_8 + tmp1_4;
    auto tmp3_10 = tmp3_9 + tmp1_7;
    auto tmp1_9 = 2*tmp3_10;
    auto tmp1_10 = tmp1_7*x0;
    auto tmp1_11 = 4*tmp1_10;
    auto tmp1_12 = 3*tmp1_10;
    auto tmp1_13 = 6*x0;
    auto tmp3_11 = tmp1_13*tmp1_7;
    auto tmp3_12 = -9*tmp1_10;
    auto tmp3_13 = tmp3_8 + x1 + tmp1_1;
    auto tmp3_14 = x5*tmp3_13;
    auto tmp3_15 = tmp3_14 + tmp3_9;
    auto tmp3_16 = x5*x0;
    auto tmp1_14 = 1 + x2;
    auto tmp3_17 = tmp1_14*tmp3_16;
    auto tmp1_15 = x4*tmp3_10;
    auto tmp3_18 = tmp1_15 + tmp3_9;
    auto tmp1_16 = x5 + 1;
    auto tmp3_19 = tmp1_7*tmp1_16;
    auto tmp3_20 = tmp3_19 + tmp3_9;
    auto tmp3_21 = x3*tmp3_16;
    auto tmp1_17 = 2*x4 + 1;
    auto tmp3_22 = tmp1_7*tmp1_17;
    auto tmp3_23 = tmp3_22 + tmp3_9;
    auto _logCall1 = SecDecInternalLog(x1);
    auto __PowCall4 = SecDecInternalSqr(x1);
    auto __PowCall5 = SecDecInternalSqr(x4);
    auto __DenominatorCall4 = SecDecInternalDenominator(x4);
    auto __DenominatorCall7 = SecDecInternalDenominator(x5);
    auto tmp3_24 = tmp3_21*__PowCall4;
    auto tmp3_25 = tmp3_24 + tmp3_20;
    auto tmp2_8 = __PowCall5*tmp1_7;
    auto tmp3_26 = tmp3_18 + tmp2_8;
    auto tmp2_9 = tmp3_17*__PowCall4;
    auto tmp3_27 = tmp3_15 + tmp2_9;
    auto _logCall2 = SecDecInternalLog(tmp3_9);
    auto _logCall3 = SecDecInternalLog(tmp1_6);
    auto __PowCall6 = SecDecInternalSqr(tmp1_6);
    auto __PowCall7 = SecDecInternalSqr(tmp1_6)*tmp1_6;
    auto __PowCall8 = SecDecInternalSqr(tmp3_7)*tmp3_7;
    auto __PowCall9 = SecDecInternalSqr(tmp3_4);
    auto __PowCall10 = SecDecInternalSqr(tmp3_4)*tmp3_4;
    auto __PowCall11 = SecDecInternalSqr(tmp1_6);
    auto __PowCall12 = SecDecInternalSqr(tmp1_6)*tmp1_6;
    auto __PowCall1 = SecDecInternalSqr(__PowCall6);
    auto __PowCall2 = SecDecInternalSqr(__PowCall9);
    auto __PowCall3 = SecDecInternalSqr(__PowCall11);
    auto __DenominatorCall2 = SecDecInternalDenominator(__PowCall7);
    auto __DenominatorCall3 = SecDecInternalDenominator(__PowCall8);
    auto __DenominatorCall6 = SecDecInternalDenominator(__PowCall10);
    auto __DenominatorCall9 = SecDecInternalDenominator(__PowCall12);
    auto __DenominatorCall1 = SecDecInternalDenominator(__PowCall1);
    auto __DenominatorCall5 = SecDecInternalDenominator(__PowCall2);
    auto __DenominatorCall8 = SecDecInternalDenominator(__PowCall3);
    auto tmp3_28 = _logCall2*tmp3_12;
    auto tmp3_29 = -__DenominatorCall7*tmp1_12;
    auto tmp3_30 = -_logCall1 + __DenominatorCall4-_logCall3;
    auto tmp3_31 = -tmp3_11*tmp3_30;
    auto tmp3_32 = tmp3_31 + tmp3_29 + tmp1_11 + tmp3_28;
    auto tmp3_33 = __DenominatorCall1*tmp3_9*tmp3_32;
    auto tmp3_34 = __DenominatorCall3*tmp1_9;
    auto tmp3_35 = -__DenominatorCall4*__DenominatorCall6*tmp3_23;
    auto tmp3_36 = tmp3_34 + tmp3_35;
    auto tmp3_37 = -__DenominatorCall9*tmp3_25;
    auto tmp3_38 = tmp1_12*__DenominatorCall8*tmp3_27;
    auto tmp3_39 = tmp3_37 + tmp3_38;
    auto tmp3_40 = __DenominatorCall7*tmp3_39;
    auto tmp3_41 = tmp3_11*__DenominatorCall4*__DenominatorCall5*tmp3_26;
    auto tmp3_42 = __DenominatorCall7 + 3*_logCall2 + 1 + 2*tmp3_30;
    auto tmp3_43 = __DenominatorCall2*tmp3_10*tmp3_42;
    return(tmp3_33 + 2*tmp3_36 + tmp3_43 + tmp3_40 + tmp3_41);
}
#ifdef SECDEC_WITH_CUDA
__device__ secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* const device_sector_43_order_n1_integrand = sector_43_order_n1_integrand;
secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* get_device_sector_43_order_n1_integrand()
{
    using IntegrandFunction = secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction;
    IntegrandFunction* device_address_on_host;
    auto errcode = cudaMemcpyFromSymbol(&device_address_on_host,device_sector_43_order_n1_integrand, sizeof(IntegrandFunction*));
    if (errcode != cudaSuccess) throw secdecutil::cuda_error( cudaGetErrorString(errcode) );
    return device_address_on_host;
}
#endif
}
