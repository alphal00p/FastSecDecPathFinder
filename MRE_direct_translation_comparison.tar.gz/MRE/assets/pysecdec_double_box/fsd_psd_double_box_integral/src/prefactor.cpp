#include <secdecutil/series.hpp>
#include <secdecutil/uncertainties.hpp>
#include <vector>

#include "fsd_psd_double_box_integral.hpp"
#include "functions.hpp"

namespace fsd_psd_double_box_integral
{
    nested_series_t<integrand_return_t> prefactor(const std::vector<real_t>& real_parameters, const std::vector<complex_t>& complex_parameters)
    {
        #define s12 real_parameters.at(0)
        #define s23 real_parameters.at(1)
        return {0,4,{{-2.0},{-3.6911373403938686},{-4.9858599838053861},{-4.5999533513648978},{-3.681199052065825}},true,"eps"};
        #undef s12
        #undef s23
    }
};
