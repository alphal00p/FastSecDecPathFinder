#include <secdecutil/series.hpp>

#include "sector_32_n3.hpp"
#include "sector_32_n2.hpp"
#include "sector_32_n1.hpp"
#include "sector_32_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_32()
{
return {-3,0,{{32,{-3},3,sector_32_order_n3_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_32_order_n3_integrand
#endif
},{32,{-2},6,sector_32_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_32_order_n2_integrand
#endif
},{32,{-1},6,sector_32_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_32_order_n1_integrand
#endif
},{32,{0},6,sector_32_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_32_order_0_integrand
#endif
}},true,"eps"};
}

}
