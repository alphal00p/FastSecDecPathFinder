#include <secdecutil/series.hpp>

#include "sector_52_n2.hpp"
#include "sector_52_n1.hpp"
#include "sector_52_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_52()
{
return {-2,0,{{52,{-2},4,sector_52_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_52_order_n2_integrand
#endif
},{52,{-1},6,sector_52_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_52_order_n1_integrand
#endif
},{52,{0},6,sector_52_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_52_order_0_integrand
#endif
}},true,"eps"};
}

}
