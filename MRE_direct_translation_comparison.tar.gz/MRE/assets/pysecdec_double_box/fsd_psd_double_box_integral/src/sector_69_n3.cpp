#include "sector_69_n3.hpp"
namespace fsd_psd_double_box_integral
{
#ifdef SECDEC_WITH_CUDA
__host__ __device__
#endif
integrand_return_t sector_69_order_n3_integrand
(
    real_t const * restrict const integration_variables,
    real_t const * restrict const real_parameters,
    complex_t const * restrict const complex_parameters,
    secdecutil::ResultInfo * restrict const result_info
)
{
    const auto x0 = integration_variables[0]; (void)x0;
    const auto x1 = integration_variables[1]; (void)x1;
    const auto x2 = integration_variables[2]; (void)x2;
    const auto x3 = integration_variables[3]; (void)x3;
    const auto x4 = integration_variables[4]; (void)x4;
    const auto x5 = integration_variables[5]; (void)x5;
    const auto s12 = real_parameters[0]; (void)s12;
    const auto s23 = real_parameters[1]; (void)s23;
    auto tmp1_1 = SecDecInternalQuo(3, 4)*x5;
    auto tmp1_2 = x5*x4;
    auto tmp1_3 = SecDecInternalQuo(3, 2)*x5;
    auto tmp1_4 = 3*x5;
    auto tmp1_5 = -SecDecInternalQuo(1, 4)*x5*x1;
    auto tmp1_6 = SecDecInternalQuo(1, 2)*x5;
    auto tmp1_7 = SecDecInternalQuo(7, 2)*x5;
    auto tmp1_8 = -SecDecInternalQuo(9, 2)*x5;
    auto tmp1_9 = x2 + 1;
    auto tmp1_10 = x4*tmp1_9;
    auto tmp3_1 = 1 + tmp1_10;
    auto tmp1_11 = x5*tmp3_1;
    auto tmp3_2 = tmp1_11 + tmp1_9;
    auto tmp1_12 = tmp1_9 + x5;
    auto tmp1_13 = x3 + tmp1_12;
    auto tmp1_14 = x2 + 2;
    auto tmp1_15 = x5 + tmp1_14;
    auto tmp1_16 = tmp1_14*x5;
    auto tmp1_17 = tmp1_16 + tmp1_9;
    auto tmp1_18 = 6*x5;
    auto tmp1_19 = tmp1_18*x4;
    auto tmp1_20 = tmp1_9*x5;
    auto tmp1_21 = SecDecInternalQuo(3, 4)*x1;
    auto tmp1_22 = -SecDecInternalQuo(29, 2)*x5;
    auto tmp1_23 = 9*x5;
    auto tmp1_24 = 30*tmp1_2;
    auto tmp1_25 = x3 + tmp1_9;
    auto tmp1_26 = x1*tmp1_9;
    auto tmp1_27 = 1 + tmp1_26;
    auto tmp3_3 = x5*tmp1_27;
    auto tmp1_28 = x4*tmp1_3;
    auto tmp1_29 = 2*x3 + tmp1_9;
    auto tmp1_30 = x3*tmp1_9;
    auto __PowCall1 = SecDecInternalSqr(x4);
    auto __PowCall10 = SecDecInternalSqr(x3);
    auto __DenominatorCall11 = SecDecInternalDenominator(x0);
    auto __DenominatorCall14 = SecDecInternalDenominator(x1);
    auto __DenominatorCall18 = SecDecInternalDenominator(x3);
    auto __DenominatorCall21 = SecDecInternalDenominator(x4);
    auto _logCall1 = SecDecInternalLog(tmp1_9);
    auto _logCall2 = SecDecInternalLog(tmp1_12);
    auto __PowCall11 = SecDecInternalSqr(tmp1_12);
    auto __PowCall12 = SecDecInternalSqr(tmp1_12)*tmp1_12;
    auto __PowCall13 = SecDecInternalSqr(tmp1_17);
    auto __PowCall14 = SecDecInternalSqr(tmp1_17)*tmp1_17;
    auto __PowCall15 = SecDecInternalSqr(tmp1_15);
    auto __PowCall16 = SecDecInternalSqr(tmp1_15)*tmp1_15;
    auto __PowCall17 = SecDecInternalSqr(tmp1_12);
    auto __PowCall18 = SecDecInternalSqr(tmp1_12)*tmp1_12;
    auto __PowCall19 = SecDecInternalSqr(tmp1_12);
    auto __PowCall20 = SecDecInternalSqr(tmp1_12);
    auto __PowCall21 = SecDecInternalSqr(tmp1_12)*tmp1_12;
    auto __PowCall22 = SecDecInternalSqr(tmp1_13);
    auto __PowCall23 = SecDecInternalSqr(tmp3_2);
    auto __PowCall24 = SecDecInternalSqr(tmp3_2)*tmp3_2;
    auto __DenominatorCall26 = SecDecInternalDenominator(tmp1_9);
    auto __PowCall2 = SecDecInternalSqr(__PowCall11);
    auto __PowCall3 = SecDecInternalSqr(__PowCall13);
    auto __PowCall4 = SecDecInternalSqr(__PowCall15);
    auto __PowCall5 = SecDecInternalSqr(__PowCall17);
    auto __PowCall6 = SecDecInternalSqr(__PowCall19);
    auto __PowCall7 = SecDecInternalSqr(__PowCall20);
    auto __PowCall8 = SecDecInternalSqr(__PowCall22);
    auto __PowCall9 = SecDecInternalSqr(__PowCall23);
    auto __DenominatorCall8 = SecDecInternalDenominator(__PowCall14);
    auto __DenominatorCall9 = SecDecInternalDenominator(__PowCall16);
    auto __DenominatorCall10 = SecDecInternalDenominator(__PowCall18);
    auto __DenominatorCall17 = SecDecInternalDenominator(__PowCall21);
    auto __DenominatorCall25 = SecDecInternalDenominator(__PowCall24);
    auto __DenominatorCall27 = SecDecInternalDenominator(__PowCall12);
    auto tmp3_4 = tmp1_12*__PowCall2;
    auto tmp3_5 = tmp1_17*__PowCall3;
    auto tmp3_6 = tmp1_12*__PowCall5;
    auto tmp3_7 = tmp1_12*__PowCall6;
    auto tmp3_8 = tmp1_12*__PowCall7;
    auto tmp3_9 = tmp1_13*__PowCall8;
    auto tmp3_10 = tmp3_2*__PowCall9;
    auto tmp3_11 = __PowCall23*__PowCall9;
    auto __DenominatorCall1 = SecDecInternalDenominator(__PowCall2);
    auto __DenominatorCall2 = SecDecInternalDenominator(tmp3_4);
    auto __DenominatorCall3 = SecDecInternalDenominator(__PowCall3);
    auto __DenominatorCall4 = SecDecInternalDenominator(tmp3_5);
    auto __DenominatorCall5 = SecDecInternalDenominator(__PowCall4);
    auto __DenominatorCall6 = SecDecInternalDenominator(__PowCall5);
    auto __DenominatorCall7 = SecDecInternalDenominator(tmp3_6);
    auto __DenominatorCall12 = SecDecInternalDenominator(__PowCall6);
    auto __DenominatorCall13 = SecDecInternalDenominator(tmp3_7);
    auto __DenominatorCall15 = SecDecInternalDenominator(__PowCall7);
    auto __DenominatorCall16 = SecDecInternalDenominator(tmp3_8);
    auto __DenominatorCall19 = SecDecInternalDenominator(__PowCall8);
    auto __DenominatorCall20 = SecDecInternalDenominator(tmp3_9);
    auto __DenominatorCall22 = SecDecInternalDenominator(__PowCall9);
    auto __DenominatorCall23 = SecDecInternalDenominator(tmp3_10);
    auto __DenominatorCall24 = SecDecInternalDenominator(tmp3_11);
    auto tmp2_16 = tmp3_1 + 1;
    auto tmp2_17 = tmp1_20*__PowCall1;
    auto tmp3_12 = tmp2_17 + tmp2_16;
    auto tmp3_13 = tmp1_3*tmp3_12;
    auto tmp2_18 = tmp1_28*tmp1_9;
    auto tmp3_14 = tmp3_13 + tmp2_18;
    auto tmp3_15 = __DenominatorCall22*tmp3_14;
    auto tmp3_16 = tmp1_9*tmp1_24*__DenominatorCall24;
    auto tmp3_17 = -__DenominatorCall23*tmp1_19*tmp2_16;
    auto tmp3_18 = tmp3_16 + tmp3_17;
    auto tmp3_19 = tmp1_20*tmp3_18;
    auto tmp3_20 = __DenominatorCall2*tmp1_9;
    auto tmp2_19 = -__DenominatorCall23*tmp1_9;
    auto tmp3_21 = tmp2_19 + tmp3_20;
    auto tmp3_22 = tmp1_18*tmp3_21;
    auto tmp2_20 = -tmp1_2*__DenominatorCall25;
    auto tmp2_21 = -tmp1_4*__DenominatorCall1;
    auto tmp3_23 = tmp2_21 + tmp3_22 + tmp2_20 + tmp3_19 + tmp3_15;
    auto tmp3_24 = __DenominatorCall21*tmp3_23;
    auto tmp3_25 = -_logCall2 + __DenominatorCall18 + __DenominatorCall11;
    auto tmp3_26 = tmp3_25*tmp3_20;
    auto tmp3_27 = __DenominatorCall4*tmp1_9;
    auto tmp3_28 = -__DenominatorCall11*__DenominatorCall13*tmp1_9;
    auto tmp2_22 = -__DenominatorCall18*__DenominatorCall20*tmp1_25;
    auto tmp3_29 = tmp3_26 + tmp2_22 + tmp3_27 + tmp3_28;
    auto tmp3_30 = tmp1_18*tmp3_29;
    auto tmp3_31 = -__DenominatorCall16*tmp1_9;
    auto tmp3_32 = tmp3_31 + tmp3_20;
    auto tmp3_33 = __DenominatorCall14*tmp3_32;
    auto tmp3_34 = __DenominatorCall11*__DenominatorCall12;
    auto tmp3_35 = __DenominatorCall18*__DenominatorCall19;
    auto tmp3_36 = -__DenominatorCall1*tmp3_25;
    auto tmp3_37 = tmp3_33 + tmp3_36 + tmp3_34 + tmp3_35;
    auto tmp3_38 = tmp1_4*tmp3_37;
    auto tmp3_39 = tmp1_5*__DenominatorCall17;
    auto tmp3_40 = __DenominatorCall16*tmp1_20*tmp1_26;
    auto tmp3_41 = tmp1_20*tmp1_21;
    auto tmp3_42 = tmp1_1 + SecDecInternalQuo(3, 4)*tmp3_3 + tmp3_41;
    auto tmp3_43 = __DenominatorCall15*tmp3_42;
    auto tmp3_44 = tmp3_43 + tmp3_39-3*tmp3_40;
    auto tmp3_45 = __DenominatorCall14*tmp3_44;
    auto tmp3_46 = -__DenominatorCall5*tmp1_14;
    auto tmp3_47 = -1-tmp1_14;
    auto tmp3_48 = __DenominatorCall3*tmp3_47;
    auto tmp2_23 = -__DenominatorCall14*__DenominatorCall1;
    auto tmp3_49 = tmp2_23-__DenominatorCall6 + tmp3_46 + tmp3_48;
    auto tmp3_50 = tmp1_3*tmp3_49;
    auto tmp3_51 = _logCall1*tmp1_23;
    auto tmp3_52 = tmp1_22 + tmp3_51;
    auto tmp3_53 = tmp3_52*tmp3_20;
    auto tmp3_54 = __DenominatorCall7*tmp1_9;
    auto tmp3_55 = -SecDecInternalQuo(3, 2)*__DenominatorCall6 + 6*tmp3_54;
    auto tmp3_56 = tmp1_16*tmp3_55;
    auto tmp3_57 = __DenominatorCall10*tmp1_9;
    auto tmp2_24 = __DenominatorCall8 + __DenominatorCall9;
    auto tmp3_58 = tmp1_6*tmp2_24;
    auto tmp2_25 = tmp1_1*__DenominatorCall27*__DenominatorCall26;
    auto tmp2_26 = _logCall1*tmp1_8;
    auto tmp3_59 = tmp1_7 + tmp2_26;
    auto tmp3_60 = __DenominatorCall1*tmp3_59;
    return(tmp3_24 + tmp3_38 + tmp3_53 + tmp3_30 + tmp3_45 + tmp3_50 + tmp3_56 + SecDecInternalQuo(1, 2)*tmp3_57 + tmp3_58 + tmp2_25 + tmp3_60);
}
#ifdef SECDEC_WITH_CUDA
__device__ secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* const device_sector_69_order_n3_integrand = sector_69_order_n3_integrand;
secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* get_device_sector_69_order_n3_integrand()
{
    using IntegrandFunction = secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction;
    IntegrandFunction* device_address_on_host;
    auto errcode = cudaMemcpyFromSymbol(&device_address_on_host,device_sector_69_order_n3_integrand, sizeof(IntegrandFunction*));
    if (errcode != cudaSuccess) throw secdecutil::cuda_error( cudaGetErrorString(errcode) );
    return device_address_on_host;
}
#endif
}
