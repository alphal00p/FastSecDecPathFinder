#include "sector_32_n2.hpp"
namespace fsd_psd_double_box_integral
{
#ifdef SECDEC_WITH_CUDA
__host__ __device__
#endif
integrand_return_t sector_32_order_n2_integrand
(
    real_t const * restrict const integration_variables,
    real_t const * restrict const real_parameters,
    complex_t const * restrict const complex_parameters,
    secdecutil::ResultInfo * restrict const result_info
)
{
    const auto x0 = integration_variables[0]; (void)x0;
    const auto x1 = integration_variables[1]; (void)x1;
    const auto x2 = integration_variables[2]; (void)x2;
    const auto x3 = integration_variables[3]; (void)x3;
    const auto x4 = integration_variables[4]; (void)x4;
    const auto x5 = integration_variables[5]; (void)x5;
    const auto s12 = real_parameters[0]; (void)s12;
    const auto s23 = real_parameters[1]; (void)s23;
    auto tmp1_1 = SecDecInternalQuo(1, 2)*x5;
    auto tmp1_2 = x3*x5;
    auto tmp1_3 = SecDecInternalQuo(3, 2)*tmp1_2;
    auto tmp1_4 = 3*tmp1_2;
    auto tmp1_5 = 2*x5;
    auto tmp1_6 = 6*tmp1_2;
    auto tmp1_7 = -2*tmp1_2;
    auto tmp1_8 = SecDecInternalQuo(3, 2)*x5;
    auto tmp1_9 = SecDecInternalQuo(9, 2)*tmp1_2;
    auto tmp1_10 = x5 + 1;
    auto tmp1_11 = tmp1_10*x2;
    auto tmp1_12 = tmp1_11 + tmp1_10;
    auto tmp1_13 = tmp1_2 + tmp1_12;
    auto tmp1_14 = x4*x3;
    auto tmp1_15 = tmp1_14 + tmp1_13;
    auto tmp1_16 = x1*x5;
    auto tmp1_17 = tmp1_16 + tmp1_13;
    auto tmp3_1 = 1 + tmp1_5 + tmp1_11 + tmp1_2;
    auto tmp1_18 = tmp1_10*x3;
    auto tmp1_19 = tmp1_18 + tmp1_12;
    auto tmp1_20 = 12*tmp1_2;
    auto tmp1_21 = x2 + 1;
    auto tmp1_22 = x5 + 2;
    auto tmp1_23 = tmp1_22*tmp1_21;
    auto tmp1_24 = SecDecInternalQuo(3, 2)*x3;
    auto tmp3_2 = tmp1_10 + x2;
    auto tmp1_25 = 3*x5;
    auto tmp1_26 = tmp1_21 + x3;
    auto tmp1_27 = 2*tmp1_26;
    auto tmp1_28 = 5*tmp1_2;
    auto tmp3_3 = -18*tmp1_2;
    auto tmp1_29 = x4*tmp1_26;
    auto tmp3_4 = tmp1_29 + tmp1_21;
    auto tmp1_30 = tmp1_16 + tmp1_21;
    auto tmp1_31 = x3 + tmp3_2;
    auto tmp1_32 = SecDecInternalQuo(9, 2)*x5;
    auto tmp3_5 = 2*tmp1_14 + tmp1_26;
    auto tmp3_6 = tmp1_16 + tmp1_26;
    auto tmp3_7 = x3*tmp1_22;
    auto tmp3_8 = tmp3_7 + tmp1_21;
    auto tmp1_33 = 3*x3;
    auto tmp1_34 = 1 + x4;
    auto tmp3_9 = x5*tmp1_34;
    auto __PowCall8 = SecDecInternalSqr(x4);
    auto __DenominatorCall12 = SecDecInternalDenominator(x0);
    auto __DenominatorCall16 = SecDecInternalDenominator(x1);
    auto __DenominatorCall20 = SecDecInternalDenominator(x4);
    auto tmp3_10 = x3*__PowCall8;
    auto tmp3_11 = tmp3_4 + tmp3_10;
    auto _logCall1 = SecDecInternalLog(tmp1_13);
    auto _logCall2 = SecDecInternalLog(tmp1_12);
    auto __PowCall9 = SecDecInternalSqr(tmp1_13);
    auto __PowCall10 = SecDecInternalSqr(tmp1_13)*tmp1_13;
    auto __PowCall11 = SecDecInternalSqr(tmp1_12);
    auto __PowCall12 = SecDecInternalSqr(tmp1_19);
    auto __PowCall13 = SecDecInternalSqr(tmp1_19)*tmp1_19;
    auto __PowCall14 = SecDecInternalSqr(tmp3_1);
    auto __PowCall15 = SecDecInternalSqr(tmp3_1)*tmp3_1;
    auto __PowCall16 = SecDecInternalSqr(tmp1_13);
    auto __PowCall17 = SecDecInternalSqr(tmp1_13)*tmp1_13;
    auto __PowCall18 = SecDecInternalSqr(tmp1_13);
    auto __PowCall19 = SecDecInternalSqr(tmp1_13)*tmp1_13;
    auto __PowCall20 = SecDecInternalSqr(tmp1_17);
    auto __PowCall21 = SecDecInternalSqr(tmp1_17)*tmp1_17;
    auto __PowCall22 = SecDecInternalSqr(tmp1_15);
    auto __PowCall23 = SecDecInternalSqr(tmp1_15)*tmp1_15;
    auto __DenominatorCall24 = SecDecInternalDenominator(tmp1_12);
    auto __PowCall1 = SecDecInternalSqr(__PowCall9);
    auto __PowCall2 = SecDecInternalSqr(__PowCall12);
    auto __PowCall3 = SecDecInternalSqr(__PowCall14);
    auto __PowCall4 = SecDecInternalSqr(__PowCall16);
    auto __PowCall5 = SecDecInternalSqr(__PowCall18);
    auto __PowCall6 = SecDecInternalSqr(__PowCall20);
    auto __PowCall7 = SecDecInternalSqr(__PowCall22);
    auto __DenominatorCall7 = SecDecInternalDenominator(__PowCall10);
    auto __DenominatorCall8 = SecDecInternalDenominator(__PowCall11);
    auto __DenominatorCall9 = SecDecInternalDenominator(__PowCall13);
    auto __DenominatorCall10 = SecDecInternalDenominator(__PowCall15);
    auto __DenominatorCall11 = SecDecInternalDenominator(__PowCall17);
    auto __DenominatorCall15 = SecDecInternalDenominator(__PowCall19);
    auto __DenominatorCall19 = SecDecInternalDenominator(__PowCall21);
    auto __DenominatorCall23 = SecDecInternalDenominator(__PowCall23);
    auto tmp3_12 = tmp1_13*__PowCall1;
    auto tmp3_13 = tmp1_13*__PowCall4;
    auto tmp3_14 = tmp1_13*__PowCall5;
    auto tmp3_15 = tmp1_17*__PowCall6;
    auto tmp3_16 = tmp1_15*__PowCall7;
    auto __DenominatorCall1 = SecDecInternalDenominator(__PowCall1);
    auto __DenominatorCall2 = SecDecInternalDenominator(tmp3_12);
    auto __DenominatorCall3 = SecDecInternalDenominator(__PowCall2);
    auto __DenominatorCall4 = SecDecInternalDenominator(__PowCall3);
    auto __DenominatorCall5 = SecDecInternalDenominator(__PowCall4);
    auto __DenominatorCall6 = SecDecInternalDenominator(tmp3_13);
    auto __DenominatorCall13 = SecDecInternalDenominator(__PowCall5);
    auto __DenominatorCall14 = SecDecInternalDenominator(tmp3_14);
    auto __DenominatorCall17 = SecDecInternalDenominator(__PowCall6);
    auto __DenominatorCall18 = SecDecInternalDenominator(tmp3_15);
    auto __DenominatorCall21 = SecDecInternalDenominator(__PowCall7);
    auto __DenominatorCall22 = SecDecInternalDenominator(tmp3_16);
    auto tmp3_17 = -_logCall1 + __DenominatorCall20 + __DenominatorCall12;
    auto tmp3_18 = tmp1_25*tmp1_26;
    auto tmp3_19 = tmp3_18 + tmp1_4;
    auto tmp3_20 = tmp3_19*tmp3_17;
    auto tmp3_21 = _logCall2*tmp1_9;
    auto tmp2_19 = _logCall2*tmp1_32;
    auto tmp3_22 = -tmp1_5 + tmp2_19;
    auto tmp3_23 = tmp1_26*tmp3_22;
    auto tmp2_20 = tmp1_26*tmp1_8;
    auto tmp2_21 = tmp1_3 + tmp2_20;
    auto tmp3_24 = __DenominatorCall16*tmp2_21;
    auto tmp2_22 = tmp1_18*tmp1_32;
    auto tmp3_25 = tmp1_9 + tmp2_22;
    auto tmp3_26 = tmp1_21*__DenominatorCall24*tmp3_25;
    auto tmp3_27 = tmp3_26 + tmp3_24 + tmp3_23 + tmp1_7 + tmp3_21 + tmp3_20;
    auto tmp3_28 = __DenominatorCall1*tmp3_27;
    auto tmp3_29 = tmp1_21*__DenominatorCall8;
    auto tmp3_30 = tmp3_29-__DenominatorCall24;
    auto tmp3_31 = tmp1_18*tmp3_30;
    auto tmp3_32 = -_logCall2 + tmp3_31;
    auto tmp3_33 = tmp1_8*tmp3_32;
    auto tmp3_34 = 1-tmp3_17;
    auto tmp3_35 = x5*tmp3_34;
    auto tmp3_36 = -__DenominatorCall24*tmp2_20;
    auto tmp3_37 = -__DenominatorCall16*tmp1_1;
    auto tmp3_38 = tmp3_37 + tmp3_36 + tmp3_35 + tmp3_33;
    auto tmp3_39 = __DenominatorCall7*tmp3_38;
    auto tmp3_40 = -tmp1_25*tmp1_26;
    auto tmp3_41 = tmp3_40-tmp1_4;
    auto tmp3_42 = __DenominatorCall13*tmp3_41;
    auto tmp3_43 = tmp1_20*__DenominatorCall14*tmp1_21;
    auto tmp3_44 = x5*__DenominatorCall15;
    auto tmp3_45 = tmp3_44 + tmp3_43 + tmp3_42;
    auto tmp3_46 = __DenominatorCall12*tmp3_45;
    auto tmp3_47 = -tmp1_8*tmp3_6;
    auto tmp3_48 = tmp3_47-tmp1_3;
    auto tmp3_49 = __DenominatorCall17*tmp3_48;
    auto tmp3_50 = tmp1_1*__DenominatorCall19;
    auto tmp3_51 = tmp1_6*__DenominatorCall18*tmp1_30;
    auto tmp3_52 = tmp3_51 + tmp3_50 + tmp3_49;
    auto tmp3_53 = __DenominatorCall16*tmp3_52;
    auto tmp3_54 = -tmp1_33*tmp3_9;
    auto tmp3_55 = -tmp1_25*tmp3_5;
    auto tmp3_56 = tmp3_55 + tmp3_54;
    auto tmp3_57 = __DenominatorCall21*tmp3_56;
    auto tmp3_58 = tmp1_20*__DenominatorCall22*tmp3_11;
    auto tmp2_23 = x5*__DenominatorCall23;
    auto tmp3_59 = tmp2_23 + tmp3_58 + tmp3_57;
    auto tmp3_60 = __DenominatorCall20*tmp3_59;
    auto tmp3_61 = -tmp3_17*tmp1_20;
    auto tmp3_62 = _logCall2*tmp3_3;
    auto tmp3_63 = -__DenominatorCall16*tmp1_6;
    auto tmp3_64 = tmp3_61 + tmp3_63 + tmp1_28 + tmp3_62;
    auto tmp3_65 = tmp1_21*__DenominatorCall2*tmp3_64;
    auto tmp3_66 = __DenominatorCall3*tmp1_27;
    auto tmp3_67 = __DenominatorCall5*tmp3_8;
    auto tmp3_68 = tmp3_66 + tmp3_67;
    auto tmp3_69 = tmp1_25*tmp3_68;
    auto tmp3_70 = __DenominatorCall10*tmp1_31;
    auto tmp2_24 = tmp1_24*__DenominatorCall4*tmp3_2;
    auto tmp2_25 = -tmp1_5*__DenominatorCall9;
    auto tmp2_26 = tmp1_6*__DenominatorCall5;
    auto tmp2_27 = -tmp1_20*__DenominatorCall6*tmp1_23;
    auto tmp2_28 = -x5*__DenominatorCall11;
    return(tmp3_65 + tmp3_28 + tmp3_39 + tmp3_46 + tmp3_53 + tmp3_60 + tmp3_69-SecDecInternalQuo(1, 2)*tmp3_70 + tmp2_24 + tmp2_25 + tmp2_26 + tmp2_27 + tmp2_28);
}
#ifdef SECDEC_WITH_CUDA
__device__ secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* const device_sector_32_order_n2_integrand = sector_32_order_n2_integrand;
secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* get_device_sector_32_order_n2_integrand()
{
    using IntegrandFunction = secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction;
    IntegrandFunction* device_address_on_host;
    auto errcode = cudaMemcpyFromSymbol(&device_address_on_host,device_sector_32_order_n2_integrand, sizeof(IntegrandFunction*));
    if (errcode != cudaSuccess) throw secdecutil::cuda_error( cudaGetErrorString(errcode) );
    return device_address_on_host;
}
#endif
}
