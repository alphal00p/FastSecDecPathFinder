#include <secdecutil/series.hpp>

#include "sector_56_n3.hpp"
#include "sector_56_n2.hpp"
#include "sector_56_n1.hpp"
#include "sector_56_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_56()
{
return {-3,0,{{56,{-3},3,sector_56_order_n3_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_56_order_n3_integrand
#endif
},{56,{-2},6,sector_56_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_56_order_n2_integrand
#endif
},{56,{-1},6,sector_56_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_56_order_n1_integrand
#endif
},{56,{0},6,sector_56_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_56_order_0_integrand
#endif
}},true,"eps"};
}

}
