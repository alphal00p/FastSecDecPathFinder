#ifndef fsd_psd_double_box_integral_codegen_sector_33_0_hpp_included
#define fsd_psd_double_box_integral_codegen_sector_33_0_hpp_included
#include "fsd_psd_double_box_integral.hpp"
#include "functions.hpp"
namespace fsd_psd_double_box_integral
{
#ifdef SECDEC_WITH_CUDA
__host__ __device__
#endif
secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction sector_33_order_0_integrand;
#ifdef SECDEC_WITH_CUDA
secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* get_device_sector_33_order_0_integrand();
#endif
}
#endif
