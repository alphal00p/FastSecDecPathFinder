#include <secdecutil/series.hpp>

#include "sector_45_n2.hpp"
#include "sector_45_n1.hpp"
#include "sector_45_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_45()
{
return {-2,0,{{45,{-2},4,sector_45_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_45_order_n2_integrand
#endif
},{45,{-1},6,sector_45_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_45_order_n1_integrand
#endif
},{45,{0},6,sector_45_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_45_order_0_integrand
#endif
}},true,"eps"};
}

}
