#include <secdecutil/series.hpp>

#include "sector_21_n2.hpp"
#include "sector_21_n1.hpp"
#include "sector_21_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_21()
{
return {-2,0,{{21,{-2},4,sector_21_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_21_order_n2_integrand
#endif
},{21,{-1},6,sector_21_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_21_order_n1_integrand
#endif
},{21,{0},6,sector_21_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_21_order_0_integrand
#endif
}},true,"eps"};
}

}
