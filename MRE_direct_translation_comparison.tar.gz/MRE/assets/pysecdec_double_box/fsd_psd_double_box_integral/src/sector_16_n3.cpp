#include "sector_16_n3.hpp"
namespace fsd_psd_double_box_integral
{
#ifdef SECDEC_WITH_CUDA
__host__ __device__
#endif
integrand_return_t sector_16_order_n3_integrand
(
    real_t const * restrict const integration_variables,
    real_t const * restrict const real_parameters,
    complex_t const * restrict const complex_parameters,
    secdecutil::ResultInfo * restrict const result_info
)
{
    const auto x0 = integration_variables[0]; (void)x0;
    const auto x1 = integration_variables[1]; (void)x1;
    const auto x2 = integration_variables[2]; (void)x2;
    const auto x3 = integration_variables[3]; (void)x3;
    const auto x4 = integration_variables[4]; (void)x4;
    const auto x5 = integration_variables[5]; (void)x5;
    const auto s12 = real_parameters[0]; (void)s12;
    const auto s23 = real_parameters[1]; (void)s23;
    auto tmp1_1 = x4*x5;
    auto tmp1_2 = SecDecInternalQuo(3, 2)*x4;
    auto tmp1_3 = 3*x4;
    auto tmp1_4 = SecDecInternalQuo(1, 2)*x4;
    auto tmp1_5 = 6*x4;
    auto tmp1_6 = -SecDecInternalQuo(3, 4)*x4;
    auto tmp1_7 = 5*x4;
    auto tmp1_8 = SecDecInternalQuo(9, 2)*x4;
    auto tmp1_9 = x2 + 1;
    auto tmp1_10 = tmp1_9*x4;
    auto tmp1_11 = x5 + 1;
    auto tmp3_1 = tmp1_11*tmp1_10;
    auto tmp3_2 = 1 + tmp3_1;
    auto tmp1_12 = tmp1_9 + x3;
    auto tmp1_13 = x4*tmp1_12;
    auto tmp3_3 = 1 + tmp1_13;
    auto tmp1_14 = tmp1_10 + 1;
    auto tmp1_15 = x2 + 2;
    auto tmp1_16 = tmp1_15*x4;
    auto tmp1_17 = 1 + tmp1_16;
    auto tmp1_18 = 1 + 2*tmp1_10;
    auto tmp1_19 = x3*tmp1_10;
    auto tmp1_20 = x5*tmp1_2;
    auto tmp1_21 = 2*x3 + tmp1_9;
    auto tmp3_4 = x4*tmp1_21;
    auto tmp1_22 = 6*tmp1_1;
    auto tmp1_23 = 30*x5;
    auto tmp1_24 = x1 + tmp1_9;
    auto tmp3_5 = x4*tmp1_24;
    auto tmp1_25 = x5*tmp1_10;
    auto tmp3_6 = 1 + tmp1_25;
    auto tmp1_26 = 2*tmp1_9;
    auto __PowCall1 = SecDecInternalSqr(x4);
    auto __PowCall2 = SecDecInternalSqr(x5);
    auto __PowCall12 = SecDecInternalSqr(x3);
    auto __DenominatorCall15 = SecDecInternalDenominator(x0);
    auto __DenominatorCall18 = SecDecInternalDenominator(x1);
    auto __DenominatorCall21 = SecDecInternalDenominator(x3);
    auto __DenominatorCall24 = SecDecInternalDenominator(x5);
    auto _logCall1 = SecDecInternalLog(tmp1_9);
    auto _logCall2 = SecDecInternalLog(tmp1_14);
    auto __PowCall13 = SecDecInternalSqr(tmp1_9);
    auto __PowCall14 = SecDecInternalSqr(tmp1_14);
    auto __PowCall15 = SecDecInternalSqr(tmp1_14)*tmp1_14;
    auto __PowCall16 = SecDecInternalSqr(tmp1_18);
    auto __PowCall17 = SecDecInternalSqr(tmp1_18)*tmp1_18;
    auto __PowCall18 = SecDecInternalSqr(tmp1_17);
    auto __PowCall19 = SecDecInternalSqr(tmp1_17)*tmp1_17;
    auto __PowCall20 = SecDecInternalSqr(tmp1_14);
    auto __PowCall21 = SecDecInternalSqr(tmp1_14)*tmp1_14;
    auto __PowCall22 = SecDecInternalSqr(tmp1_14);
    auto __PowCall23 = SecDecInternalSqr(tmp1_14);
    auto __PowCall24 = SecDecInternalSqr(tmp1_14);
    auto __PowCall25 = SecDecInternalSqr(tmp3_3);
    auto __PowCall26 = SecDecInternalSqr(tmp3_2);
    auto __PowCall27 = SecDecInternalSqr(tmp3_2)*tmp3_2;
    auto __DenominatorCall29 = SecDecInternalDenominator(tmp1_9);
    auto __PowCall3 = SecDecInternalSqr(__PowCall14);
    auto __PowCall4 = SecDecInternalSqr(__PowCall16);
    auto __PowCall5 = SecDecInternalSqr(__PowCall18);
    auto __PowCall6 = SecDecInternalSqr(__PowCall20);
    auto __PowCall7 = SecDecInternalSqr(__PowCall22);
    auto __PowCall8 = SecDecInternalSqr(__PowCall23);
    auto __PowCall9 = SecDecInternalSqr(__PowCall24);
    auto __PowCall10 = SecDecInternalSqr(__PowCall25);
    auto __PowCall11 = SecDecInternalSqr(__PowCall26);
    auto __DenominatorCall10 = SecDecInternalDenominator(__PowCall13);
    auto __DenominatorCall11 = SecDecInternalDenominator(__PowCall15);
    auto __DenominatorCall12 = SecDecInternalDenominator(__PowCall17);
    auto __DenominatorCall13 = SecDecInternalDenominator(__PowCall19);
    auto __DenominatorCall14 = SecDecInternalDenominator(__PowCall21);
    auto __DenominatorCall28 = SecDecInternalDenominator(__PowCall27);
    auto tmp3_7 = tmp1_14*__PowCall3;
    auto tmp3_8 = tmp1_18*__PowCall4;
    auto tmp3_9 = tmp1_14*__PowCall6;
    auto tmp3_10 = tmp1_14*__PowCall7;
    auto tmp3_11 = tmp1_14*__PowCall8;
    auto tmp3_12 = tmp1_14*__PowCall9;
    auto tmp3_13 = tmp3_3*__PowCall10;
    auto tmp3_14 = tmp3_2*__PowCall11;
    auto tmp3_15 = __PowCall26*__PowCall11;
    auto __DenominatorCall1 = SecDecInternalDenominator(__PowCall3);
    auto __DenominatorCall2 = SecDecInternalDenominator(tmp3_7);
    auto __DenominatorCall3 = SecDecInternalDenominator(__PowCall4);
    auto __DenominatorCall4 = SecDecInternalDenominator(tmp3_8);
    auto __DenominatorCall5 = SecDecInternalDenominator(__PowCall5);
    auto __DenominatorCall6 = SecDecInternalDenominator(__PowCall6);
    auto __DenominatorCall7 = SecDecInternalDenominator(tmp3_9);
    auto __DenominatorCall8 = SecDecInternalDenominator(__PowCall7);
    auto __DenominatorCall9 = SecDecInternalDenominator(tmp3_10);
    auto __DenominatorCall16 = SecDecInternalDenominator(__PowCall8);
    auto __DenominatorCall17 = SecDecInternalDenominator(tmp3_11);
    auto __DenominatorCall19 = SecDecInternalDenominator(__PowCall9);
    auto __DenominatorCall20 = SecDecInternalDenominator(tmp3_12);
    auto __DenominatorCall22 = SecDecInternalDenominator(__PowCall10);
    auto __DenominatorCall23 = SecDecInternalDenominator(tmp3_13);
    auto __DenominatorCall25 = SecDecInternalDenominator(__PowCall11);
    auto __DenominatorCall26 = SecDecInternalDenominator(tmp3_14);
    auto __DenominatorCall27 = SecDecInternalDenominator(tmp3_15);
    auto tmp3_16 = tmp3_6 + 1;
    auto tmp2_13 = tmp1_10*__PowCall2;
    auto tmp3_17 = tmp2_13 + tmp3_16;
    auto tmp3_18 = tmp1_2*tmp3_17;
    auto tmp2_14 = tmp1_20*tmp1_10;
    auto tmp3_19 = tmp3_18 + tmp2_14;
    auto tmp3_20 = __DenominatorCall25*tmp3_19;
    auto tmp3_21 = -tmp1_1*__DenominatorCall28;
    auto tmp3_22 = -tmp1_10*__DenominatorCall26*tmp1_22*tmp3_16;
    auto tmp2_15 = -__DenominatorCall1*tmp1_3;
    auto tmp3_23 = tmp2_15 + tmp3_21 + tmp3_22 + tmp3_20;
    auto tmp3_24 = __DenominatorCall24*tmp3_23;
    auto tmp3_25 = __DenominatorCall4*tmp1_9;
    auto tmp3_26 = __DenominatorCall9*tmp1_26;
    auto tmp3_27 = -__DenominatorCall15*__DenominatorCall17*tmp1_9;
    auto tmp2_16 = __DenominatorCall21*__DenominatorCall23*tmp1_12;
    auto tmp3_28 = -tmp2_16 + tmp3_27 + tmp3_25 + tmp3_26;
    auto tmp3_29 = -__DenominatorCall18*__DenominatorCall20*tmp1_9;
    auto tmp3_30 = tmp3_29 + 2*tmp3_28;
    auto tmp3_31 = tmp1_9*__DenominatorCall2;
    auto tmp3_32 = -_logCall2 + __DenominatorCall21 + __DenominatorCall15;
    auto tmp3_33 = 3*__DenominatorCall18-SecDecInternalQuo(17, 2)+9*_logCall1 + 6*tmp3_32;
    auto tmp3_34 = tmp3_33*tmp3_31;
    auto tmp2_17 = tmp1_10*tmp1_23*__DenominatorCall27;
    auto tmp3_35 = -6*__DenominatorCall26 + tmp2_17;
    auto tmp3_36 = tmp1_9*tmp3_35;
    auto tmp3_37 = 6*tmp3_31 + tmp3_36;
    auto tmp3_38 = __DenominatorCall24*tmp3_37;
    auto tmp3_39 = tmp3_38 + 3*tmp3_30 + tmp3_34;
    auto tmp3_40 = __PowCall1*tmp3_39;
    auto tmp3_41 = tmp1_16*__DenominatorCall7*tmp1_9;
    auto tmp3_42 = __DenominatorCall15*__DenominatorCall16;
    auto tmp3_43 = __DenominatorCall21*__DenominatorCall22;
    auto tmp3_44 = tmp3_43 + tmp3_41 + tmp3_42;
    auto tmp3_45 = tmp1_3*tmp3_44;
    auto tmp3_46 = -__DenominatorCall1 + __DenominatorCall19;
    auto tmp3_47 = __DenominatorCall18*tmp3_46;
    auto tmp3_48 = -__DenominatorCall5*tmp1_15;
    auto tmp2_18 = -1-tmp1_14;
    auto tmp3_49 = __DenominatorCall3*tmp2_18;
    auto tmp3_50 = tmp3_48 + tmp3_49 + tmp3_47;
    auto tmp3_51 = tmp1_2*tmp3_50;
    auto tmp3_52 = -tmp1_8*_logCall1;
    auto tmp3_53 = -tmp1_3*tmp3_32;
    auto tmp3_54 = tmp3_53 + tmp1_7 + tmp3_52;
    auto tmp3_55 = __DenominatorCall1*tmp3_54;
    auto tmp3_56 = __DenominatorCall11*__DenominatorCall10;
    auto tmp3_57 = -__DenominatorCall1*tmp1_8*__DenominatorCall29;
    auto tmp3_58 = -SecDecInternalQuo(3, 4)*tmp3_56 + tmp3_57;
    auto tmp3_59 = tmp1_9*tmp3_58;
    auto tmp3_60 = __DenominatorCall14*tmp1_10;
    auto tmp3_61 = __DenominatorCall13 + SecDecInternalQuo(1, 2)*tmp3_60;
    auto tmp2_19 = -tmp1_5*__DenominatorCall8;
    auto tmp2_20 = tmp1_4*__DenominatorCall12;
    auto tmp2_21 = tmp1_6-SecDecInternalQuo(3, 4)*tmp1_16;
    auto tmp3_62 = __DenominatorCall6*tmp2_21;
    auto tmp2_22 = __DenominatorCall29*__DenominatorCall11;
    return(tmp3_24 + tmp3_40 + tmp3_45 + tmp3_55 + tmp3_51 + tmp3_59 + SecDecInternalQuo(1, 2)*tmp3_61 + tmp2_19 + tmp2_20 + tmp3_62 + SecDecInternalQuo(3, 2)*tmp2_22);
}
#ifdef SECDEC_WITH_CUDA
__device__ secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* const device_sector_16_order_n3_integrand = sector_16_order_n3_integrand;
secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* get_device_sector_16_order_n3_integrand()
{
    using IntegrandFunction = secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction;
    IntegrandFunction* device_address_on_host;
    auto errcode = cudaMemcpyFromSymbol(&device_address_on_host,device_sector_16_order_n3_integrand, sizeof(IntegrandFunction*));
    if (errcode != cudaSuccess) throw secdecutil::cuda_error( cudaGetErrorString(errcode) );
    return device_address_on_host;
}
#endif
}
