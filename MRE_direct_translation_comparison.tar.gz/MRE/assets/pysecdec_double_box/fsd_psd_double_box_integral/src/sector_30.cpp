#include <secdecutil/series.hpp>

#include "sector_30_n2.hpp"
#include "sector_30_n1.hpp"
#include "sector_30_0.hpp"

namespace fsd_psd_double_box_integral
{
nested_series_t<sector_container_t> get_integrand_of_sector_30()
{
return {-2,0,{{30,{-2},4,sector_30_order_n2_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_30_order_n2_integrand
#endif
},{30,{-1},6,sector_30_order_n1_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_30_order_n1_integrand
#endif
},{30,{0},6,sector_30_order_0_integrand
#ifdef SECDEC_WITH_CUDA
,get_device_sector_30_order_0_integrand
#endif
}},true,"eps"};
}

}
