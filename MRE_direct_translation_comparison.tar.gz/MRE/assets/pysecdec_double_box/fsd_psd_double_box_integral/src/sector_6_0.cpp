#include "sector_6_0.hpp"
namespace fsd_psd_double_box_integral
{
#ifdef SECDEC_WITH_CUDA
__host__ __device__
#endif
integrand_return_t sector_6_order_0_integrand
(
    real_t const * restrict const integration_variables,
    real_t const * restrict const real_parameters,
    complex_t const * restrict const complex_parameters,
    secdecutil::ResultInfo * restrict const result_info
)
{
    const auto x0 = integration_variables[0]; (void)x0;
    const auto x1 = integration_variables[1]; (void)x1;
    const auto x2 = integration_variables[2]; (void)x2;
    const auto x3 = integration_variables[3]; (void)x3;
    const auto x4 = integration_variables[4]; (void)x4;
    const auto x5 = integration_variables[5]; (void)x5;
    const auto s12 = real_parameters[0]; (void)s12;
    const auto s23 = real_parameters[1]; (void)s23;
    auto tmp1_1 = x2 + x3;
    auto tmp1_2 = x1*x4;
    auto tmp1_3 = tmp1_2 + 1;
    auto tmp3_1 = tmp1_1*tmp1_3;
    auto tmp1_4 = x4 + 1;
    auto tmp3_2 = tmp3_1 + tmp1_4 + x0;
    auto tmp1_5 = x1*tmp1_1;
    auto tmp1_6 = x1*tmp1_4;
    auto tmp3_3 = 1 + tmp1_6 + tmp1_5;
    auto tmp1_7 = x4*tmp1_1;
    auto tmp1_8 = x0*x1;
    auto tmp3_4 = tmp1_8 + x1 + tmp1_5;
    auto tmp3_5 = tmp1_4*tmp3_4;
    auto tmp3_6 = 2 + x4 + tmp3_5;
    auto tmp1_9 = x0 + 1;
    auto tmp3_7 = tmp1_7*tmp1_9;
    auto tmp3_8 = tmp1_8 + 1;
    auto tmp3_9 = tmp1_4*tmp3_8;
    auto tmp3_10 = tmp1_2*tmp1_1;
    auto tmp3_11 = tmp3_9 + tmp3_10;
    auto tmp3_12 = tmp1_7*x0;
    auto _logCall2 = SecDecInternalLog(x4);
    auto __PowCall1 = SecDecInternalSqr(x1);
    auto __PowCall2 = SecDecInternalSqr(x4);
    auto __DenominatorCall3 = SecDecInternalDenominator(x5);
    auto tmp2_7 = tmp3_12*__PowCall1;
    auto tmp3_13 = tmp2_7 + tmp3_11;
    auto tmp2_8 = tmp3_7*__PowCall1;
    auto tmp3_14 = tmp3_6 + tmp2_8;
    auto tmp2_9 = tmp1_7*__PowCall1;
    auto tmp3_15 = tmp3_3 + tmp2_9;
    auto tmp2_10 = x1*__PowCall2;
    auto _logCall1 = SecDecInternalLog(tmp2_10);
    auto _logCall3 = SecDecInternalLog(tmp3_2);
    auto __PowCall3 = SecDecInternalSqr(tmp3_2)*tmp3_2;
    auto __PowCall4 = SecDecInternalSqr(tmp3_2)*tmp3_2;
    auto __PowCall5 = SecDecInternalSqr(tmp3_2)*tmp3_2;
    auto _logCall4 = SecDecInternalLog(tmp3_15);
    auto __DenominatorCall1 = SecDecInternalDenominator(__PowCall3);
    auto __DenominatorCall2 = SecDecInternalDenominator(__PowCall4);
    auto __DenominatorCall4 = SecDecInternalDenominator(__PowCall5);
    auto tmp3_16 = _logCall2 + _logCall4;
    auto tmp3_17 = _logCall1 + _logCall3-SecDecInternalQuo(1, 2)-__DenominatorCall3-SecDecInternalQuo(3, 2)*tmp3_16;
    auto tmp3_18 = tmp3_17*tmp3_13*__DenominatorCall1;
    auto tmp3_19 = -tmp3_14*__DenominatorCall2;
    auto tmp3_20 = tmp3_13*__DenominatorCall4*__DenominatorCall3;
    return(tmp3_18 + tmp3_19 + tmp3_20);
}
#ifdef SECDEC_WITH_CUDA
__device__ secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* const device_sector_6_order_0_integrand = sector_6_order_0_integrand;
secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction* get_device_sector_6_order_0_integrand()
{
    using IntegrandFunction = secdecutil::SectorContainerWithoutDeformation<real_t, complex_t, integrand_return_t>::IntegrandFunction;
    IntegrandFunction* device_address_on_host;
    auto errcode = cudaMemcpyFromSymbol(&device_address_on_host,device_sector_6_order_0_integrand, sizeof(IntegrandFunction*));
    if (errcode != cudaSuccess) throw secdecutil::cuda_error( cudaGetErrorString(errcode) );
    return device_address_on_host;
}
#endif
}
