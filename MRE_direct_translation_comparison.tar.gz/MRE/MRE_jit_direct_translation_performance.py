#!/usr/bin/env python3
"""Standalone eager/JIT/assembly performance MRE for one Symbolica expression set.

This script has no FSD imports.  It reads the saved ``format_plain()`` strings
for the DOT double-box PSD50 explicit sector and benchmarks the corresponding
Symbolica multi-output evaluator in four representations:

  * eager real evaluator,
  * raw real-valued JIT evaluator,
  * complex-valued JIT evaluator call,
  * assembly-compiled real evaluator.

The raw real-JIT path used to expose a correctness bug on older SymJIT builds;
use ``MRE_JIT_compile_real_bug.py`` to check whether that bug is present in a
given wheel.
"""

from __future__ import annotations

import argparse
import copy
import json
from importlib.metadata import PackageNotFoundError, version
import os
from pathlib import Path
import subprocess
import statistics
import sys
import tempfile
import time
from typing import Any, Callable

import numpy as np
from symbolica import E, Expression, S


MRE_ROOT = Path(__file__).resolve().parent
DEFAULT_EXPR_FILE = MRE_ROOT / "assets" / "PSD50_explicit_format_plain.json"
DEFAULT_PYSECDEC_SHARED = (
    MRE_ROOT
    / "assets"
    / "pysecdec_double_box"
    / "fsd_psd_double_box_pylink.so"
)
DEFAULT_PYSECDEC_INTEGRAL_DIR = (
    MRE_ROOT
    / "assets"
    / "pysecdec_double_box"
    / "fsd_psd_double_box_integral"
)
REFERENCE_CPU = "Apple M3 Pro, 12 logical CPUs, Darwin arm64"
REFERENCE_PYSECDEC_MRE_SECTOR = "sector_53"
REFERENCE_PYSECDEC_MRE_SECTOR_US = 3.644
REFERENCE_PYSECDEC_MRE_SECTOR_ORDERS = "eps^-4..eps^0"


def _symbolica_version() -> str:
    try:
        return version("symbolica")
    except PackageNotFoundError:
        return "unknown"


def _parse_indices(raw: str | None) -> list[int] | None:
    """Parse a comma-separated index list or return ``None`` for all outputs."""
    if raw is None or raw.strip().lower() in {"", "all"}:
        return None
    return [int(part) for part in raw.replace(",", " ").split()]


def _load_expression_data(path: Path, indices: list[int] | None) -> tuple[list[str], list[str]]:
    """Load saved ``format_plain()`` expressions and optional output subset."""
    payload = json.loads(path.read_text())
    input_names = [str(name) for name in payload["input_names"]]
    expressions = [str(expr) for expr in payload["expressions"]]
    if indices is not None:
        expressions = [expressions[int(index)] for index in indices]
    return input_names, expressions


def _sample_rows(seed: int, batch_size: int, dimension: int) -> np.ndarray:
    """Return deterministic interior points for timing."""
    rng = np.random.default_rng(int(seed) + int(batch_size) * 1009)
    return 0.125 + 0.75 * rng.random((int(batch_size), int(dimension)))


def _time_callback(
    callback: Callable[[np.ndarray], Any],
    rows: np.ndarray,
    repeats: int,
    *,
    warmup: bool = True,
) -> float:
    """Return microseconds per sample for repeated evaluator calls."""
    if warmup:
        callback(rows)
    start = time.perf_counter()
    for _ in range(int(repeats)):
        callback(rows)
    elapsed = time.perf_counter() - start
    return 1.0e6 * elapsed / max(int(repeats) * int(rows.shape[0]), 1)


def _fmt(value: float) -> str:
    return f"{value:10.3f}"


def _optional_int(raw: str | None) -> int | None:
    """Parse an optional integer where ``none`` means Symbolica's unbounded default."""
    if raw is None:
        return None
    text = str(raw).strip().lower()
    if text in {"", "none", "null"}:
        return None
    return int(text)


def _parse_sector_ids(raw: str | None) -> list[int] | None:
    """Parse comma/space separated pySecDec generated sector ids."""
    if raw is None:
        return None
    text = str(raw).strip().lower()
    if text in {"", "all", "none"}:
        return None
    return [int(part) for part in text.replace(",", " ").split()]


def _pysecdec_kernel_us(
    integral_dir: Path,
    *,
    real_parameters: list[float],
    sector_ids: list[int] | None,
    samples: int,
    repeats: int,
    seed: int,
) -> tuple[float | None, str]:
    """Run the direct pySecDec generated-kernel benchmark helper."""
    try:
        from pysecdec_kernel_benchmark import benchmark_pysecdec_generated_kernels
    except Exception as exc:
        return None, f"could not import pysecDec kernel benchmark helper: {exc}"
    try:
        report = benchmark_pysecdec_generated_kernels(
            integral_dir,
            samples_per_sector=int(samples),
            sectors=sector_ids,
            real_parameters=real_parameters,
            repeats=int(repeats),
            seed=int(seed),
        )
        values = [
            float(entry["us_per_sector_point"])
            for entry in report.get("sectors", [])
        ]
        if not values:
            return None, "pySecDec generated-kernel benchmark produced no sector rows"
        if len(values) == 1:
            return values[0], "ok"
        return max(values), "ok"
    except Exception as exc:
        return None, f"pySecDec generated-kernel benchmark failed: {exc}"


def _rebuild_pysecdec_kernel_assets(python_executable: str) -> float:
    """Run ``make clean && make`` for the bundled sector-only pySecDec assets."""
    assets_dir = MRE_ROOT / "assets"
    start = time.perf_counter()
    commands = [
        ["make", "-C", str(assets_dir), "clean"],
        ["make", "-C", str(assets_dir), f"PYTHON={python_executable}"],
    ]
    for command in commands:
        completed = subprocess.run(
            command,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        if completed.returncode != 0:
            if completed.stdout:
                print(completed.stdout, file=sys.stderr)
            raise RuntimeError(f"command failed: {' '.join(command)}")
    return time.perf_counter() - start


def _evaluator_kwargs(args: argparse.Namespace, *, jit_compile: bool) -> dict[str, Any]:
    """Return Symbolica evaluator options for the requested optimization profile."""
    if args.optimizer_profile == "max":
        kwargs: dict[str, Any] = {
            "iterations": int(args.iterations if args.iterations is not None else 8),
            "cpe_iterations": _optional_int(args.cpe_iterations)
            if args.cpe_iterations is not None
            else None,
            "n_cores": int(args.n_cores or max(1, os.cpu_count() or 1)),
            "verbose": bool(args.verbose_evaluator),
            "jit_compile": bool(jit_compile),
            "direct_translation": True,
            "jit_direct_translation": bool(args.jit_direct_translation),
            "jit_optimization_level": int(args.jit_optimization_level),
            "max_horner_scheme_variables": int(args.max_horner_scheme_variables or 500),
            "max_common_pair_cache_entries": int(args.max_common_pair_cache_entries or 1_000_000),
            "max_common_pair_distance": int(args.max_common_pair_distance or 100),
        }
    else:
        kwargs = {
            "jit_compile": bool(jit_compile),
            "verbose": bool(args.verbose_evaluator),
        }
        # Keep Symbolica's own defaults unless an explicit override is provided.
        for key, value in {
            "iterations": args.iterations,
            "cpe_iterations": _optional_int(args.cpe_iterations),
            "n_cores": args.n_cores,
            "jit_optimization_level": args.jit_optimization_level,
            "max_horner_scheme_variables": args.max_horner_scheme_variables,
            "max_common_pair_cache_entries": args.max_common_pair_cache_entries,
            "max_common_pair_distance": args.max_common_pair_distance,
        }.items():
            if value is not None:
                kwargs[key] = int(value)
        if args.direct_translation is not None:
            kwargs["direct_translation"] = bool(args.direct_translation)
        if args.jit_direct_translation:
            kwargs["jit_direct_translation"] = True
    return kwargs


def _benchmark_jit_translation_variant(
    args: argparse.Namespace,
    expressions: list[Any],
    params: list[Any],
    *,
    jit_direct_translation: bool,
) -> dict[str, Any]:
    """Build and time one fresh JIT evaluator for one translation mode."""
    local_args = copy.copy(args)
    local_args.jit_direct_translation = bool(jit_direct_translation)
    start = time.perf_counter()
    evaluator = Expression.evaluator_multiple(
        expressions,
        params,
        **_evaluator_kwargs(local_args, jit_compile=True),
    )
    build_seconds = time.perf_counter() - start
    callbacks: dict[str, Callable[[np.ndarray], Any]] = {
        "jit-real": lambda rows: evaluator.evaluate(rows),
        "jit-complex": lambda rows: evaluator.evaluate_complex(
            np.ascontiguousarray(rows, dtype=np.complex128)
        ),
    }
    timings: dict[str, dict[int, float]] = {}
    for mode in [mode for mode in args.modes if mode in callbacks]:
        timings[mode] = {}
        for batch in args.batch_sizes:
            rows = _sample_rows(args.seed, batch, len(params))
            timings[mode][int(batch)] = _time_callback(
                callbacks[mode],
                rows,
                args.repeats,
                warmup=True,
            )
    return {"build_s": build_seconds, "timings": timings}


def _run_jit_direct_translation_comparison(
    args: argparse.Namespace,
    expressions: list[Any],
    params: list[Any],
) -> None:
    """Run repeated fresh-build direct-vs-indirect JIT timing comparisons."""
    variants = [
        ("indirect", False),
        ("direct", True),
    ]
    records: dict[str, list[dict[str, Any]]] = {label: [] for label, _ in variants}
    print("\n[jit_direct_translation comparison]")
    print(
        "Each trial builds one fresh JIT evaluator, then times warmed evaluator "
        "calls for the requested batch sizes."
    )
    for label, direct in variants:
        for trial in range(int(args.compare_trials)):
            record = _benchmark_jit_translation_variant(
                args,
                expressions,
                params,
                jit_direct_translation=direct,
            )
            records[label].append(record)
            print(
                f"  {label:8s} trial {trial + 1}/{args.compare_trials}: "
                f"build={record['build_s']:.6f}s",
                flush=True,
            )

    print("\n[generation: fresh JIT evaluator build time]")
    print(f"{'variant':>10s} {'median_s':>10s} {'mean_s':>10s} {'stdev_s':>10s}")
    build_medians: dict[str, float] = {}
    for label, _direct in variants:
        values = [float(record["build_s"]) for record in records[label]]
        build_medians[label] = statistics.median(values)
        stdev = statistics.stdev(values) if len(values) > 1 else 0.0
        print(
            f"{label:>10s} "
            f"{statistics.median(values):10.6f} "
            f"{statistics.mean(values):10.6f} "
            f"{stdev:10.6f}"
        )
    if build_medians["indirect"]:
        ratio = build_medians["direct"] / build_medians["indirect"]
        print(f"build ratio direct/indirect: {ratio:.3f}x")

    print("\n[runtime: median warmed evaluator timing, us/sample]")
    active_modes = [mode for mode in args.modes if mode in {"jit-real", "jit-complex"}]
    header = (
        f"{'mode':>11s} {'batch':>8s} "
        f"{'indirect':>10s} {'direct':>10s} {'direct/ind':>11s}"
    )
    print(header)
    for mode in active_modes:
        for batch in args.batch_sizes:
            indirect_values = [
                float(record["timings"][mode][int(batch)])
                for record in records["indirect"]
            ]
            direct_values = [
                float(record["timings"][mode][int(batch)])
                for record in records["direct"]
            ]
            indirect_median = statistics.median(indirect_values)
            direct_median = statistics.median(direct_values)
            ratio = direct_median / indirect_median if indirect_median else float("nan")
            print(
                f"{mode:>11s} {int(batch):8d} "
                f"{indirect_median:10.3f} {direct_median:10.3f} {ratio:11.3f}"
            )


def _pysecdec_runtime_us_per_maxeval(
    shared_path: Path,
    *,
    real_parameters: list[float],
    maxeval: int,
    repeats: int,
    workers: int,
) -> tuple[float | None, str]:
    """Return pySecDec wall/maxeval timing if a generated pylink is available."""
    if not shared_path.exists():
        return None, f"shared library not found: {shared_path}"
    try:
        from pySecDec.integral_interface import IntegralLibrary
    except Exception as exc:  # pragma: no cover - optional external dependency.
        return None, f"could not import pySecDec IntegralLibrary: {exc}"
    try:
        library = IntegralLibrary(str(shared_path.resolve()))
        # Match the pySecDec generated-integrator route used elsewhere in FSD
        # comparisons.  This is a whole-integral call, not the PSD50 expression
        # alone, so the table labels it as wall/maxeval rather than as a
        # one-sector evaluator timing.
        if hasattr(library, "use_Qmc"):
            library.use_Qmc(
                minn=max(int(maxeval), 1),
                maxeval=max(int(maxeval), 1),
                cputhreads=max(int(workers), 1),
                epsrel=1.0e-99,
                epsabs=1.0e-99,
            )
        # Warm up the Python wrapper / dynamic loader.
        library(
            real_parameters=real_parameters,
            format="json",
            verbose=False,
            number_of_presamples=0,
            maxeval=max(int(maxeval), 1),
            epsrel=1.0e-99,
            epsabs=1.0e-99,
        )
        start = time.perf_counter()
        for _ in range(max(int(repeats), 1)):
            library(
                real_parameters=real_parameters,
                format="json",
                verbose=False,
                number_of_presamples=0,
                maxeval=max(int(maxeval), 1),
                epsrel=1.0e-99,
                epsabs=1.0e-99,
            )
        elapsed = time.perf_counter() - start
        return 1.0e6 * elapsed / max(int(repeats) * int(maxeval), 1), "ok"
    except Exception as exc:
        return None, f"pySecDec call failed: {exc}"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--expression-file",
        type=Path,
        default=DEFAULT_EXPR_FILE,
        help="JSON file with input_names and format_plain expression strings.",
    )
    parser.add_argument(
        "--expression-indices",
        default="all",
        help=(
            "Output expression indices to use, e.g. '1' or '0,1,2'. "
            "Default 'all' uses the full five-output PSD50 expression."
        ),
    )
    parser.add_argument(
        "--modes",
        nargs="+",
        choices=["eager", "jit-real", "jit-complex", "compile"],
        default=["eager", "jit-real", "jit-complex", "compile"],
        help="Evaluator representations to benchmark.",
    )
    parser.add_argument(
        "--batch-sizes",
        nargs="+",
        type=int,
        default=[1, 16, 256, 1000, 4096],
        help="Batch sizes to time.",
    )
    parser.add_argument("--repeats", type=int, default=5, help="Timing repeats per batch.")
    parser.add_argument("--seed", type=int, default=1, help="Random seed.")
    parser.add_argument(
        "--optimizer-profile",
        choices=["default", "max"],
        default="default",
        help=(
            "Symbolica evaluator optimization profile.  'default' leaves most "
            "options at Symbolica defaults; 'max' raises iterations/cores and "
            "cache limits for best-effort runtime timing."
        ),
    )
    parser.add_argument("--iterations", type=int, default=None, help="Symbolica Horner iterations.")
    parser.add_argument(
        "--cpe-iterations",
        default=None,
        help="Common-pair elimination iterations; use 'none' for Symbolica's unbounded default.",
    )
    parser.add_argument("--n-cores", type=int, default=None, help="Symbolica evaluator build cores.")
    parser.add_argument(
        "--jit-optimization-level",
        type=int,
        default=3,
        help="Symbolica JIT optimization level.",
    )
    parser.add_argument(
        "--max-horner-scheme-variables",
        type=int,
        default=None,
        help="Maximum variables considered in Horner scheme search.",
    )
    parser.add_argument(
        "--max-common-pair-cache-entries",
        type=int,
        default=None,
        help="Common-pair cache entry limit.",
    )
    parser.add_argument(
        "--max-common-pair-distance",
        type=int,
        default=None,
        help="Common-pair distance limit.",
    )
    parser.add_argument(
        "--direct-translation",
        dest="direct_translation",
        action="store_true",
        default=None,
        help="Force Symbolica direct_translation=True.",
    )
    parser.add_argument(
        "--no-direct-translation",
        dest="direct_translation",
        action="store_false",
        help="Force Symbolica direct_translation=False.",
    )
    parser.add_argument(
        "--jit-direct-translation",
        action="store_true",
        help="Enable Symbolica jit_direct_translation.",
    )
    parser.add_argument(
        "--compare-jit-direct-translation",
        action="store_true",
        help=(
            "Run both jit_direct_translation=False and True in repeated fresh-build "
            "trials and print generation/runtime ratios."
        ),
    )
    parser.add_argument(
        "--compare-trials",
        type=int,
        default=5,
        help="Fresh evaluator builds per translation mode for --compare-jit-direct-translation.",
    )
    parser.add_argument(
        "--verbose-evaluator",
        action="store_true",
        help="Pass verbose=True to Symbolica evaluator construction.",
    )
    parser.add_argument(
        "--pysecdec-shared",
        type=Path,
        default=DEFAULT_PYSECDEC_SHARED,
        help=(
            "Optional generated pySecDec pylink .so.  If present, the table "
            "adds a whole-integral pySecDec wall/maxeval row."
        ),
    )
    parser.add_argument(
        "--pysecdec-integral-dir",
        type=Path,
        default=DEFAULT_PYSECDEC_INTEGRAL_DIR,
        help=(
            "Generated pySecDec *_integral directory used by the optional "
            "direct sector/order kernel benchmark."
        ),
    )
    parser.add_argument(
        "--skip-pysecdec",
        action="store_true",
        default=True,
        help="Do not attempt the optional pySecDec timing row.",
    )
    parser.add_argument(
        "--include-pysecdec-wall-maxeval",
        dest="skip_pysecdec",
        action="store_false",
        help=(
            "Also show the optional pySecDec generated-library wall/maxeval row. "
            "This is not a same-sector PSD50 timing and is disabled by default."
        ),
    )
    parser.add_argument(
        "--run-pysecdec-kernel-benchmark",
        action="store_true",
        help=(
            "Also time pySecDec's generated C++ sector/order kernels directly. "
            "By default this uses generated sector 53, matching pySecDec53_REF. "
            "This option automatically runs `make clean && make` in assets and "
            "reports that elapsed time in the build_s column."
        ),
    )
    parser.add_argument(
        "--pysecdec-kernel-sectors",
        default="53",
        help=(
            "Generated pySecDec sector ids for --run-pysecdec-kernel-benchmark. "
            "Use 'all' to scan all generated sectors."
        ),
    )
    parser.add_argument(
        "--pysecdec-kernel-repeats",
        type=int,
        default=1,
        help="Repeated generated-kernel timing loops per table column.",
    )
    parser.add_argument(
        "--pysecdec-real-parameters",
        nargs="+",
        type=float,
        default=[-1.0, -1.0],
        help="Real parameters passed to the generated pySecDec library.",
    )
    parser.add_argument(
        "--pysecdec-repeats",
        type=int,
        default=1,
        help="Repeated pySecDec calls per table column.",
    )
    parser.add_argument(
        "--pysecdec-workers",
        type=int,
        default=max(1, min(10, (os.cpu_count() or 1))),
        help="cputhreads setting for pySecDec QMC timing.",
    )
    args = parser.parse_args()

    indices = _parse_indices(args.expression_indices)
    input_names, expression_strings = _load_expression_data(args.expression_file, indices)
    params = [S(name) for name in input_names]

    print("Standalone Symbolica evaluator performance MRE")
    print(f"python: {sys.executable}")
    print(f"symbolica version: {_symbolica_version()}")
    print(f"expression file: {args.expression_file}")
    print(f"outputs used: {'all' if indices is None else indices}")
    print(f"input count: {len(params)}")
    print(f"output count: {len(expression_strings)}")
    print(f"expression bytes: {sum(len(expr.encode('utf-8')) for expr in expression_strings)}")
    print(f"batch sizes: {args.batch_sizes}")
    print(f"repeats: {args.repeats}")
    print(f"optimizer profile: {args.optimizer_profile}")
    print(f"evaluator kwargs eager: {_evaluator_kwargs(args, jit_compile=False)}")
    print(f"evaluator kwargs jit: {_evaluator_kwargs(args, jit_compile=True)}")

    t0 = time.perf_counter()
    expressions = [E(expr) for expr in expression_strings]
    parse_seconds = time.perf_counter() - t0
    print(f"parse time: {parse_seconds:.6f} s")

    if args.compare_jit_direct_translation:
        _run_jit_direct_translation_comparison(args, expressions, params)
        return 0

    evaluators: dict[str, Any] = {}
    build_seconds: dict[str, float] = {}

    if any(mode in args.modes for mode in ("eager", "compile")):
        t0 = time.perf_counter()
        eager = Expression.evaluator_multiple(
            expressions,
            params,
            **_evaluator_kwargs(args, jit_compile=False),
        )
        build_seconds["eager"] = time.perf_counter() - t0
        evaluators["eager"] = eager
        print(f"eager build time: {build_seconds['eager']:.6f} s")
    else:
        eager = None

    if any(mode in args.modes for mode in ("jit-real", "jit-complex")):
        t0 = time.perf_counter()
        jit = Expression.evaluator_multiple(
            expressions,
            params,
            **_evaluator_kwargs(args, jit_compile=True),
        )
        jit_seconds = time.perf_counter() - t0
        evaluators["jit-real"] = jit
        evaluators["jit-complex"] = jit
        build_seconds["jit-real"] = jit_seconds
        build_seconds["jit-complex"] = jit_seconds
        print(f"JIT build time: {jit_seconds:.6f} s")

    if "compile" in args.modes:
        if eager is None:
            t0 = time.perf_counter()
            eager = Expression.evaluator_multiple(
                expressions,
                params,
                **_evaluator_kwargs(args, jit_compile=False),
            )
            build_seconds["eager"] = time.perf_counter() - t0
            evaluators["eager"] = eager
            print(f"eager build time for compile source: {build_seconds['eager']:.6f} s")
        tmpdir = Path(tempfile.mkdtemp(prefix="symbolica-mre-compiled-"))
        t0 = time.perf_counter()
        compiled = eager.compile(
            "mre_psd50_explicit",
            str(tmpdir / "mre_psd50_explicit.cpp"),
            str(tmpdir / "libmre_psd50_explicit.so"),
            "real",
        )
        build_seconds["compile"] = time.perf_counter() - t0
        evaluators["compile"] = compiled
        print(f"assembly compile time: {build_seconds['compile']:.6f} s")

    pysecdec_kernel_build_seconds = 0.0
    if args.run_pysecdec_kernel_benchmark:
        print("\n[pySecDec generated-kernel rebuild]")
        print("running: make -C assets clean && make -C assets")
        pysecdec_kernel_build_seconds = _rebuild_pysecdec_kernel_assets(sys.executable)
        print(f"pySecDec sector-only rebuild time: {pysecdec_kernel_build_seconds:.6f} s")

    callbacks: dict[str, Callable[[np.ndarray], Any]] = {
        "eager": lambda rows: evaluators["eager"].evaluate(rows),
        "jit-real": lambda rows: evaluators["jit-real"].evaluate(rows),
        "jit-complex": lambda rows: evaluators["jit-complex"].evaluate_complex(
            np.ascontiguousarray(rows, dtype=np.complex128)
        ),
        "compile": lambda rows: evaluators["compile"].evaluate(rows),
    }

    # Correctness against eager, when available.  Older SymJIT builds failed
    # this check for raw real-JIT on this expression set; current fixed builds
    # should agree with eager to roundoff.
    if "eager" in evaluators:
        rows = _sample_rows(args.seed, 8, len(params))
        reference = np.asarray(callbacks["eager"](rows), dtype=float)
        print("\n[numerical check against eager]")
        for mode in args.modes:
            values = callbacks[mode](rows)
            values = np.asarray(values, dtype=np.complex128 if mode == "jit-complex" else float)
            if mode == "jit-complex":
                values = values.real
            diff = float(np.max(np.abs(values - reference)))
            scale = max(1.0, float(np.max(np.abs(reference))))
            print(f"  {mode:>11s}: max_abs_diff={diff:.6e} rel={diff / scale:.6e}")

    print("\n[warmed evaluator timing, us/sample]")
    print(
        f"{'mode':>11s} {'build_s':>9s} "
        + " ".join(f"{('b=' + str(batch)):>10s}" for batch in args.batch_sizes)
    )
    for mode in args.modes:
        values: list[str] = []
        for batch in args.batch_sizes:
            rows = _sample_rows(args.seed, batch, len(params))
            us = _time_callback(callbacks[mode], rows, args.repeats, warmup=True)
            values.append(_fmt(us))
        print(f"{mode:>11s} {build_seconds.get(mode, 0.0):9.3f} " + " ".join(values))
    if not args.run_pysecdec_kernel_benchmark:
        reference_values = [_fmt(REFERENCE_PYSECDEC_MRE_SECTOR_US) for _ in args.batch_sizes]
        print(f"{'pySecDec53_REF':>11s} {'n/a':>9s} " + " ".join(reference_values))

    if args.run_pysecdec_kernel_benchmark:
        sector_ids = _parse_sector_ids(args.pysecdec_kernel_sectors)
        kernel_values: list[str] = []
        kernel_notes: list[str] = []
        for batch in args.batch_sizes:
            us, note = _pysecdec_kernel_us(
                args.pysecdec_integral_dir,
                real_parameters=[float(value) for value in args.pysecdec_real_parameters],
                sector_ids=sector_ids,
                samples=int(batch),
                repeats=int(args.pysecdec_kernel_repeats),
                seed=int(args.seed),
            )
            kernel_values.append("   skipped" if us is None else _fmt(us))
            if note != "ok":
                kernel_notes.append(note)
        label = "pySecDec53" if sector_ids == [53] else "pySecDec"
        print(f"{label:>11s} {pysecdec_kernel_build_seconds:9.3f} " + " ".join(kernel_values))
        if kernel_notes:
            print("pySecDec generated-kernel note: " + kernel_notes[0])
        else:
            selected = "sector_53" if sector_ids == [53] else args.pysecdec_kernel_sectors
            print(
                "pySecDec generated-kernel row times generated C++ "
                f"sector/order functions directly for {selected}."
            )

    if not args.skip_pysecdec:
        py_values: list[str] = []
        py_notes: list[str] = []
        for batch in args.batch_sizes:
            us, note = _pysecdec_runtime_us_per_maxeval(
                args.pysecdec_shared,
                real_parameters=[float(value) for value in args.pysecdec_real_parameters],
                maxeval=int(batch),
                repeats=int(args.pysecdec_repeats),
                workers=int(args.pysecdec_workers),
            )
            py_values.append("   skipped" if us is None else _fmt(us))
            if note != "ok":
                py_notes.append(note)
        print(f"{'pySecDec*':>11s} {0.0:9.3f} " + " ".join(py_values))
        if py_notes:
            print("pySecDec note: " + py_notes[0])
        else:
            print(
                "pySecDec* is a generated whole-integral call normalized as "
                "wall/maxeval, not the standalone PSD50 expression alone."
            )

    print(
        "\nNote: raw real-JIT timings are shown because they are the intended "
        "fast real-valued path.  Older SymJIT builds mis-evaluated this saved "
        "expression set; rerun MRE_JIT_compile_real_bug.py to check a specific "
        "wheel."
    )
    if args.run_pysecdec_kernel_benchmark:
        print(
            "The pySecDec53 row above was executed in this run from the "
            "bundled generated pySecDec source after rebuilding the local "
            "static library.  For reference, the previous recorded timing for "
            "pySecDec's generated "
            f"double-box {REFERENCE_PYSECDEC_MRE_SECTOR} order kernels "
            f"({REFERENCE_PYSECDEC_MRE_SECTOR_ORDERS}) on {REFERENCE_CPU}: "
            f"{REFERENCE_PYSECDEC_MRE_SECTOR_US:.3f} us per generated sector "
            "point."
        )
    else:
        print(
            "pySecDec53_REF is not executed by default by this Python MRE.  It "
            "is the recorded direct C++ timing of pySecDec's generated "
            f"double-box {REFERENCE_PYSECDEC_MRE_SECTOR} order kernels "
            f"({REFERENCE_PYSECDEC_MRE_SECTOR_ORDERS}) on {REFERENCE_CPU}: "
            f"{REFERENCE_PYSECDEC_MRE_SECTOR_US:.3f} us per generated sector "
            "point.  This is the relevant pySecDec raw-kernel reference for "
            "this MRE."
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
