#!/usr/bin/env sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

if [ -f "$SCRIPT_DIR/assets/Makefile" ]; then
  make -C "$SCRIPT_DIR/assets" clean >/dev/null 2>&1 || true
fi

find "$SCRIPT_DIR" -type d -name '__pycache__' -prune -exec rm -rf {} +
find "$SCRIPT_DIR" -type f \( \
  -name '*.pyc' -o \
  -name '*.pyo' -o \
  -name '*.swp' -o \
  -name '*.o' -o \
  -name '*.a' -o \
  -name '*.so' -o \
  -name '*.dylib' -o \
  -name '*.dll' -o \
  -name '*.fatbin' \
\) -delete
