"""Self-contained direct benchmark for bundled pySecDec generated kernels.

This file intentionally has no imports from the FSD project.  It is used by
``MRE_jit_direct_translation_performance.py`` when ``--run-pysecdec-kernel-benchmark`` is
requested and the bundled generated pySecDec source has been built with:

    make -C assets pysecdec-double-box-static
"""

from __future__ import annotations

from dataclasses import dataclass
import importlib
import json
from pathlib import Path
import re
import statistics
import subprocess
import tempfile
from typing import Any


_KERNEL_RE = re.compile(r"^sector_(\d+)_order_(.+)$")


@dataclass(frozen=True)
class PySecDecKernelRecord:
    sector_id: int
    orders: tuple[str, ...]
    samples: int
    seconds: float
    checksum: float

    @property
    def us_per_sector_point(self) -> float:
        return 1.0e6 * self.seconds / max(int(self.samples), 1)

    def to_dict(self) -> dict[str, Any]:
        return {
            "sector_id": self.sector_id,
            "orders": list(self.orders),
            "samples": self.samples,
            "seconds": self.seconds,
            "us_per_sector_point": self.us_per_sector_point,
            "checksum": self.checksum,
        }


def _order_sort_key(token: str) -> tuple[int, str]:
    if token.startswith("n") and token[1:].isdigit():
        return (int(token[1:]), token)
    try:
        return (1000 + int(token), token)
    except ValueError:
        return (2000, token)


def _pysecdec_contrib_dir() -> Path:
    try:
        module = importlib.import_module("pySecDecContrib")
    except Exception as exc:
        raise RuntimeError(
            "pySecDecContrib is required to compile the generated-kernel benchmark"
        ) from exc
    return Path(module.__file__).resolve().parent


def _kernel_groups(metadata: dict[str, Any]) -> dict[int, list[str]]:
    groups: dict[int, list[str]] = {}
    for kernel in metadata.get("kernels", []):
        match = _KERNEL_RE.match(str(kernel))
        if match is None:
            continue
        groups.setdefault(int(match.group(1)), []).append(match.group(2))
    for orders in groups.values():
        orders.sort(key=_order_sort_key)
    return groups


def _build_driver_source(
    *,
    namespace: str,
    dimension: int,
    grouped_orders: dict[int, list[str]],
    real_parameters: list[float],
    seed: int,
) -> str:
    includes: list[str] = []
    calls: list[str] = []
    for sector_id in sorted(grouped_orders):
        for token in grouped_orders[sector_id]:
            includes.append(f'#include "src/sector_{sector_id}_{token}.hpp"')
            calls.append(
                "        { "
                f"{sector_id}, \"{token}\", "
                "+[] (const double* x, const double* p, "
                "const std::complex<double>* cp) -> std::complex<double> { "
                f"return {namespace}::sector_{sector_id}_order_{token}_integrand"
                "(x, p, cp, nullptr); } },"
            )
    params = ", ".join(f"{float(value):.17g}" for value in real_parameters)
    return f"""
#include <algorithm>
#include <chrono>
#include <complex>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <map>
#include <random>
#include <string>
#include <vector>
{chr(10).join(sorted(set(includes)))}

struct Kernel {{
    int sector;
    const char* order;
    std::complex<double> (*fn)(const double*, const double*, const std::complex<double>*);
}};

int main(int argc, char** argv) {{
    const int dim = {int(dimension)};
    const int samples = argc > 1 ? std::atoi(argv[1]) : 10000;
    const int repeats = argc > 2 ? std::atoi(argv[2]) : 1;
    const unsigned long long seed = static_cast<unsigned long long>({int(seed)});
    std::vector<double> params = {{ {params} }};
    std::vector<std::complex<double>> cparams;
    std::vector<Kernel> kernels = {{
{chr(10).join(calls)}
    }};

    std::vector<double> points(static_cast<std::size_t>(samples) * dim);
    std::mt19937_64 rng(seed);
    std::uniform_real_distribution<double> dist(0.125, 0.875);
    for (int i = 0; i < samples; ++i) {{
        for (int j = 0; j < dim; ++j) {{
            points[static_cast<std::size_t>(i) * dim + j] = dist(rng);
        }}
    }}

    std::map<int, double> seconds;
    std::map<int, double> checksum;
    for (auto const& k : kernels) {{
        volatile double sink = 0.0;
        auto t0 = std::chrono::steady_clock::now();
        for (int r = 0; r < repeats; ++r) {{
            for (int i = 0; i < samples; ++i) {{
                const double* x = &points[static_cast<std::size_t>(i) * dim];
                auto val = k.fn(x, params.data(), cparams.data());
                sink += val.real() + 0.01 * val.imag();
            }}
        }}
        auto t1 = std::chrono::steady_clock::now();
        const double elapsed = std::chrono::duration<double>(t1 - t0).count();
        seconds[k.sector] += elapsed;
        checksum[k.sector] += sink;
    }}
    for (auto const& entry : seconds) {{
        const int sector = entry.first;
        std::cout << "sector_total "
                  << sector << " "
                  << std::setprecision(17) << entry.second << " "
                  << checksum[sector] << "\\n";
    }}
    return 0;
}}
"""


def _parse_driver_output(
    output: str,
    *,
    samples: int,
    repeats: int,
    grouped_orders: dict[int, list[str]],
) -> list[PySecDecKernelRecord]:
    records: list[PySecDecKernelRecord] = []
    effective_samples = max(int(samples) * int(repeats), 1)
    for line in output.splitlines():
        parts = line.split()
        if not parts or parts[0] != "sector_total":
            continue
        sector_id = int(parts[1])
        records.append(
            PySecDecKernelRecord(
                sector_id=sector_id,
                orders=tuple(grouped_orders.get(sector_id, ())),
                samples=effective_samples,
                seconds=float(parts[2]),
                checksum=float(parts[3]),
            )
        )
    return sorted(records, key=lambda item: item.sector_id)


def benchmark_pysecdec_generated_kernels(
    integral_dir: str | Path,
    *,
    samples_per_sector: int,
    sectors: list[int] | tuple[int, ...] | None = None,
    real_parameters: list[float] | tuple[float, ...] | None = None,
    repeats: int = 1,
    seed: int = 12345,
) -> dict[str, Any]:
    integral_dir = Path(integral_dir).expanduser().resolve()
    metadata_path = integral_dir / "disteval" / f"{integral_dir.name}.json"
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    namespace = str(metadata.get("name") or integral_dir.name)
    grouped = _kernel_groups(metadata)
    if sectors is not None:
        selected = {int(sector_id) for sector_id in sectors}
        grouped = {sector_id: orders for sector_id, orders in grouped.items() if sector_id in selected}
    if not grouped:
        raise ValueError("no generated pySecDec sector kernels selected")
    if real_parameters is None:
        real_parameters = [0.0 for _ in metadata.get("realp", [])]
    lib = integral_dir / f"lib{namespace}.a"
    if not lib.is_file():
        raise FileNotFoundError(
            f"missing {lib}; run `make -C {integral_dir.parent.parent} pysecdec-double-box-static`"
        )
    contrib = _pysecdec_contrib_dir()
    source = _build_driver_source(
        namespace=namespace,
        dimension=int(metadata["dimension"]),
        grouped_orders=grouped,
        real_parameters=[float(value) for value in real_parameters],
        seed=int(seed),
    )
    with tempfile.TemporaryDirectory(prefix="mre-pysecdec-kernel-bench-") as tmp:
        tmpdir = Path(tmp)
        cpp = tmpdir / "bench.cpp"
        exe = tmpdir / "bench"
        cpp.write_text(source, encoding="utf-8")
        subprocess.run(
            [
                "c++",
                "-std=c++17",
                "-O3",
                "-I",
                str(integral_dir),
                "-I",
                str(integral_dir / "src"),
                "-I",
                str(contrib / "include"),
                str(cpp),
                str(lib),
                "-L",
                str(contrib / "lib"),
                "-lgsl",
                "-lgslcblas",
                "-lcuba",
                "-lgmp",
                "-lm",
                "-pthread",
                "-o",
                str(exe),
            ],
            check=True,
            text=True,
        )
        output = subprocess.check_output(
            [str(exe), str(int(samples_per_sector)), str(int(repeats))],
            text=True,
        )
    records = _parse_driver_output(
        output,
        samples=int(samples_per_sector),
        repeats=int(repeats),
        grouped_orders=grouped,
    )
    values = [record.us_per_sector_point for record in records]
    return {
        "sector_count": len(records),
        "kernel_count": sum(len(orders) for orders in grouped.values()),
        "runtime_us_per_sector_point": {
            "min": min(values),
            "max": max(values),
            "average": statistics.fmean(values),
            "median": statistics.median(values),
        },
        "sectors": [record.to_dict() for record in records],
    }
